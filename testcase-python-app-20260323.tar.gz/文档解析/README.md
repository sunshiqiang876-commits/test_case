# 文档解析服务说明

Flask 应用（默认端口 **5000**），负责 **上传文档 → 解析为 Markdown / OCR 产物**，以及 **Wiki 页面拉取与解析**。主站（Node）通过 `DOC_PARSER_API_BASE` 把浏览器请求代理到本服务。

---

## 核心能力概览

| 能力 | 说明 |
|------|------|
| **本地上传解析** | 接收 `.docx` / `.pdf`，后台调用 `run_parse.py`：MarkItDown 转 Markdown、图片 OCR 走 **Bella 接口**（需 `BELLA_API_KEY`）、图片抽取与外链处理。 |
| **Wiki 导入解析** | 对 **wiki.lianjia.com** 的页面 URL 拉取 HTML，转 Markdown 并走与上传类似的后续处理；需 Wiki Cookie / Token（请求头或环境变量）。 |
| **异步任务** | 上传与 Wiki 均创建 **job**，前端轮询 `/api/jobs/{id}` 或 Wiki 对应接口查看进度与结果。 |
| **历史记录** | 解析结果写入历史列表，供主站「引用历史文档」等能力使用（`/api/history`）。 |
| **产物访问** | 生成的 `.md`、`_ocr.md`、图片目录等可通过 `/files/...` 或按路径读文本（`/api/file-text`）；可选接 Postgres / S3（见 `parser_persistence.py`、`artifact_store.py`）。 |

---

## 路由与功能对应表

### 浏览器页面（HTML）

| 路径 | 方法 | 功能 |
|------|------|------|
| `/` | GET | 文档解析独立首页：展示上传表单（模板 `index.html`）。 |
| `/` | POST | 提交上传文件，创建解析任务后 **303 重定向** 到任务页。 |
| `/job/<job_id>` | GET | 任务进行中页面（轮询状态，模板 `job.html`）。 |
| `/job/<job_id>/result` | GET | 任务完成后展示结果列表（模板 `result.html`）；未完成则重定向回任务页。 |

### 静态 / 产物文件

| 路径 | 方法 | 功能 |
|------|------|------|
| `/files/<path:filename>` | GET / HEAD | 按相对路径返回解析产物文件（如 `.md`、图片）；走 `artifact_store`，防止路径穿越。 |

### JSON API（供主站代理或脚本调用）

| 路径 | 方法 | 功能 |
|------|------|------|
| `/api/health` | GET | 健康检查，返回 `success` / `data.ok`。 |
| `/api/history` | GET | 返回解析历史记录列表（主站「历史文档」数据源）。 |
| `/api/parse` | POST | **multipart 上传**一个或多个文件（字段名 `file`），可选表单 `target`；返回 `jobId`，**202**。 |
| `/api/jobs/<job_id>` | GET | 查询上传解析任务状态、进度、错误信息、完成后的结果路径等。 |
| `/api/file-text` | GET | 查询参数 `path=`，返回指定相对路径文件的 **文本内容**（JSON 包装）。 |
| `/api/wiki/import` | POST | JSON body：`url`（必填）、`target`（可选）；请求头可带 `X-Wiki-Cookie`、`X-Wiki-Auth-Token`。创建 **Wiki 解析任务**，**202**。 |
| `/api/wiki/jobs/<job_id>` | GET | 查询 Wiki 解析任务（与上传任务共用内存 job 存储结构）。 |

### 其它

| 项 | 说明 |
|------|------|
| **CORS** | 仅对 `ALLOWED_CORS_ORIGINS` 中的来源（如 `localhost:3002`）加跨域头，便于浏览器直连调试。 |
| **405** | 统一重定向到首页，避免错误方法停留在空白页。 |

---

## 后台脚本与模块

| 文件 | 作用 |
|------|------|
| `run_parse.py` | 实际执行：MarkItDown、锚点/链接修正、图片抽取、**Bella OCR**（仅云端，依赖 `BELLA_API_KEY`）。 |
| `wiki_import.py` | Wiki URL 校验（仅允许配置的主机）、拉取页面、HTML→Markdown、与任务流水线对接。 |
| `parser_persistence.py` | 可选将任务与历史同步到 **Postgres**（`DATABASE_URL`）。 |
| `artifact_store.py` | 产物读写：本地目录或 **S3 兼容存储**（环境变量控制）。 |

---

## 与主站（Node）的关系

- 浏览器一般只访问 **Node 同源** 的 `/api/history`、`/api/parse`、`/api/wiki/parse` 等；Node **转发**到本服务对应路径（见 `server.js` 中 `DOC_PARSER_API_BASE`）。
- 本服务 **默认不替主站提供** 测试用例生成，只负责 **文档 / Wiki → Markdown 及附属文件**。

---

## 部署与配置摘要

- **依赖**：Python 3.10+，`pip install -r requirements.txt`（含 markitdown 等；**OCR 不再内置 Paddle**，须配置 Bella）。
- **启动**：`HOST=0.0.0.0 PORT=5000 python3 web_app.py` 或使用 **`Dockerfile` / `docker-compose.yml`**（见 `DEPLOY.md`）。
- **环境变量**：数据库、Wiki 默认凭证、S3、OCR 地址等见 **`DEPLOY.md`** 与 **`.env.example`**。

---

## 默认限制（安全 / 产品）

- 上传扩展名：**`.docx`、`.pdf`**（见 `SUPPORTED_UPLOAD_EXTENSIONS`）。
- Wiki 主机：当前实现为 **`wiki.lianjia.com`**（见 `wiki_import.py` / `web_app` 中相关逻辑）。

如需改域名或扩展名，需在代码或配置中同步调整并回归测试。
