from __future__ import annotations

import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import threading
import uuid

from flask import Flask, Response, abort, redirect, render_template, request, send_file, url_for
from wiki_import import normalize_wiki_url, parse_wiki_page, resolve_wiki_auth

BASE_DIR = Path(os.environ.get("BASE_DIR", Path(__file__).resolve().parent))
UPLOAD_DIR = BASE_DIR / "uploads"
DATA_DIR = BASE_DIR / "data"
HISTORY_FILE = DATA_DIR / "parse_history.json"
RUN_PARSE = BASE_DIR / "run_parse.py"
HISTORY_LIMIT = 120
ALLOWED_CORS_ORIGINS = {
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:3002",
    "http://127.0.0.1:3002",
}
SUPPORTED_UPLOAD_EXTENSIONS = {".docx", ".pdf"}

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024  # 200MB

JOBS = {}
history_lock = threading.Lock()


def _safe_resolve(path: Path) -> Path:
    resolved = path.resolve()
    base = BASE_DIR.resolve()
    if base not in resolved.parents and resolved != base:
        raise ValueError("Path outside base directory")
    return resolved


def _run_parse(upload_path: Path) -> dict:
    cmd = ["python3", str(RUN_PARSE), str(upload_path), "--out-dir", str(BASE_DIR)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr or result.stdout)

    outputs = {}
    for line in (result.stdout or "").splitlines():
        line = line.strip()
        for key in ("Markdown:", "OCR Markdown:", "OCR JSON:"):
            if line.startswith(key):
                outputs[key] = line.replace(key, "", 1).strip()
                break
    outputs["stdout"] = result.stdout or ""
    outputs["stderr"] = result.stderr or ""
    return outputs


def _relpath(path_str: str) -> str:
    p = Path(path_str).resolve()
    return str(p.relative_to(BASE_DIR.resolve()))


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_history_unlocked() -> list[dict] | None:
    try:
        from parser_persistence import history_load

        db = history_load()
        if db is not None:
            return db
    except Exception:
        pass
    if not HISTORY_FILE.exists():
        return None
    try:
        data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _write_history_unlocked(records: list[dict]) -> None:
    temp_path = HISTORY_FILE.with_name(f"{HISTORY_FILE.stem}.{uuid.uuid4().hex}.tmp")
    temp_path.write_text(
        json.dumps(records[:HISTORY_LIMIT], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temp_path.replace(HISTORY_FILE)
    try:
        from parser_persistence import history_save

        history_save(records, limit=HISTORY_LIMIT)
    except Exception:
        pass


def _set_job(job_id: str, payload: dict) -> None:
    JOBS[job_id] = payload
    try:
        from parser_persistence import job_upsert

        job_upsert(payload)
    except Exception:
        pass


def _get_job(job_id: str) -> dict | None:
    job = JOBS.get(job_id)
    if job:
        return job
    try:
        from parser_persistence import job_get

        job = job_get(job_id)
        if job:
            JOBS[job_id] = job
        return job
    except Exception:
        return None


def _legacy_display_name(base_name: str) -> str:
    return re.sub(r"^[0-9a-f]{32}_", "", base_name)


def _normalize_target(target: str | None) -> str:
    value = (target or "").strip().lower()
    return value if value in {"prd", "tech"} else ""


def _infer_target_from_name(filename: str) -> str:
    lowered = (filename or "").lower()
    if "__tech_" in lowered or "tech" in lowered:
        return "tech"
    if "__prd_" in lowered or "prd" in lowered:
        return "prd"
    return ""


def _bootstrap_history_records(limit: int = HISTORY_LIMIT) -> list[dict]:
    records: list[dict] = []
    candidates = sorted(
        BASE_DIR.glob("*_ocr.md"),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    for ocr_md_path in candidates[:limit]:
        base_name = ocr_md_path.name[: -len("_ocr.md")]
        markdown_path = BASE_DIR / f"{base_name}.md"
        ocr_json_path = BASE_DIR / f"{base_name}_ocr.json"
        inferred_target = _infer_target_from_name(base_name)
        records.append(
            {
                "id": f"legacy-{base_name}",
                "createdAt": datetime.fromtimestamp(
                    ocr_md_path.stat().st_mtime, tz=timezone.utc
                ).isoformat(),
                "status": "done",
                "target": inferred_target,
                "error": "",
                "results": [
                    {
                        "filename": _legacy_display_name(base_name),
                        "target": inferred_target,
                        "markdown": _relpath(str(markdown_path)) if markdown_path.exists() else "",
                        "ocr_markdown": _relpath(str(ocr_md_path)),
                        "ocr_json": _relpath(str(ocr_json_path)) if ocr_json_path.exists() else "",
                        "stdout": "",
                        "stderr": "",
                        "error": "",
                    }
                ],
            }
        )
        try:
            from artifact_store import store_directory, store_relative_path

            legacy_job_id = f"legacy-{base_name}"
            if markdown_path.exists():
                store_relative_path(BASE_DIR, legacy_job_id, _relpath(str(markdown_path)), "markdown")
            store_relative_path(BASE_DIR, legacy_job_id, _relpath(str(ocr_md_path)), "ocr_markdown")
            if ocr_json_path.exists():
                store_relative_path(BASE_DIR, legacy_job_id, _relpath(str(ocr_json_path)), "ocr_json")
            store_directory(BASE_DIR, legacy_job_id, f"images_{base_name}", "image")
        except Exception:
            pass
    return records


def _load_history_records() -> list[dict]:
    with history_lock:
        records = _read_history_unlocked()
        if records is None:
            records = _bootstrap_history_records()
            _write_history_unlocked(records)
        return records


def _save_history_record(record: dict) -> None:
    with history_lock:
        existing = _read_history_unlocked()
        if existing is None:
            existing = _bootstrap_history_records()
        deduped = [item for item in existing if item.get("id") != record.get("id")]
        _write_history_unlocked([record, *deduped])


def _build_job_payload(job_id: str, created_at: str, status: str, results: list, error: str) -> dict:
    return {
        "id": job_id,
        "createdAt": created_at,
        "status": status,
        "target": "",
        "results": results,
        "error": error,
    }


def _is_supported_upload(filename: str) -> bool:
    return Path(filename or "").suffix.lower() in SUPPORTED_UPLOAD_EXTENSIONS


def _start_parse_job(files, target: str | None = None) -> tuple[str | None, str | None]:
    if not files:
        return None, "请选择要上传的文件。"

    job_id = uuid.uuid4().hex
    created_at = _now_iso()
    normalized_target = _normalize_target(target)
    initial_payload = _build_job_payload(job_id, created_at, "running", [], "")
    initial_payload["target"] = normalized_target
    _set_job(job_id, initial_payload)

    prepared = []
    pre_results = []
    for file in files:
        if not file or not file.filename:
            continue
        if not _is_supported_upload(file.filename):
            pre_results.append(
                {"filename": file.filename, "error": "仅支持 .docx / .pdf 文件。"}
            )
            continue
        save_name = f"{uuid.uuid4().hex}_{file.filename}"
        upload_path = UPLOAD_DIR / save_name
        file.save(upload_path)
        prepared.append((file.filename, upload_path))

    def _worker():
        try:
            results = list(pre_results)
            for original_name, upload_path in prepared:
                try:
                    outputs = _run_parse(upload_path)
                    from artifact_store import store_parse_outputs

                    stored_outputs = store_parse_outputs(BASE_DIR, job_id, outputs)
                except Exception as exc:
                    results.append(
                        {"filename": original_name, "error": f"解析失败：{exc}"}
                    )
                    continue
                finally:
                    upload_path.unlink(missing_ok=True)

                result = {
                    "filename": original_name,
                    "target": normalized_target or _infer_target_from_name(original_name),
                    "markdown": stored_outputs.get("Markdown:", ""),
                    "ocr_markdown": stored_outputs.get("OCR Markdown:", ""),
                    "ocr_json": stored_outputs.get("OCR JSON:", ""),
                    "stdout": outputs.get("stdout", ""),
                    "stderr": outputs.get("stderr", ""),
                    "error": "",
                }

                results.append(result)

            if not results:
                final_payload = _build_job_payload(
                    job_id,
                    created_at,
                    "error",
                    [],
                    "未检测到可解析的文件。",
                )
                final_payload["target"] = normalized_target
                _set_job(job_id, final_payload)
                _save_history_record(final_payload)
                return

            all_failed = all(item.get("error") for item in results)
            final_payload = _build_job_payload(
                job_id,
                created_at,
                "error" if all_failed else "done",
                results,
                "全部文件解析失败。" if all_failed else "",
            )
            final_payload["target"] = normalized_target
            _set_job(job_id, final_payload)
            _save_history_record(final_payload)
        except Exception as exc:
            final_payload = _build_job_payload(job_id, created_at, "error", [], str(exc))
            final_payload["target"] = normalized_target
            _set_job(job_id, final_payload)
            _save_history_record(final_payload)

    threading.Thread(target=_worker, daemon=True).start()
    return job_id, None


def _build_wiki_job_payload(
    job_id: str,
    created_at: str,
    *,
    status: str,
    results: list,
    error: str,
    stage: str,
    stage_message: str,
    title: str,
    target: str,
    source_url: str,
) -> dict:
    payload = _build_job_payload(job_id, created_at, status, results, error)
    payload["target"] = target
    payload["stage"] = stage
    payload["stageMessage"] = stage_message
    payload["title"] = title
    payload["sourceType"] = "wiki"
    payload["sourceUrl"] = source_url
    return payload


def _set_wiki_job_stage(
    job_id: str,
    created_at: str,
    *,
    stage: str,
    stage_message: str,
    title: str,
    target: str,
    source_url: str,
) -> None:
    payload = _build_wiki_job_payload(
        job_id,
        created_at,
        status="running",
        results=[],
        error="",
        stage=stage,
        stage_message=stage_message,
        title=title,
        target=target,
        source_url=source_url,
    )
    _set_job(job_id, payload)


def _start_wiki_job(
    raw_url: str,
    target: str | None = None,
    *,
    cookie_header: str | None = None,
    auth_token_header: str | None = None,
) -> tuple[str | None, str | None]:
    try:
        normalized_url = normalize_wiki_url(raw_url)
    except ValueError as exc:
        return None, str(exc)

    auth = resolve_wiki_auth(cookie_header, auth_token_header)
    if not auth.get("cookie") and not auth.get("authToken"):
        return None, "当前未配置可用的 Wiki 凭证"

    job_id = uuid.uuid4().hex
    created_at = _now_iso()
    normalized_target = _normalize_target(target)
    _set_wiki_job_stage(
        job_id,
        created_at,
        stage="fetching",
        stage_message="正在抓取 Wiki 页面...",
        title="",
        target=normalized_target,
        source_url=normalized_url,
    )

    def _worker():
        title = ""
        try:
            page_id_match = re.search(r"(?:[?&]pageId=)(\d+)", normalized_url)
            page_id = page_id_match.group(1) if page_id_match else job_id[:8]
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            base_name = f"wiki_{page_id}_{ts}"

            parsed = parse_wiki_page(
                page_url=normalized_url,
                auth=auth,
                base_dir=BASE_DIR,
                base_name=base_name,
                on_progress=lambda stage, message: _set_wiki_job_stage(
                    job_id,
                    created_at,
                    stage=stage,
                    stage_message=message,
                    title=title,
                    target=normalized_target,
                    source_url=normalized_url,
                ),
            )
            title = str(parsed.get("title") or "")

            from artifact_store import store_parse_outputs

            stored_outputs = store_parse_outputs(
                BASE_DIR,
                job_id,
                {
                    "Markdown:": str(parsed["markdownPath"]),
                    "OCR Markdown:": str(parsed["ocrMarkdownPath"]),
                    "OCR JSON:": str(parsed["ocrJsonPath"]),
                },
            )

            result = {
                "error": "",
                "pageId": str(parsed.get("pageId") or ""),
                "stderr": "",
                "stdout": "",
                "target": normalized_target,
                "filename": title or f"Wiki 页面 {page_id}",
                "markdown": stored_outputs.get("Markdown:", ""),
                "ocr_json": stored_outputs.get("OCR JSON:", ""),
                "sourceUrl": normalized_url,
                "spaceName": str(parsed.get("spaceName") or ""),
                "imageCount": int(parsed.get("imageCount") or 0),
                "sourceType": "wiki",
                "pageVersion": str(parsed.get("pageVersion") or ""),
                "parentTitle": str(parsed.get("parentTitle") or ""),
                "ocr_markdown": stored_outputs.get("OCR Markdown:", ""),
            }

            final_payload = _build_wiki_job_payload(
                job_id,
                created_at,
                status="done",
                results=[result],
                error="",
                stage="done",
                stage_message="Wiki 解析完成",
                title=title,
                target=normalized_target,
                source_url=normalized_url,
            )
            _set_job(job_id, final_payload)
            _save_history_record(final_payload)
        except Exception as exc:
            final_payload = _build_wiki_job_payload(
                job_id,
                created_at,
                status="error",
                results=[],
                error=str(exc),
                stage="error",
                stage_message=str(exc) or "Wiki 解析失败",
                title=title,
                target=normalized_target,
                source_url=normalized_url,
            )
            _set_job(job_id, final_payload)
            _save_history_record(final_payload)

    threading.Thread(target=_worker, daemon=True).start()
    return job_id, None


@app.after_request
def add_cors_headers(response):
    origin = request.headers.get("Origin", "")
    if origin in ALLOWED_CORS_ORIGINS:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Vary"] = "Origin"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"
        response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        job_id, error = _start_parse_job(
            request.files.getlist("file"),
            request.form.get("target"),
        )
        if error:
            return render_template("index.html", error=error)
        # 303 强制浏览器用 GET 访问目标页，避免 POST 重定向导致 405
        return redirect(url_for("job_status_page", job_id=job_id), code=303)

    return render_template("index.html")


@app.route("/files/<path:filename>", methods=["GET", "HEAD"])
def files(filename: str):
    try:
        from artifact_store import exists, guess_mime, read_bytes

        if not exists(BASE_DIR, filename):
            abort(404)
        mime = guess_mime(filename)
        if request.method == "HEAD":
            return Response(status=200, mimetype=mime)
        return Response(read_bytes(BASE_DIR, filename), mimetype=mime)
    except FileNotFoundError:
        abort(404)
    except ValueError:
        abort(404)


@app.route("/job/<job_id>", methods=["GET"])
def job_status_page(job_id: str):
    if not _get_job(job_id):
        return render_template("index.html", error="任务不存在或已过期。")
    return render_template("job.html", job_id=job_id)


@app.route("/job/<job_id>/status", methods=["GET"])
def job_status(job_id: str):
    job = _get_job(job_id)
    if not job:
        return {"status": "error", "error": "任务不存在或已过期。"}
    return job


@app.route("/api/health", methods=["GET"])
def api_health():
    return {"success": True, "data": {"ok": True}}


@app.route("/api/history", methods=["GET"])
def api_history():
    return {"success": True, "data": _load_history_records()}


@app.route("/api/parse", methods=["POST"])
def api_parse():
    job_id, error = _start_parse_job(
        request.files.getlist("file"),
        request.form.get("target"),
    )
    if error:
        return {"success": False, "error": error}, 400
    return {
        "success": True,
        "data": {
            "jobId": job_id,
            "createdAt": (_get_job(job_id) or {}).get("createdAt"),
        },
    }, 202


@app.route("/api/jobs/<job_id>", methods=["GET"])
def api_job(job_id: str):
    job = _get_job(job_id)
    if not job:
        return {"success": False, "error": "任务不存在或已过期。"}, 404
    return {"success": True, "data": job}


@app.route("/api/file-text", methods=["GET"])
def api_file_text():
    relative_path = (request.args.get("path") or "").strip()
    if not relative_path:
        return {"success": False, "error": "缺少 path 参数。"}, 400
    try:
        from artifact_store import read_text

        text = read_text(BASE_DIR, relative_path)
    except FileNotFoundError:
        return {"success": False, "error": "文件不存在。"}, 404
    except ValueError:
        return {"success": False, "error": "文件不存在。"}, 404
    return {"success": True, "data": {"path": relative_path, "text": text}}


@app.route("/api/wiki/import", methods=["POST"])
def api_wiki_import():
    payload = request.get_json(silent=True) or {}
    raw_url = (payload.get("url") or "").strip()
    target = payload.get("target")
    if not raw_url:
        return {"success": False, "error": "请提供 Wiki 地址"}, 400
    job_id, error = _start_wiki_job(
        raw_url,
        target,
        cookie_header=request.headers.get("X-Wiki-Cookie"),
        auth_token_header=request.headers.get("X-Wiki-Auth-Token"),
    )
    if error:
        return {"success": False, "error": error}, 400
    return {
        "success": True,
        "data": {
            "jobId": job_id,
            "createdAt": (_get_job(job_id) or {}).get("createdAt"),
        },
    }, 202


@app.route("/api/wiki/jobs/<job_id>", methods=["GET"])
def api_wiki_job(job_id: str):
    job = _get_job(job_id)
    if not job:
        return {"success": False, "error": "任务不存在或已过期。"}, 404
    return {"success": True, "data": job}


@app.route("/job/<job_id>/result", methods=["GET"])
def job_result(job_id: str):
    job = _get_job(job_id)
    if not job:
        return render_template("index.html", error="任务不存在或已过期。")
    if job.get("status") == "done":
        return render_template("result.html", results=job.get("results", []))
    if job.get("status") == "error":
        return render_template("index.html", error=job.get("error", "解析失败"))
    return redirect(url_for("job_status_page", job_id=job_id))


@app.errorhandler(405)
def method_not_allowed(_e):
    """方法不允许时跳回首页"""
    return redirect(url_for("index"), code=302)


if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "5000"))
    app.run(host=host, port=port, debug=False)
