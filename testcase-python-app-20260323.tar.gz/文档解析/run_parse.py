import argparse
import base64
import io
import json
import os
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

from PIL import Image


DATA_URI_PATTERN = re.compile(
    r"!\[(?P<alt>[^\]]*)\]\(data:image/(?P<ext>png|jpg|jpeg|gif|webp);base64,(?P<data>[^)]+)\)"
)
BAD_ANCHOR_PATTERN = re.compile(
    r"\((?:%22|\")\s*\\l\s*(?:%22|\")(?P<anchor>id-[^)]+)\)"
)
MARKDOWN_LINK_PATTERN = re.compile(
    r"(?<!!)\[(?P<text>[^\]]+)\]\((?P<target>[^)]+)\)"
)
BELLA_OCR_URL = os.environ.get(
    "BELLA_OCR_URL", "http://bella-openapi.ait.ke.com/v1/ocr/general"
)
BELLA_OCR_MODEL = os.environ.get("BELLA_OCR_MODEL", "baidu-general")


def _safe_name(text: str, fallback: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("_")
    return cleaned or fallback


def run_markitdown(input_path: Path, output_md: Path) -> None:
    cmd = [
        "markitdown",
        "--keep-data-uris",
        str(input_path),
        "-o",
        str(output_md),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(result.stderr or result.stdout)


def fix_bad_anchors(md_path: Path) -> None:
    text = md_path.read_text(encoding="utf-8")
    new_text = BAD_ANCHOR_PATTERN.sub(r"(#\g<anchor>)", text)
    md_path.write_text(new_text, encoding="utf-8")


def _is_word_internal_target(target: str) -> bool:
    lowered = target.strip().lower()
    decoded = urllib.parse.unquote(lowered)
    return lowered.startswith("#id-") or ("id-" in decoded and "\\l" in decoded)


def normalize_word_internal_links(md_path: Path) -> None:
    text = md_path.read_text(encoding="utf-8")

    def _replace(match: re.Match) -> str:
        target = match.group("target")
        if _is_word_internal_target(target):
            return match.group("text")
        return match.group(0)

    new_text = MARKDOWN_LINK_PATTERN.sub(_replace, text)
    md_path.write_text(new_text, encoding="utf-8")


def extract_images(md_path: Path, images_dir: Path) -> None:
    text = md_path.read_text(encoding="utf-8")
    images_dir.mkdir(parents=True, exist_ok=True)

    counter = 0
    rel_dir = images_dir.name

    def _replace(match: re.Match) -> str:
        nonlocal counter
        counter += 1
        alt = match.group("alt") or f"image_{counter}"
        ext = match.group("ext")
        data = match.group("data")
        try:
            binary = base64.b64decode(data, validate=False)
        except Exception:
            return match.group(0)

        base_name = _safe_name(alt, f"image_{counter}")
        filename = f"{base_name}.{ext}"
        out_path = images_dir / filename
        if out_path.exists():
            out_path = images_dir / f"{base_name}_{counter}.{ext}"
        out_path.write_bytes(binary)

        rel_path = f"{rel_dir}/{out_path.name}"
        return f"![{alt}]({rel_path})"

    new_text = DATA_URI_PATTERN.sub(_replace, text)
    md_path.write_text(new_text, encoding="utf-8")


def render_pdf_to_markdown(input_path: Path, output_md: Path, images_dir: Path) -> None:
    try:
        import pypdfium2 as pdfium
    except ImportError as exc:
        raise RuntimeError(
            "缺少 pypdfium2，无法解析 PDF。请安装：pip install pypdfium2"
        ) from exc

    images_dir.mkdir(parents=True, exist_ok=True)
    pdf = pdfium.PdfDocument(str(input_path))
    markdown_lines = [f"# {input_path.stem}", ""]

    for page_index in range(len(pdf)):
        page = pdf[page_index]
        bitmap = page.render(scale=2.4)
        pil_image = bitmap.to_pil()
        image_name = f"page_{page_index + 1:03d}.png"
        image_path = images_dir / image_name
        pil_image.save(image_path)
        markdown_lines.extend(
            [
                f"## 第{page_index + 1}页",
                "",
                f"![第{page_index + 1}页]({images_dir.name}/{image_name})",
                "",
            ]
        )
        if hasattr(bitmap, "close"):
            bitmap.close()
        if hasattr(page, "close"):
            page.close()

    output_md.write_text("\n".join(markdown_lines).strip() + "\n", encoding="utf-8")


def _image_pattern(image_dir_name: str) -> re.Pattern[str]:
    return re.compile(rf"!\[[^\]]*\]\((?P<path>{re.escape(image_dir_name)}/[^)]+)\)")


def _encode_image_for_remote_ocr(img_path: Path) -> str:
    with Image.open(img_path) as opened:
        img = opened.convert("RGB")

    max_side = 2500
    w, h = img.size
    if max(w, h) > max_side:
        scale = max_side / float(max(w, h))
        new_w = max(1, int(w * scale))
        new_h = max(1, int(h * scale))
        img = img.resize((new_w, new_h), Image.BILINEAR)

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=88, optimize=True)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _extract_bella_words(payload: dict) -> list[str]:
    data = payload.get("data", {})
    if isinstance(data, dict):
        for key in ("words", "lines", "texts"):
            value = data.get(key)
            if isinstance(value, list):
                return [str(item).strip() for item in value if str(item).strip()]

        words_result = data.get("words_result")
        if isinstance(words_result, list):
            words = []
            for item in words_result:
                if isinstance(item, dict):
                    text = item.get("words") or item.get("text")
                else:
                    text = item
                if text and str(text).strip():
                    words.append(str(text).strip())
            return words

        text = data.get("text")
        if text and str(text).strip():
            return [str(text).strip()]

    return []


def _bella_headers() -> dict[str, str]:
    api_key = os.environ.get("BELLA_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("未配置 BELLA_API_KEY，无法使用 Bella OCR。")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    optional_headers = {
        "X-BELLA-SPACE-CODE": os.environ.get("BELLA_SPACE_CODE", "").strip(),
        "X-BELLA-OPERATOR-ID": os.environ.get("BELLA_OPERATOR_ID", "").strip(),
        "X-BELLA-OPERATOR-NAME": os.environ.get("BELLA_OPERATOR_NAME", "").strip(),
    }
    for key, value in optional_headers.items():
        if value:
            headers[key] = value
    return headers


def _call_bella_ocr(image_base64: str) -> str:
    body = json.dumps(
        {"model": BELLA_OCR_MODEL, "image_base64": image_base64},
        ensure_ascii=False,
    ).encode("utf-8")
    req = urllib.request.Request(
        BELLA_OCR_URL,
        data=body,
        headers=_bella_headers(),
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"Bella OCR 请求失败（HTTP {exc.code}）：{detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Bella OCR 连接失败：{exc}") from exc

    words = _extract_bella_words(payload)
    return "\n".join(words)


def run_bella_ocr(
    md_path: Path, base_dir: Path, ocr_json: Path, image_dir_name: str
) -> dict:
    text = md_path.read_text(encoding="utf-8")
    image_pattern = _image_pattern(image_dir_name)

    ocr_data = {}
    for match in image_pattern.finditer(text):
        img_rel = match.group("path")
        if img_rel in ocr_data:
            continue
        img_path = base_dir / img_rel
        if not img_path.exists():
            continue

        image_base64 = _encode_image_for_remote_ocr(img_path)
        ocr_data[img_rel] = _call_bella_ocr(image_base64)

    ocr_json.write_text(
        json.dumps(ocr_data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return ocr_data


def run_ocr(md_path: Path, base_dir: Path, ocr_json: Path, image_dir_name: str) -> dict:
    """Markdown 中引用到的图片走 Bella HTTP OCR；无图片引用时不调接口、也不要求 BELLA_API_KEY。"""
    text = md_path.read_text(encoding="utf-8")
    if not _image_pattern(image_dir_name).search(text):
        empty: dict = {}
        ocr_json.write_text(json.dumps(empty, ensure_ascii=False, indent=2), encoding="utf-8")
        return empty
    api_key = os.environ.get("BELLA_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "Markdown 中含图片需 OCR：请在运行文档解析进程的环境中配置 BELLA_API_KEY "
            "（可与主站 Node/.env 一致），并确保可访问 BELLA_OCR_URL。"
        )
    return run_bella_ocr(md_path, base_dir, ocr_json, image_dir_name)


def build_output_with_inline_ocr(
    md_path: Path, ocr_data: dict, output_ocr: Path, image_dir_name: str
) -> None:
    md_text = md_path.read_text(encoding="utf-8")
    image_pattern = _image_pattern(image_dir_name)

    def _ocr_inline(text: str) -> str:
        condensed = " ".join([line.strip() for line in text.splitlines() if line.strip()])
        return condensed

    lines = md_text.splitlines()
    out_lines = []

    for line in lines:
        matches = list(image_pattern.finditer(line))
        if not matches:
            out_lines.append(line)
            continue

        is_table_row = "|" in line

        if is_table_row:
            # Keep table intact: inline OCR after each image on same line
            new_line = line
            for match in matches:
                img_rel = match.group("path")
                ocr_text = ocr_data.get(img_rel, "")
                if not ocr_text:
                    continue
                inline_text = _ocr_inline(ocr_text)
                if inline_text:
                    new_line = new_line.replace(
                        match.group(0), f"{match.group(0)}（OCR：{inline_text}）", 1
                    )
            out_lines.append(new_line)
        else:
            # Non-table: place OCR in a separate paragraph right after the image line
            out_lines.append(line)
            for match in matches:
                img_rel = match.group("path")
                ocr_text = ocr_data.get(img_rel, "")
                if not ocr_text:
                    continue
                for ocr_line in [l.strip() for l in ocr_text.splitlines() if l.strip()]:
                    out_lines.append(f"> {ocr_line}")
            if matches:
                out_lines.append("")

    output_ocr.write_text("\n".join(out_lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Document/PDF -> Markdown + OCR workflow")
    parser.add_argument("input", help="Path to input .docx or .pdf file")
    parser.add_argument(
        "--out-dir",
        default=os.environ.get("BASE_DIR", str(Path(__file__).resolve().parent)),
        help="Output directory",
    )
    args = parser.parse_args()

    input_path = Path(args.input).expanduser().resolve()
    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    stem = _safe_name(input_path.stem, "document")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_md = out_dir / f"{stem}_{ts}.md"
    output_ocr = out_dir / f"{stem}_{ts}_ocr.md"
    ocr_json = out_dir / f"{stem}_{ts}_ocr.json"
    images_dir = out_dir / f"images_{stem}_{ts}"

    if input_path.suffix.lower() == ".pdf":
        render_pdf_to_markdown(input_path, output_md, images_dir)
    else:
        run_markitdown(input_path, output_md)
        fix_bad_anchors(output_md)
        normalize_word_internal_links(output_md)
        extract_images(output_md, images_dir)
    ocr_data = run_ocr(output_md, out_dir, ocr_json, images_dir.name)
    build_output_with_inline_ocr(output_md, ocr_data, output_ocr, images_dir.name)

    print("Done.")
    print(f"Markdown: {output_md}")
    print(f"OCR Markdown: {output_ocr}")
    print(f"OCR JSON: {ocr_json}")


if __name__ == "__main__":
    main()
