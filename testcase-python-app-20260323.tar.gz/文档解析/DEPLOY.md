# 文档解析服务部署说明

## 方式一：Docker 部署（推荐）

### 前置要求
- 已安装 [Docker](https://docs.docker.com/get-docker/) 和 [Docker Compose](https://docs.docker.com/compose/install/)

### 部署步骤

```bash
cd /Users/ssq/Desktop/文档解析

# 构建并启动
docker compose up -d --build

# 查看日志
docker compose logs -f
```

服务将在 **http://localhost:5000** 启动。

### 常用命令

```bash
# 停止服务
docker compose down

# 重启服务
docker compose restart

# 查看运行状态
docker compose ps
```

---

## 方式二：直接运行（本地开发）

### 前置要求
- Python 3.10+
- 已安装 [markitdown](https://pypi.org/project/markitdown/)（`pip install markitdown[docx]`）

### 部署步骤

```bash
cd /Users/ssq/Desktop/文档解析

# 安装依赖
pip install -r requirements.txt

# 启动服务（默认 0.0.0.0:5000，可从外网访问）
HOST=0.0.0.0 PORT=5000 python web_app.py

# 或使用 gunicorn 生产模式
gunicorn -b 0.0.0.0:5000 -w 1 --timeout 300 web_app:app
```

### 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `BASE_DIR` | 项目根目录（上传、解析输出路径） | 脚本所在目录 |
| `HOST` | 监听地址 | `0.0.0.0` |
| `PORT` | 监听端口 | `5000` |
| `BELLA_API_KEY` | **图片 OCR 必填**（Markdown 中含抽取图片时调用 Bella OCR） | 无 |
| `BELLA_OCR_URL` | Bella OCR 接口地址 | 见 `.env.example` |

> 已移除本机 PaddleOCR；无图片的 Wiki/文档可不配 Key，有图片则必须配置并可访问 `BELLA_OCR_URL`。

---

## 部署到云服务器

1. 将项目上传到服务器
2. 使用 Docker 部署：`docker compose up -d --build`
3. 配置防火墙放行 5000 端口
4. 如需域名访问，可配合 Nginx 反向代理

### Nginx 反向代理示例

```nginx
server {
    listen 80;
    server_name your-domain.com;
    client_max_body_size 200M;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 300;
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
    }
}
```
