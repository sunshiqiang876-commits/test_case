"""Artifact storage abstraction for parser outputs.

Supports:
- local filesystem (default)
- S3-compatible object storage when PARSER_STORAGE_BACKEND=s3

Logical paths stay stable across backends so existing APIs can keep using
`/api/file-text?path=...` and `/files/<path>`.
"""

from __future__ import annotations

import mimetypes
import os
from pathlib import Path
from typing import Any


def _backend() -> str:
    configured = (os.environ.get("PARSER_STORAGE_BACKEND") or "").strip().lower()
    if configured:
        return configured
    return "s3" if _bucket() else "local"


def _bucket() -> str:
    return (os.environ.get("PARSER_S3_BUCKET") or os.environ.get("S3_BUCKET") or "").strip()


def _key_prefix() -> str:
    return (os.environ.get("PARSER_S3_KEY_PREFIX") or "parser-artifacts").strip().strip("/")


def _object_key(logical_path: str) -> str:
    normalized = str(logical_path or "").replace("\\", "/").lstrip("/")
    prefix = _key_prefix()
    return f"{prefix}/{normalized}" if prefix else normalized


def _storage_uri(logical_path: str) -> str:
    if remote_enabled():
        return f"s3://{_bucket()}/{_object_key(logical_path)}"
    return f"local://{logical_path}"


def remote_enabled() -> bool:
    return _backend() == "s3" and bool(_bucket())


def _boto3_client() -> Any:
    try:
        import boto3
    except ImportError as e:
        raise RuntimeError(
            "boto3 is required for S3 parser storage. Install: pip install boto3"
        ) from e

    kwargs: dict[str, Any] = {}
    endpoint = (os.environ.get("PARSER_S3_ENDPOINT_URL") or "").strip()
    region = (os.environ.get("PARSER_S3_REGION") or os.environ.get("AWS_DEFAULT_REGION") or "").strip()
    access_key = (os.environ.get("PARSER_S3_ACCESS_KEY_ID") or os.environ.get("AWS_ACCESS_KEY_ID") or "").strip()
    secret_key = (
        os.environ.get("PARSER_S3_SECRET_ACCESS_KEY") or os.environ.get("AWS_SECRET_ACCESS_KEY") or ""
    ).strip()
    session_token = (
        os.environ.get("PARSER_S3_SESSION_TOKEN") or os.environ.get("AWS_SESSION_TOKEN") or ""
    ).strip()

    if endpoint:
        kwargs["endpoint_url"] = endpoint
    if region:
        kwargs["region_name"] = region
    if access_key and secret_key:
        kwargs["aws_access_key_id"] = access_key
        kwargs["aws_secret_access_key"] = secret_key
    if session_token:
        kwargs["aws_session_token"] = session_token
    return boto3.client("s3", **kwargs)


def _safe_resolve(base_dir: Path, logical_path: str) -> Path:
    resolved = (base_dir / logical_path).resolve()
    base = base_dir.resolve()
    if base not in resolved.parents and resolved != base:
        raise ValueError("Path outside base directory")
    return resolved


def _guess_mime(logical_path: str) -> str:
    mime, _ = mimetypes.guess_type(logical_path)
    return mime or "application/octet-stream"


def _record_artifact(parse_job_id: str, kind: str, logical_path: str) -> None:
    try:
        from parser_persistence import artifact_upsert

        artifact_upsert(
            parse_job_id=parse_job_id,
            kind=kind,
            logical_path=logical_path,
            storage_uri=_storage_uri(logical_path),
            filename=Path(logical_path).name,
            mime_type=_guess_mime(logical_path),
        )
    except Exception:
        pass


def store_relative_path(base_dir: Path, parse_job_id: str, logical_path: str, kind: str) -> str:
    logical = str(logical_path or "").replace("\\", "/").lstrip("/")
    if not logical:
        return ""
    file_path = _safe_resolve(base_dir, logical)
    if not file_path.exists() or not file_path.is_file():
        return logical

    if remote_enabled():
        client = _boto3_client()
        client.upload_file(str(file_path), _bucket(), _object_key(logical))

    _record_artifact(parse_job_id, kind, logical)
    return logical


def store_directory(base_dir: Path, parse_job_id: str, logical_dir: str, kind: str) -> None:
    logical_root = str(logical_dir or "").replace("\\", "/").strip("/").lstrip("/")
    if not logical_root:
        return
    dir_path = _safe_resolve(base_dir, logical_root)
    if not dir_path.exists() or not dir_path.is_dir():
        return
    for child in dir_path.rglob("*"):
        if child.is_file():
            rel = str(child.relative_to(base_dir.resolve())).replace("\\", "/")
            store_relative_path(base_dir, parse_job_id, rel, kind)


def store_parse_outputs(base_dir: Path, parse_job_id: str, outputs: dict[str, Any]) -> dict[str, str]:
    """Upload parser outputs and related images to the active backend.

    Returns the logical relative paths that should be stored in job payload/history.
    """

    out: dict[str, str] = {}
    for label, kind in (
        ("Markdown:", "markdown"),
        ("OCR Markdown:", "ocr_markdown"),
        ("OCR JSON:", "ocr_json"),
    ):
        raw_path = str(outputs.get(label) or "").strip()
        if not raw_path:
            continue
        try:
            logical = str(Path(raw_path).resolve().relative_to(base_dir.resolve())).replace("\\", "/")
        except Exception:
            logical = Path(raw_path).name
        out[label] = store_relative_path(base_dir, parse_job_id, logical, kind)

    markdown_path = out.get("Markdown:")
    if markdown_path:
        images_dir = f"images_{Path(markdown_path).stem}"
        store_directory(base_dir, parse_job_id, images_dir, "image")

    return out


def exists(base_dir: Path, logical_path: str) -> bool:
    logical = str(logical_path or "").replace("\\", "/").lstrip("/")
    if not logical:
        return False
    if remote_enabled():
        client = _boto3_client()
        try:
            client.head_object(Bucket=_bucket(), Key=_object_key(logical))
            return True
        except Exception:
            pass
    try:
        return _safe_resolve(base_dir, logical).exists()
    except Exception:
        return False


def read_bytes(base_dir: Path, logical_path: str) -> bytes:
    logical = str(logical_path or "").replace("\\", "/").lstrip("/")
    if not logical:
        raise FileNotFoundError(logical)
    if remote_enabled():
        client = _boto3_client()
        try:
            response = client.get_object(Bucket=_bucket(), Key=_object_key(logical))
            return response["Body"].read()
        except Exception:
            pass
    file_path = _safe_resolve(base_dir, logical)
    if not file_path.exists() or not file_path.is_file():
        raise FileNotFoundError(logical)
    return file_path.read_bytes()


def read_text(base_dir: Path, logical_path: str) -> str:
    data = read_bytes(base_dir, logical_path)
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="ignore")


def guess_mime(logical_path: str) -> str:
    return _guess_mime(logical_path)
