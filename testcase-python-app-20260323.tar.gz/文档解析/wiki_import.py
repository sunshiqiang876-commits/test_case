from __future__ import annotations

import mimetypes
import os
import re
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, urljoin, urlparse

import httpx
from bs4 import BeautifulSoup
from markdownify import markdownify as html_to_markdown


ALLOWED_WIKI_HOSTS = frozenset({"wiki.lianjia.com"})
WIKI_HTML_ACCEPT = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
ProgressCallback = Callable[[str, str], None]


def normalize_optional_string(value: str | None) -> str:
    return str(value or "").strip()


def normalize_wiki_cookie(cookie: str | None) -> str:
    raw = normalize_optional_string(cookie)
    if raw.lower().startswith("cookie:"):
        raw = raw[7:].strip()
    if not raw:
        return ""
    parts = [part.strip() for part in raw.split(";") if part.strip()]
    preferred = [
        part
        for part in parts
        if re.match(r"^JSESSIONID=", part, re.I) or re.match(r"^seraph\.confluence=", part, re.I)
    ]
    return "; ".join(preferred if preferred else parts)


def normalize_wiki_auth_token(value: str | None) -> str:
    raw = normalize_optional_string(value)
    if raw.lower().startswith("bearer "):
        return raw[7:].strip()
    return raw


def resolve_wiki_auth(cookie_header: str | None = None, auth_token_header: str | None = None) -> dict[str, str]:
    cookie = normalize_wiki_cookie(cookie_header) or normalize_wiki_cookie(os.environ.get("WIKI_COOKIE", ""))
    auth_token = normalize_wiki_auth_token(auth_token_header) or normalize_wiki_auth_token(
        os.environ.get("WIKI_AUTH_TOKEN", "")
    )
    return {
        "cookie": cookie,
        "authToken": auth_token,
    }


def build_wiki_request_headers(auth: dict[str, str]) -> dict[str, str]:
    headers = {
        "Accept": WIKI_HTML_ACCEPT,
        "User-Agent": "Mozilla/5.0 Wiki Parser",
    }
    if auth.get("cookie"):
        headers["Cookie"] = auth["cookie"]
    if auth.get("authToken"):
        headers["Authorization"] = f"Bearer {auth['authToken']}"
    return headers


def normalize_wiki_url(raw_url: str) -> str:
    raw = normalize_optional_string(raw_url)
    try:
        parsed = urlparse(raw)
    except Exception:
        raise ValueError("请输入有效的 Wiki 地址") from None
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("仅支持 http/https 的 Wiki 地址")
    if parsed.hostname not in ALLOWED_WIKI_HOSTS:
        raise ValueError("当前仅支持 wiki.lianjia.com 地址")
    return raw


def looks_like_wiki_login_html(html_text: str) -> bool:
    lower = (html_text or "").lower()
    return "seraph" in lower and "login" in lower


def _notify_progress(callback: ProgressCallback | None, stage: str, message: str) -> None:
    if not callback:
        return
    try:
        callback(stage, message)
    except Exception:
        pass


def _safe_name(text: str, fallback: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", str(text or "")).strip("._")
    return cleaned or fallback


def _extract_page_id(soup: BeautifulSoup, page_url: str) -> str:
    for name in ("ajs-page-id", "page-id"):
        value = _extract_meta_content(soup, name)
        if value:
            return value
    query_page_id = parse_qs(urlparse(page_url).query).get("pageId", [])
    return normalize_optional_string(query_page_id[0] if query_page_id else "")


def _extract_meta_content(soup: BeautifulSoup, name: str) -> str:
    meta = soup.find("meta", attrs={"name": name}) or soup.find("meta", attrs={"property": name})
    if not meta:
        return ""
    return normalize_optional_string(meta.get("content"))


def _extract_page_title(soup: BeautifulSoup) -> str:
    candidates = [
        _extract_meta_content(soup, "ajs-page-title"),
        _extract_meta_content(soup, "og:title"),
    ]
    title_el = soup.select_one("#title-text")
    if title_el:
        candidates.append(title_el.get_text(" ", strip=True))
    if soup.title:
        candidates.append(re.sub(r"\s*-\s*Confluence\s*$", "", soup.title.get_text(" ", strip=True)))
    for value in candidates:
        value = normalize_optional_string(value)
        if value:
            return value
    return "Wiki 页面"


def _select_content_root(soup: BeautifulSoup):
    for selector in ("#main-content", ".wiki-content", "main", "body"):
        node = soup.select_one(selector)
        if node is not None:
            return node
    return soup


def _strip_noise(root: BeautifulSoup) -> None:
    for node in root.select("script, style, noscript, button"):
        node.decompose()
    for selector in (
        ".pageSection.group .pageSectionHeader",
        ".pageSection.group .pageSectionFooter",
        ".content-navigation",
        ".wiki-content-sidebar",
    ):
        for node in root.select(selector):
            node.decompose()


def _rewrite_links_absolute(root: BeautifulSoup, page_url: str) -> None:
    for link in root.find_all("a", href=True):
        href = normalize_optional_string(link.get("href"))
        if not href or href.startswith("#") or href.lower().startswith("javascript:"):
            continue
        link["href"] = urljoin(page_url, href)


def _guess_image_extension(response: httpx.Response, image_url: str) -> str:
    path_ext = Path(urlparse(image_url).path).suffix.lower()
    if path_ext in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}:
        return path_ext
    content_type = normalize_optional_string(response.headers.get("content-type")).split(";", 1)[0].strip()
    guessed = mimetypes.guess_extension(content_type) or ""
    if guessed == ".jpe":
        return ".jpg"
    if guessed in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}:
        return guessed
    return ".png"


def _download_inline_images(
    root: BeautifulSoup, page_url: str, auth: dict[str, str], images_dir: Path
) -> int:
    images_dir.mkdir(parents=True, exist_ok=True)
    fetched: dict[str, str] = {}
    with httpx.Client(
        headers=build_wiki_request_headers(auth),
        follow_redirects=True,
        timeout=60.0,
    ) as client:
        for index, image in enumerate(root.find_all("img"), start=1):
            raw_src = normalize_optional_string(image.get("data-image-src")) or normalize_optional_string(
                image.get("src")
            )
            if not raw_src:
                continue
            absolute_src = urljoin(page_url, raw_src)
            if absolute_src in fetched:
                image["src"] = fetched[absolute_src]
                image.attrs.pop("data-image-src", None)
                continue
            try:
                response = client.get(absolute_src)
            except Exception:
                continue
            if not response.is_success or not response.content:
                continue
            alt = (
                normalize_optional_string(image.get("alt"))
                or normalize_optional_string(image.get("data-linked-resource-default-alias"))
                or f"image_{index}"
            )
            ext = _guess_image_extension(response, absolute_src)
            base_name = _safe_name(alt, f"image_{index}")
            file_path = images_dir / f"{base_name}{ext}"
            suffix = 1
            while file_path.exists():
                file_path = images_dir / f"{base_name}_{suffix}{ext}"
                suffix += 1
            file_path.write_bytes(response.content)
            relative_path = f"{images_dir.name}/{file_path.name}"
            fetched[absolute_src] = relative_path
            image["src"] = relative_path
            image.attrs.pop("data-image-src", None)
    return sum(
        1
        for image in root.find_all("img")
        if normalize_optional_string(image.get("src")).startswith(f"{images_dir.name}/")
    )


def _strip_duplicate_title(markdown_text: str, title: str) -> str:
    text = str(markdown_text or "").strip()
    normalized_title = normalize_optional_string(title)
    if not text or not normalized_title:
        return text
    pattern = rf"^#\s+{re.escape(normalized_title)}\s*\n+"
    return re.sub(pattern, "", text, count=1, flags=re.IGNORECASE)


def _build_markdown_document(
    *,
    title: str,
    source_url: str,
    page_id: str,
    space_name: str,
    parent_title: str,
    page_version: str,
    body_markdown: str,
) -> str:
    lines = [f"# {title}", ""]
    lines.append(f"> 来源：{source_url}")
    if page_id:
        lines.append(f"> 页面ID：{page_id}")
    if space_name:
        lines.append(f"> 空间：{space_name}")
    if parent_title:
        lines.append(f"> 父页面：{parent_title}")
    if page_version:
        lines.append(f"> 页面版本：{page_version}")
    lines.append("")
    if body_markdown:
        lines.append(body_markdown.strip())
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def parse_wiki_page(
    *,
    page_url: str,
    auth: dict[str, str],
    base_dir: Path,
    base_name: str,
    on_progress: ProgressCallback | None = None,
) -> dict[str, Any]:
    normalized_url = normalize_wiki_url(page_url)
    if not auth.get("cookie") and not auth.get("authToken"):
        raise RuntimeError("当前未配置可用的 Wiki 凭证")

    with httpx.Client(
        headers=build_wiki_request_headers(auth),
        follow_redirects=True,
        timeout=45.0,
    ) as client:
        response = client.get(normalized_url)

    html_text = response.text
    final_host = normalize_optional_string(urlparse(str(response.url)).hostname)
    login_reason = normalize_optional_string(response.headers.get("x-seraph-loginreason"))
    if response.status_code in {401, 403}:
        raise RuntimeError(f"Wiki 鉴权失败（HTTP {response.status_code}）")
    if (
        final_host
        and final_host not in ALLOWED_WIKI_HOSTS
        or looks_like_wiki_login_html(html_text)
        or (login_reason and login_reason != "OK")
    ):
        raise RuntimeError("当前 Wiki 凭证已失效或未登录，请更新 cookie 后重试")
    if not response.is_success:
        raise RuntimeError(f"读取 Wiki 页面失败（HTTP {response.status_code}）")

    _notify_progress(on_progress, "converting", "Wiki 抓取完成，正在解析正文结构...")
    soup = BeautifulSoup(html_text, "html.parser")
    title = _extract_page_title(soup)
    page_id = _extract_page_id(soup, normalized_url)
    space_name = _extract_meta_content(soup, "ajs-space-name")
    parent_title = _extract_meta_content(soup, "ajs-parent-page-title")
    page_version = _extract_meta_content(soup, "ajs-page-version")

    content_root = _select_content_root(soup)
    content = BeautifulSoup(str(content_root), "html.parser")
    _strip_noise(content)
    _rewrite_links_absolute(content, str(response.url))

    markdown_path = base_dir / f"{base_name}.md"
    ocr_markdown_path = base_dir / f"{base_name}_ocr.md"
    ocr_json_path = base_dir / f"{base_name}_ocr.json"
    images_dir = base_dir / f"images_{base_name}"
    image_count = _download_inline_images(content, str(response.url), auth, images_dir)

    body_markdown = html_to_markdown(
        str(content),
        heading_style="ATX",
        bullets="-",
        strong_em_symbol="*",
    )
    body_markdown = re.sub(r"\n{3,}", "\n\n", body_markdown).strip()
    body_markdown = _strip_duplicate_title(body_markdown, title)
    if not body_markdown and image_count == 0:
        raise RuntimeError("Wiki 页面没有可解析的正文内容")

    markdown_path.write_text(
        _build_markdown_document(
            title=title,
            source_url=normalized_url,
            page_id=page_id,
            space_name=space_name,
            parent_title=parent_title,
            page_version=page_version,
            body_markdown=body_markdown,
        ),
        encoding="utf-8",
    )

    from run_parse import build_output_with_inline_ocr, run_ocr

    if image_count > 0:
        _notify_progress(on_progress, "ocr", f"检测到 {image_count} 张图片，正在识别图片内容...")
    else:
        _notify_progress(on_progress, "finalizing", "当前页面没有图片，正在整理 Markdown 内容...")
    ocr_data = run_ocr(markdown_path, base_dir, ocr_json_path, images_dir.name)
    if image_count > 0:
        _notify_progress(on_progress, "finalizing", "图片识别完成，正在整理 Markdown 内容...")
    build_output_with_inline_ocr(markdown_path, ocr_data, ocr_markdown_path, images_dir.name)

    return {
        "title": title,
        "pageId": page_id,
        "spaceName": space_name,
        "parentTitle": parent_title,
        "pageVersion": page_version,
        "imageCount": image_count,
        "sourceUrl": normalized_url,
        "markdownPath": markdown_path,
        "ocrMarkdownPath": ocr_markdown_path,
        "ocrJsonPath": ocr_json_path,
    }
