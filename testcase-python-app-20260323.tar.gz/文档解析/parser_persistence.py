"""
Optional Postgres persistence for parse job payloads + history snapshot.
When DATABASE_URL is set, mirrors JOBS and parse_history to the tables created by
python_server/db/migrations/001_initial.sql and 002_parse_history_snapshot.sql.
"""

from __future__ import annotations

import json
import os
from typing import Any


def _dsn() -> str:
    return (os.environ.get("DATABASE_URL") or "").strip()


def _psycopg():
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError:
        return None, None
    return psycopg, dict_row


def history_load() -> list[dict[str, Any]] | None:
    """Return history entries from DB, or None to fall back to JSON file."""
    dsn = _dsn()
    if not dsn:
        return None
    psycopg, dict_row = _psycopg()
    if not psycopg:
        return None
    try:
        with psycopg.connect(dsn, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT entries FROM parse_history_snapshot WHERE id = 1")
                row = cur.fetchone()
        if not row:
            return None
        entries = row["entries"]
        if isinstance(entries, list):
            return [x for x in entries if isinstance(x, dict)]
        return []
    except Exception:
        return None


def history_save(records: list[dict[str, Any]], *, limit: int = 120) -> None:
    dsn = _dsn()
    if not dsn:
        return
    psycopg, _ = _psycopg()
    if not psycopg:
        return
    payload = json.dumps(records[:limit], ensure_ascii=False)
    try:
        with psycopg.connect(dsn) as conn:
            conn.execute(
                """
                INSERT INTO parse_history_snapshot (id, entries)
                VALUES (1, %s::jsonb)
                ON CONFLICT (id) DO UPDATE SET entries = EXCLUDED.entries
                """,
                (payload,),
            )
    except Exception:
        pass


def job_upsert(payload: dict[str, Any]) -> None:
    dsn = _dsn()
    if not dsn:
        return
    job_id = str(payload.get("id") or "")
    if not job_id:
        return
    psycopg, _ = _psycopg()
    if not psycopg:
        return
    pj = json.dumps(payload, ensure_ascii=False)
    status = str(payload.get("status") or "")
    stage = str(payload.get("stage") or "")
    stage_message = str(payload.get("stageMessage") or "")
    title = str(payload.get("title") or "")
    error = str(payload.get("error") or "")
    source_type = str(payload.get("sourceType") or "")
    source_url = str(payload.get("sourceUrl") or "")
    target = str(payload.get("target") or "")
    created = payload.get("createdAt")
    try:
        with psycopg.connect(dsn) as conn:
            conn.execute(
                """
                INSERT INTO parse_jobs (
                    job_id, workspace_id, status, stage, stage_message, title, error,
                    source_type, source_url, target, payload_json, created_at, updated_at
                )
                VALUES (
                    %s, '00000000-0000-0000-0000-000000000001'::uuid,
                    %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s::timestamptz, NOW()
                )
                ON CONFLICT (job_id) DO UPDATE SET
                    status = EXCLUDED.status,
                    stage = EXCLUDED.stage,
                    stage_message = EXCLUDED.stage_message,
                    title = EXCLUDED.title,
                    error = EXCLUDED.error,
                    source_type = EXCLUDED.source_type,
                    source_url = EXCLUDED.source_url,
                    target = EXCLUDED.target,
                    payload_json = EXCLUDED.payload_json,
                    updated_at = NOW()
                """,
                (
                    job_id,
                    status,
                    stage,
                    stage_message,
                    title,
                    error,
                    source_type,
                    source_url,
                    target,
                    pj,
                    created,
                ),
            )
    except Exception:
        pass


def job_get(job_id: str) -> dict[str, Any] | None:
    dsn = _dsn()
    if not dsn:
        return None
    psycopg, dict_row = _psycopg()
    if not psycopg:
        return None
    try:
        with psycopg.connect(dsn, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT payload_json FROM parse_jobs WHERE job_id = %s",
                    (job_id,),
                )
                row = cur.fetchone()
        if not row:
            return None
        data = row["payload_json"]
        if isinstance(data, dict):
            return data
        if isinstance(data, str):
            return json.loads(data)
    except Exception:
        return None
    return None


def artifact_upsert(
    *,
    parse_job_id: str,
    kind: str,
    logical_path: str,
    storage_uri: str,
    filename: str,
    mime_type: str | None = None,
) -> None:
    dsn = _dsn()
    if not dsn or not parse_job_id or not logical_path:
        return
    psycopg, _ = _psycopg()
    if not psycopg:
        return
    try:
        with psycopg.connect(dsn) as conn:
            conn.execute(
                """
                INSERT INTO parse_artifacts (
                    parse_job_id, kind, logical_path, storage_uri, filename, mime_type
                )
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (parse_job_id, kind, logical_path) DO UPDATE SET
                    storage_uri = EXCLUDED.storage_uri,
                    filename = EXCLUDED.filename,
                    mime_type = EXCLUDED.mime_type
                """,
                (
                    parse_job_id,
                    kind,
                    logical_path,
                    storage_uri,
                    filename,
                    mime_type,
                ),
            )
    except Exception:
        pass
