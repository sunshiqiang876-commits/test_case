# 测试用例生成应用

根据 PRD 和 Tech 输入，调用 Bella Workflow 生成测试用例。

## 快速开始

1. 复制环境变量配置：

```bash
cp .env.example .env
```

2. 编辑 `.env`，填入真实的 Bella API 配置：

```bash
BELLA_API_KEY=你的API密钥
BELLA_TENANT_ID=04633c4f-8638-43a3-a02e-af23c29f821f
BELLA_WORKFLOW_ID=WKFL-89c53071-d8f8-4127-a28d-4a0bb5ae3512
BELLA_BASE_URL=https://openapi-ait.ke.com/v1
BELLA_USER_ID=1000123
BELLA_USER_NAME=测试用户
```

3. 安装依赖并启动：

```bash
npm install
npm start
```

4. 在浏览器访问：http://localhost:3000（若端口被占用，可在 `.env` 中设置 `PORT=3001` 等）

## 接口说明

- `POST /api/testcase/generate` — 生成测试用例
- 请求体：`{ "prd": "...", "tech": "..." }`
- 返回：`{ "success": true, "data": { "outputs": { "text": "..." } } }`

## 注意事项

- API Key 仅保存在后端 `.env` 中，不会出现在前端代码
- Bella 试用额度限制：每分钟最多 5 次，并行数不超过 1
