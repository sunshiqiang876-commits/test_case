const form = document.getElementById("form");
const prdInput = document.getElementById("prd");
const techInput = document.getElementById("tech");
const submitBtn = document.getElementById("submitBtn");
const homeLayout = document.getElementById("homeLayout");
const progressSection = document.getElementById("progressSection");
const progressStatus = document.getElementById("progressStatus");
const progressIntro = document.getElementById("progressIntro");
const progressIntroHint = document.getElementById("progressIntroHint");
const progressStageList = document.getElementById("progressStageList");
const progressTerminal = document.getElementById("progressTerminal");
const progressTerminalTitle = document.getElementById("progressTerminalTitle");
const progressTerminalOutput = document.getElementById("progressTerminalOutput");
const progressCancelBtn = document.getElementById("progressCancelBtn");
const resultSection = document.getElementById("resultSection");
const regenerateBtn = document.getElementById("regenerateBtn");
const toMindmapBtnHeader = document.getElementById("toMindmapBtnHeader");
const resultContent = document.getElementById("resultContent");
const resultStatus = document.getElementById("resultStatus");
const errorBox = document.getElementById("errorBox");
const errorText = document.getElementById("errorText");
const openSavedPairBtn = document.getElementById("openSavedPairBtn");
const savedPairMenu = document.getElementById("savedPairMenu");
const savedPairMenuList = document.getElementById("savedPairMenuList");
const openParsedDocBtn = document.getElementById("openParsedDocBtn");
const parsedDocMenu = document.getElementById("parsedDocMenu");
const parsedDocMenuList = document.getElementById("parsedDocMenuList");
const homeListLoading = document.getElementById("homeListLoading");
const homeListEmpty = document.getElementById("homeListEmpty");
const homeResultList = document.getElementById("homeResultList");
const homeModal = document.getElementById("homeModal");
const homeModalBackdrop = document.getElementById("homeModalBackdrop");
const homeModalClose = document.getElementById("homeModalClose");
const homeDetailMeta = document.getElementById("homeDetailMeta");
const homeDetailOutput = document.getElementById("homeDetailOutput");
const DOC_PARSER_API_BASE = "";
const LEGACY_PENDING_GENERATION_KEY = "testcase_pending_generation_v1";
const PENDING_GENERATIONS_KEY = "testcase_pending_generations_v2";
const ACTIVE_PENDING_REQUEST_KEY = "testcase_active_pending_request_v1";
const RECOVER_POLL_INTERVAL_MS = 2500;
const RECOVER_TIMEOUT_MS = 12 * 60 * 60 * 1000;
let recoverTimer = null;
let savedPairs = [];
let parsedDocRefs = [];
let isGenerating = false;
let isRecovering = false;
let activeGenerationContext = null;

function setHomeView(view) {
  homeLayout?.classList.toggle("has-progress", view === "progress");
  homeLayout?.classList.toggle("has-result", view === "result");
  if (progressSection) progressSection.hidden = view !== "progress";
  if (resultSection) resultSection.hidden = view !== "result";
}

function setResultVisible(visible) {
  setHomeView(visible ? "result" : "form");
  if (!visible && toMindmapBtnHeader) {
    toMindmapBtnHeader.hidden = true;
  }
}

function setProgressVisible(visible) {
  setHomeView(visible ? "progress" : "form");
}

function resetResultView() {
  setResultVisible(false);
  if (resultStatus) resultStatus.textContent = "";
  if (resultContent) {
    resultContent.innerHTML =
      '<p class="placeholder">填写需求文档和设计文档后，点击「生成测试用例」获取结果</p>';
  }
}

function resetProgressView() {
  setProgressVisible(false);
  if (progressStatus) progressStatus.textContent = "";
  if (progressIntro) progressIntro.textContent = "正在准备工作流任务，请稍候...";
  if (progressIntroHint) progressIntroHint.hidden = true;
  if (progressStageList) progressStageList.innerHTML = "";
  if (progressTerminal) progressTerminal.hidden = true;
  if (progressTerminalTitle) progressTerminalTitle.textContent = "生成失败";
  if (progressTerminalOutput) progressTerminalOutput.textContent = "";
  if (progressCancelBtn) {
    progressCancelBtn.hidden = false;
    progressCancelBtn.disabled = false;
    progressCancelBtn.textContent = "中止生成";
  }
}

async function ensureNotificationPermission() {
  if (typeof window === "undefined" || !("Notification" in window)) return false;
  // Notification API requires secure context (https) or localhost.
  if (!window.isSecureContext) return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") return false;
  try {
    return (await Notification.requestPermission()) === "granted";
  } catch {
    return false;
  }
}

function notifyGenerationDone(success, message) {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  const title = success ? "测试用例生成完成" : "测试用例生成失败";
  const body = message || (success ? "点击页面查看生成结果" : "请返回页面查看失败原因");
  try {
    const n = new Notification(title, { body });
    n.onclick = () => window.focus();
  } catch {
    // Ignore notification errors.
  }
}

function getOutputText(outputs) {
  if (!outputs) return "";
  if (typeof outputs.text === "string") return outputs.text;
  if (typeof outputs.result === "string") return outputs.result;
  return "";
}

function normalizeEscapedNewlines(text) {
  if (typeof text !== "string") return text;
  return text
    .replace(/\\r\\n/g, "\n")
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\n");
}

function formatTime(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString("zh-CN");
  } catch {
    return iso || "-";
  }
}

function formatLeafNodeCount(value) {
  return Number.isFinite(value) ? String(value) : "-";
}

function getStageStatusLabel(status) {
  if (status === "succeeded") return "成功";
  if (status === "timed_out") return "超时";
  if (status === "retrying") return "重试中";
  if (status === "running") return "进行中";
  if (status === "failed") return "失败";
  if (status === "hidden") return "未触发";
  return "待执行";
}

function formatStageSummaryText(stageSummary) {
  if (!stageSummary || typeof stageSummary !== "object") return "";
  return Object.values(stageSummary)
    .map((stage) => {
      const parts = [stage?.label || "-", getStageStatusLabel(stage?.status)];
      if (Number.isFinite(stage?.retryCount) && stage.retryCount > 0) {
        parts.push(`重试 ${stage.retryCount} 次`);
      }
      if (stage?.workflowRunId) {
        parts.push(`Workflow Run ID: ${stage.workflowRunId}`);
      }
      if (stage?.message) {
        parts.push(stage.message);
      }
      return parts.join(" · ");
    })
    .join("\n");
}

function decodeBase64Utf8(value) {
  if (!value || typeof value !== "string") return "";
  try {
    const binary = atob(value);
    const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
    return new TextDecoder().decode(bytes);
  } catch {
    return "";
  }
}

function readUrlParamText(params, plainKey, base64Key) {
  const base64Value = params.get(base64Key);
  if (base64Value) return decodeBase64Utf8(base64Value);
  return params.get(plainKey) || "";
}

function applyMarkdownPrefill(text, target = "") {
  const normalizedMd = normalizeEscapedNewlines(text || "");
  if (!normalizedMd) return false;
  if (target === "prd") {
    prdInput.value = normalizedMd;
    return true;
  }
  if (target === "tech") {
    techInput.value = normalizedMd;
    return true;
  }
  if (target === "both") {
    prdInput.value = normalizedMd;
    techInput.value = normalizedMd;
    return true;
  }
  if (!prdInput.value.trim()) {
    prdInput.value = normalizedMd;
  } else if (!techInput.value.trim()) {
    techInput.value = normalizedMd;
  } else {
    prdInput.value = normalizedMd;
  }
  return true;
}

function applyPrefillFromUrl() {
  if (typeof window === "undefined") return;
  const params = new URLSearchParams(window.location.search);
  if (!params.toString()) return;

  const prdText = readUrlParamText(params, "prd", "prd64");
  const techText = readUrlParamText(params, "tech", "tech64");
  const mdText = readUrlParamText(params, "md", "md64") || readUrlParamText(params, "markdown", "markdown64");
  const target = (params.get("target") || "").toLowerCase();
  let applied = false;

  if (prdText) {
    prdInput.value = normalizeEscapedNewlines(prdText);
    applied = true;
  }
  if (techText) {
    techInput.value = normalizeEscapedNewlines(techText);
    applied = true;
  }
  if (mdText) {
    applied = applyMarkdownPrefill(mdText, target) || applied;
  }

  if (applied) {
    // Keep URL clean after prefill and avoid re-applying on refresh.
    const cleanUrl = window.location.pathname + window.location.hash;
    window.history.replaceState({}, "", cleanUrl);
  }
}

function updateButtonState() {
  const prd = (prdInput.value || "").trim();
  const tech = (techInput.value || "").trim();
  const busy = isGenerating || isRecovering;
  submitBtn.disabled = busy || !prd || !tech;
  submitBtn.classList.toggle("loading", busy);
  submitBtn.textContent = busy ? "生成中..." : "生成测试用例";
}

prdInput.addEventListener("input", updateButtonState);
techInput.addEventListener("input", updateButtonState);

function showError(msg) {
  errorBox.hidden = false;
  errorText.textContent = msg;
}

function hideError() {
  errorBox.hidden = true;
  errorText.textContent = "";
}

function setGeneratingState(loading) {
  isGenerating = loading;
  if (loading) {
    isRecovering = false;
    hideError();
  }
  updateButtonState();
}

function setRecoveringState(recovering) {
  isRecovering = recovering;
  if (recovering) {
    isGenerating = false;
  }
  updateButtonState();
}

function isSameGenerationContext(context) {
  return Boolean(
    context &&
    activeGenerationContext &&
    activeGenerationContext.clientRequestId === context.clientRequestId
  );
}

function clearActiveGenerationContext(context) {
  if (isSameGenerationContext(context)) {
    activeGenerationContext = null;
  }
}

function normalizeTextForCompare(text) {
  return String(text || "").replace(/\r\n/g, "\n").trim();
}

function truncate(str, len = 40) {
  if (!str || typeof str !== "string") return "";
  return str.length <= len ? str : str.slice(0, len) + "…";
}

function createClientRequestId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `req-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function setActivePendingRequestId(requestId) {
  try {
    if (requestId) {
      sessionStorage.setItem(ACTIVE_PENDING_REQUEST_KEY, requestId);
    } else {
      sessionStorage.removeItem(ACTIVE_PENDING_REQUEST_KEY);
    }
  } catch {}
}

function getActivePendingRequestId() {
  try {
    return sessionStorage.getItem(ACTIVE_PENDING_REQUEST_KEY) || "";
  } catch {
    return "";
  }
}

function readLegacyPendingGeneration() {
  try {
    const raw = localStorage.getItem(LEGACY_PENDING_GENERATION_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data || !data.prd || !data.tech || !data.startAt) return null;
    return {
      ...data,
      clientRequestId: data.clientRequestId || `legacy-${data.startAt}`,
    };
  } catch {
    return null;
  }
}

function readPendingGenerationList() {
  try {
    const raw = localStorage.getItem(PENDING_GENERATIONS_KEY);
    if (!raw) {
      const legacy = readLegacyPendingGeneration();
      return legacy ? [legacy] : [];
    }
    const data = JSON.parse(raw);
    if (!Array.isArray(data)) return [];
    return data.filter((item) => item && item.prd && item.tech && item.startAt);
  } catch {
    const legacy = readLegacyPendingGeneration();
    return legacy ? [legacy] : [];
  }
}

function writePendingGenerationList(items) {
  try {
    const next = Array.isArray(items) ? items : [];
    if (next.length) {
      localStorage.setItem(PENDING_GENERATIONS_KEY, JSON.stringify(next));
    } else {
      localStorage.removeItem(PENDING_GENERATIONS_KEY);
    }
    localStorage.removeItem(LEGACY_PENDING_GENERATION_KEY);
  } catch {}
}

function closeSavedPairMenu() {
  if (!savedPairMenu) return;
  savedPairMenu.hidden = true;
}

function renderSavedPairMenu() {
  if (!savedPairMenuList) return;
  savedPairMenuList.innerHTML = "";
  if (!savedPairs.length) {
    const emptyItem = document.createElement("li");
    emptyItem.className = "saved-pair-item-empty";
    emptyItem.textContent = "暂无历史输入组合";
    savedPairMenuList.appendChild(emptyItem);
    return;
  }
  savedPairs.slice(0, 30).forEach((pair, idx) => {
    const li = document.createElement("li");
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "saved-pair-item-btn";
    btn.textContent = `${idx + 1}. ${truncate(pair.prd || "", 24)} | ${truncate(pair.tech || "", 24)}`;
    btn.addEventListener("click", () => {
      applySavedPairByIndex(idx);
      closeSavedPairMenu();
    });
    li.appendChild(btn);
    savedPairMenuList.appendChild(li);
  });
}

async function loadSavedPairs() {
  try {
    const res = await fetch("/api/testcase/pairs");
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data)) return;
    savedPairs = data.data;
    renderSavedPairMenu();
  } catch {
    // Ignore loading errors silently; core flow should stay available.
  }
}

function inferParsedDocTarget(filename) {
  const lower = String(filename || "").toLowerCase();
  if (lower.includes("__tech_") || lower.includes("tech")) return "tech";
  if (lower.includes("__prd_") || lower.includes("prd")) return "prd";
  return "";
}

function normalizeDocRefIdentity(value) {
  return String(value || "").trim().toLowerCase();
}

function buildParsedDocRefKey(item) {
  const sourceType = normalizeDocRefIdentity(item?.sourceType || "upload");
  const sourceUrl = normalizeDocRefIdentity(item?.sourceUrl);
  const filename = normalizeDocRefIdentity(item?.filename);
  const target = normalizeDocRefIdentity(item?.defaultTarget);
  if (sourceType === "wiki" && sourceUrl) {
    return `wiki:${sourceUrl}:${target}`;
  }
  if (filename) {
    return `${sourceType}:${filename}:${target}`;
  }
  return `${sourceType}:${normalizeDocRefIdentity(item?.ocrMarkdownPath)}:${target}`;
}

function dedupeParsedDocRefs(items) {
  const seen = new Set();
  return items.filter((item) => {
    const key = buildParsedDocRefKey(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function flattenParsedDocRefs(records) {
  if (!Array.isArray(records)) return [];
  return dedupeParsedDocRefs(
    records.flatMap((record) => {
      const createdAt = record?.createdAt || "";
      const results = Array.isArray(record?.results) ? record.results : [];
      return results
        .filter((result) => result?.ocr_markdown && !result?.error)
        .map((result, idx) => ({
          id: `${record.id || "record"}:${idx}`,
          createdAt,
          filename: result.filename || result.ocr_markdown || `解析结果 ${idx + 1}`,
          ocrMarkdownPath: result.ocr_markdown,
          defaultTarget: inferParsedDocTarget(result.filename || result.ocr_markdown),
          sourceType: result.sourceType || record?.sourceType || "upload",
          sourceUrl: result.sourceUrl || record?.sourceUrl || "",
        }));
    })
  );
}

function renderParsedDocMenu() {
  if (!parsedDocMenuList) return;
  parsedDocMenuList.innerHTML = "";
  if (!parsedDocRefs.length) {
    const emptyItem = document.createElement("li");
    emptyItem.className = "saved-pair-item-empty";
    emptyItem.textContent = "暂无可引用的文档解析结果";
    parsedDocMenuList.appendChild(emptyItem);
    return;
  }
  parsedDocRefs.slice(0, 30).forEach((item, idx) => {
    const li = document.createElement("li");
    li.className = "doc-ref-item";
    const recommendedLabel =
      item.defaultTarget === "tech"
        ? "推荐填入：技术文档"
        : item.defaultTarget === "prd"
          ? "推荐填入：需求文档"
          : "可填入任一输入框";
    li.innerHTML = `
      <div class="doc-ref-title">${escapeHtml(truncate(item.filename || "", 44))}</div>
      <div class="doc-ref-meta">${escapeHtml(formatTime(item.createdAt))} · ${escapeHtml(recommendedLabel)}</div>
      <div class="doc-ref-actions">
        <button type="button" class="btn btn-outline parsed-doc-apply-btn" data-index="${idx}" data-target="prd">填需求</button>
        <button type="button" class="btn btn-outline parsed-doc-apply-btn" data-index="${idx}" data-target="tech">填技术</button>
      </div>
    `;
    parsedDocMenuList.appendChild(li);
  });
  parsedDocMenuList.querySelectorAll(".parsed-doc-apply-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const idx = Number(btn.getAttribute("data-index"));
      const target = btn.getAttribute("data-target") || "prd";
      await applyParsedDocByIndex(idx, target);
    });
  });
}

async function loadParsedDocRefs() {
  const res = await fetch(`${DOC_PARSER_API_BASE}/api/history`);
  const data = await res.json();
  if (!res.ok || !data?.success || !Array.isArray(data.data)) {
    throw new Error(data?.error || "文档解析结果加载失败");
  }
  parsedDocRefs = flattenParsedDocRefs(data.data);
  renderParsedDocMenu();
}

function closeParsedDocMenu() {
  if (!parsedDocMenu) return;
  parsedDocMenu.hidden = true;
}

async function fetchParsedDocText(path) {
  const res = await fetch(`${DOC_PARSER_API_BASE}/api/file-text?path=${encodeURIComponent(path)}`);
  const data = await res.json();
  if (!res.ok || !data?.success) {
    throw new Error(data?.error || "读取 OCR Markdown 失败");
  }
  return data.data?.text || "";
}

async function applyParsedDocByIndex(idx, target) {
  if (!Number.isInteger(idx) || idx < 0 || idx >= parsedDocRefs.length) return;
  const item = parsedDocRefs[idx];
  try {
    const text = await fetchParsedDocText(item.ocrMarkdownPath);
    if (!applyMarkdownPrefill(text, target || item.defaultTarget || "prd")) {
      showError("选中的文档解析结果没有可填充的文本");
      return;
    }
    hideError();
    updateButtonState();
    closeParsedDocMenu();
  } catch (err) {
    showError(`引用文档解析结果失败：${err.message || "网络错误"}`);
  }
}

function applySavedPairByIndex(idx) {
  if (!Number.isInteger(idx) || idx < 0 || idx >= savedPairs.length) return;
  const pair = savedPairs[idx];
  prdInput.value = pair.prd || "";
  techInput.value = pair.tech || "";
  updateButtonState();
}

function openSavedPairPicker() {
  if (!savedPairMenu) return;
  if (savedPairMenu.hidden) {
    closeParsedDocMenu();
    renderSavedPairMenu();
    savedPairMenu.hidden = false;
    if (!savedPairs.length) {
      showError("暂无可用的历史输入组合");
    }
  } else {
    closeSavedPairMenu();
  }
}

async function openParsedDocPicker() {
  if (!parsedDocMenu) return;
  if (!parsedDocMenu.hidden) {
    closeParsedDocMenu();
    return;
  }
  closeSavedPairMenu();
  parsedDocMenu.hidden = false;
  if (parsedDocMenuList) {
    parsedDocMenuList.innerHTML = '<li class="saved-pair-item-empty">加载中...</li>';
  }
  try {
    await loadParsedDocRefs();
    if (!parsedDocRefs.length) {
      showError("暂无可引用的文档解析结果");
    }
  } catch (err) {
    parsedDocRefs = [];
    renderParsedDocMenu();
    showError(err.message || "文档解析结果加载失败");
  }
}

function onDocClickCloseSavedPairMenu(event) {
  if (!event.target) return;
  const target = event.target;
  if (!(target instanceof Node)) return;
  if (
    savedPairMenu &&
    !savedPairMenu.hidden &&
    !savedPairMenu.contains(target) &&
    !openSavedPairBtn?.contains(target)
  ) {
    closeSavedPairMenu();
  }
  if (
    parsedDocMenu &&
    !parsedDocMenu.hidden &&
    !parsedDocMenu.contains(target) &&
    !openParsedDocBtn?.contains(target)
  ) {
    closeParsedDocMenu();
  }
}

function onDocKeydownCloseSavedPairMenu(event) {
  if (event.key === "Escape") {
    closeSavedPairMenu();
    closeParsedDocMenu();
  }
}

function getItemStatus(item) {
  return item?.status === "failed" ? "failed" : "succeeded";
}

function closeHomeModal() {
  if (!homeModal) return;
  homeModal.hidden = true;
  document.removeEventListener("keydown", onHomeModalEscape);
}

function onHomeModalEscape(e) {
  if (e.key === "Escape") closeHomeModal();
}

async function openHomeDetail(id) {
  if (!homeModal || !homeDetailMeta || !homeDetailOutput) return;
  try {
    const res = await fetch(`/api/testcase/${id}`);
    const data = await res.json();
    if (!data.success || !data.data) {
      showError("获取详情失败");
      return;
    }
    const item = data.data;
    const status = getItemStatus(item);
    const stageSummaryText = formatStageSummaryText(item.stageSummary || item.outputs?.stageSummary);
    homeDetailMeta.innerHTML = `
      <p><strong>结果 ID：</strong><code class="result-id-copy" title="点击复制">${escapeHtml(item.id || "-")}</code></p>
      <p><strong>Client 请求 ID：</strong>${escapeHtml(item.clientRequestId || "-")}</p>
      <p><strong>生成时间：</strong>${escapeHtml(formatTime(item.createdAt))}</p>
      <p><strong>Workflow Run ID：</strong>${escapeHtml(item.workflowRunId || "-")}</p>
      <p><strong>初始 AI 叶子节点数：</strong>${escapeHtml(formatLeafNodeCount(item.leafNodeCount))}</p>
      <p><strong>状态：</strong>${status === "failed" ? "生成失败" : "生成成功"}</p>
      ${stageSummaryText ? `
      <details class="detail-inputs">
        <summary>工作流阶段</summary>
        <pre>${escapeHtml(stageSummaryText)}</pre>
      </details>` : ""}
      <details class="detail-inputs">
        <summary>需求文档 / 设计文档 输入</summary>
        <pre>${escapeHtml(`需求文档:\n${item.prd || ""}\n\n设计文档:\n${item.tech || ""}`)}</pre>
      </details>
    `;
    const text = normalizeEscapedNewlines(getOutputText(item.outputs || {}) || "");
    if (text) {
      homeDetailOutput.innerHTML = `<pre class="output-text">${escapeHtml(text)}</pre>`;
    } else {
      const rawStr = JSON.stringify(item.outputs || {}, null, 2);
      homeDetailOutput.innerHTML = `<pre class="output-text">${escapeHtml(rawStr)}</pre>`;
    }
    homeModal.hidden = false;
    document.addEventListener("keydown", onHomeModalEscape);
  } catch (err) {
    showError("获取详情失败：" + (err.message || "网络错误"));
  }
}

function openItemInMindmap(item) {
  const text = normalizeEscapedNewlines(getOutputText(item.outputs || {}) || "");
  const payload = text || JSON.stringify(item.outputs || {}, null, 2);
  if (!payload) return;
  sessionStorage.setItem("mindmapMarkdown", payload);
  window.location.href = "/mindmap";
}

function removeHomePendingPlaceholder() {
  homeResultList?.querySelectorAll('[data-home-pending="1"]').forEach((item) => item.remove());
}

function appendHomePendingPlaceholder(pending = readPendingGeneration(), options = {}) {
  if (!homeResultList) return;
  removeHomePendingPlaceholder();
  if (!pending) return;
  const { prepend = false } = options;
  const li = document.createElement("li");
  li.className = "list-item list-item-pending";
  li.dataset.homePending = "1";
  li.innerHTML = `
    <div class="list-item-main">
      <span class="list-item-time">生成中</span>
      <p class="list-item-preview">正在生成测试用例，请稍候…</p>
    </div>
  `;
  if (prepend) {
    homeResultList.prepend(li);
    return;
  }
  homeResultList.appendChild(li);
}

function showHomePendingPlaceholderImmediately(pending) {
  if (!pending) return;
  if (homeListLoading) homeListLoading.hidden = true;
  if (homeListEmpty) homeListEmpty.hidden = true;
  appendHomePendingPlaceholder(pending, { prepend: true });
}

async function loadHomeList() {
  if (!homeResultList || !homeListLoading || !homeListEmpty) return;
  homeListLoading.hidden = false;
  homeListEmpty.hidden = true;
  homeResultList.innerHTML = "";
  appendHomePendingPlaceholder();
  try {
    const res = await fetch("/api/testcase/list");
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data)) {
      homeListEmpty.hidden = false;
      homeListEmpty.textContent = "加载失败";
      return;
    }
    const items = data.data.slice(0, 20);
    if (!items.length && !readPendingGeneration()) {
      homeListEmpty.hidden = false;
      homeListEmpty.textContent = "暂无历史记录";
      return;
    }
    items.forEach((item) => {
      const status = getItemStatus(item);
      const li = document.createElement("li");
      li.className = `list-item ${status === "failed" ? "list-item-failed" : ""}`;
      const text = normalizeEscapedNewlines(getOutputText(item.outputs || {}) || "");
      const canOpenMindmap = status !== "failed" && Boolean((text || "").trim());
      li.innerHTML = `
        <div class="list-item-main">
          <span class="list-item-time">${escapeHtml(formatTime(item.createdAt))} ${
            status === "failed" ? '<span class="status-badge status-failed">生成失败</span>' : ""
          }</span>
          <p class="list-item-preview">${escapeHtml(text ? truncate(text, 100) : "(无文本输出)")}</p>
        </div>
        <div class="list-item-actions ${status === "failed" ? "list-item-actions-center" : ""}">
          ${canOpenMindmap ? '<button type="button" class="btn btn-outline home-item-mindmap-btn">生成思维导图</button>' : ""}
          <button type="button" class="btn btn-outline home-item-detail-btn">查看</button>
        </div>
      `;
      li.querySelector(".home-item-detail-btn")?.addEventListener("click", () => openHomeDetail(item.id));
      li.querySelector(".home-item-mindmap-btn")?.addEventListener("click", () => openItemInMindmap(item));
      homeResultList.appendChild(li);
    });
  } catch (err) {
    homeListEmpty.hidden = false;
    homeListEmpty.textContent = "加载失败：" + (err.message || "网络错误");
  } finally {
    homeListLoading.hidden = true;
  }
}

function savePendingGeneration(payload) {
  const item = {
    ...payload,
    clientRequestId: payload.clientRequestId || createClientRequestId(),
    startAt: Number(payload.startAt || Date.now()),
  };
  const next = readPendingGenerationList().filter((entry) => entry.clientRequestId !== item.clientRequestId);
  next.unshift(item);
  writePendingGenerationList(next.slice(0, 20));
  setActivePendingRequestId(item.clientRequestId);
  return item;
}

function readPendingGeneration() {
  const list = readPendingGenerationList();
  if (!list.length) return null;
  const activeRequestId = getActivePendingRequestId();
  if (activeRequestId) {
    const matched = list.find((item) => item.clientRequestId === activeRequestId);
    if (matched) return matched;
  }
  return list[0] || null;
}

function clearPendingGeneration(clientRequestId) {
  const activeRequestId = clientRequestId || getActivePendingRequestId();
  if (!activeRequestId) {
    writePendingGenerationList([]);
    setActivePendingRequestId("");
    return;
  }
  const next = readPendingGenerationList().filter((item) => item.clientRequestId !== activeRequestId);
  writePendingGenerationList(next);
  if (getActivePendingRequestId() === activeRequestId) {
    setActivePendingRequestId(next[0]?.clientRequestId || "");
  }
}

function updatePendingGeneration(clientRequestId, patch = {}) {
  if (!clientRequestId) return null;
  const next = readPendingGenerationList().map((item) => {
    if (item.clientRequestId !== clientRequestId) return item;
    return { ...item, ...patch };
  });
  writePendingGenerationList(next);
  return next.find((item) => item.clientRequestId === clientRequestId) || null;
}

function getProgressStageClass(stage) {
  if (!stage) return "pending";
  const isFallbackStage = stage.key === "businessFallback" || stage.key === "elementMatchFallback";
  if (isFallbackStage && (stage.status === "running" || stage.status === "retrying")) {
    return "fallback_running";
  }
  if (stage.status === "succeeded") return "success";
  if (stage.status === "timed_out") return "timeout";
  if (stage.status === "retrying") return "retrying";
  if (stage.status === "failed") return "failed";
  if (stage.status === "running") return "running";
  return "pending";
}

function buildProgressStageMeta(stage) {
  const parts = [];
  if (stage?.message) parts.push(stage.message);
  if (Number.isFinite(stage?.retryCount) && stage.retryCount > 0) {
    parts.push(`已重试 ${stage.retryCount} 次`);
  }
  return parts.join(" · ");
}

function createPendingProgressJob(jobId = "", currentStageLabel = "正在准备工作流任务") {
  return {
    id: jobId,
    status: "running",
    currentStageLabel,
    stages: [
      { key: "testPoint", label: "测试点提取中", status: "pending", message: "" },
      { key: "elements", label: "元素提取中", status: "pending", message: "" },
      { key: "business", label: "业务逻辑生成中", status: "pending", message: "" },
      { key: "elementMatch", label: "元素匹配中", status: "pending", message: "" },
    ],
  };
}

function renderProgressStages(stages) {
  if (!progressStageList) return;
  const items = Array.isArray(stages) ? stages : [];
  progressStageList.innerHTML = items
    .map((stage) => {
      const stageClass = getProgressStageClass(stage);
      const meta = buildProgressStageMeta(stage);
      return `
        <li class="progress-stage-item is-${escapeHtml(stageClass)}">
          <span class="progress-stage-dot" aria-hidden="true"></span>
          <div class="progress-stage-body">
            <p class="progress-stage-title">${escapeHtml(stage?.label || "")}</p>
            ${meta ? `<p class="progress-stage-meta">${escapeHtml(meta)}</p>` : ""}
          </div>
        </li>
      `;
    })
    .join("");
}

function getProgressTerminalText(job) {
  const outputs = job?.result?.outputs || {};
  const text = normalizeEscapedNewlines(getOutputText(outputs) || "");
  if (text) return text;
  if (typeof outputs?.error === "string" && outputs.error.trim()) return outputs.error;
  if (typeof job?.error === "string" && job.error.trim()) return job.error;
  return "生成失败";
}

function renderProgressJob(job) {
  if (!job) return;
  setProgressVisible(true);
  if (progressStatus) {
    const statusParts = [];
    if (job?.currentStageLabel) statusParts.push(job.currentStageLabel);
    progressStatus.textContent = statusParts.join(" · ");
  }
  if (progressIntro) {
    if (job.status === "failed") {
      progressIntro.textContent = "本次生成失败，可查看下方阶段状态和失败原因。";
    } else if (job.status === "cancelled") {
      progressIntro.textContent = "本次生成已中止。";
    } else if (job.status === "done") {
      progressIntro.textContent = "测试用例已生成，正在同步结果...";
    } else {
      progressIntro.textContent = "已进入生成流程，页面会自动刷新阶段进度。";
    }
  }
  if (progressIntroHint) {
    progressIntroHint.hidden = job.status !== "running";
  }
  renderProgressStages(job.stages || []);
  if (progressTerminal) {
    progressTerminal.hidden = job.status !== "failed";
  }
  if (progressTerminalTitle) {
    progressTerminalTitle.textContent = "生成失败";
  }
  if (progressTerminalOutput) {
    progressTerminalOutput.textContent = job.status === "failed" ? getProgressTerminalText(job) : "";
  }
  if (progressCancelBtn) {
    progressCancelBtn.hidden = job.status !== "running";
    progressCancelBtn.disabled = false;
    progressCancelBtn.textContent = "中止生成";
  }
}

async function fetchPendingJobById(jobId) {
  const res = await fetch(`/api/testcase/jobs/${encodeURIComponent(jobId)}`);
  const data = await res.json();
  if (!res.ok || !data?.success || !data.data) {
    throw new Error(data?.message || data?.error || "生成任务加载失败");
  }
  return data.data;
}

async function fetchPendingJobByClientRequestId(clientRequestId) {
  const res = await fetch(`/api/testcase/jobs/by-client/${encodeURIComponent(clientRequestId)}`);
  const data = await res.json();
  if (!res.ok || !data?.success || !data.data) {
    throw new Error(data?.message || data?.error || "生成任务加载失败");
  }
  return data.data;
}

async function requestCancelJob(jobId, clientRequestId) {
  const candidates = [];
  if (jobId) {
    candidates.push(`/api/testcase/jobs/${encodeURIComponent(jobId)}/cancel`);
  }
  if (clientRequestId) {
    candidates.push(`/api/testcase/jobs/by-client/${encodeURIComponent(clientRequestId)}/cancel`);
  }
  let lastError = null;
  for (const url of candidates) {
    try {
      const res = await fetch(url, { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data?.success) {
        return data.data || null;
      }
      if (res.status === 404) {
        lastError = null;
        continue;
      }
      throw new Error(data?.message || data?.error || "中止生成失败");
    } catch (error) {
      lastError = error;
    }
  }
  if (!jobId && clientRequestId) {
    await new Promise((resolve) => setTimeout(resolve, 400));
    const res = await fetch(`/api/testcase/jobs/by-client/${encodeURIComponent(clientRequestId)}/cancel`, {
      method: "POST",
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok && data?.success) {
      return data.data || null;
    }
    if (res.status !== 404) {
      throw new Error(data?.message || data?.error || "中止生成失败");
    }
  }
  if (lastError) throw lastError;
  return null;
}

function finalizeSuccessfulJob(job, notifyEnabled = false, recovered = false) {
  const result = job?.result || {};
  clearPendingGeneration(job?.clientRequestId);
  stopRecoverPolling();
  setGeneratingState(false);
  setRecoveringState(false);
  resetProgressView();
  hideError();
  showResult(true, result.outputs || {});
  loadHomeList();
  resultStatus.innerHTML =
    '<a href="/list">已保存，查看历史</a>' +
    (recovered ? " · 已恢复生成进度" : "");
  if (Array.isArray(job?.warnings) && job.warnings.length) {
    showError(`提醒：${job.warnings.join("；")}`);
  }
  if (notifyEnabled) {
    const message = job?.warnings?.length
      ? `${job.warnings.join("；")}，测试用例已生成`
      : "测试用例已生成";
    notifyGenerationDone(true, message);
  }
}

function finalizeFailedJob(job, notifyEnabled = false) {
  clearPendingGeneration(job?.clientRequestId);
  stopRecoverPolling();
  setGeneratingState(false);
  setRecoveringState(false);
  resetProgressView();
  loadHomeList();
  showError(getProgressTerminalText(job));
  prdInput.focus();
  updateButtonState();
  if (notifyEnabled) {
    notifyGenerationDone(false, job?.error || "生成失败");
  }
}

function finalizeCancelledJob(job, showMessage = true) {
  clearPendingGeneration(job?.clientRequestId);
  stopRecoverPolling();
  setGeneratingState(false);
  setRecoveringState(false);
  resetProgressView();
  loadHomeList();
  if (showMessage) {
    showError(job?.error || "已中止当前生成");
  }
}

async function cancelCurrentGeneration(showMessage = true) {
  if (!isGenerating && !isRecovering && !activeGenerationContext) return;
  stopRecoverPolling();
  const pending = readPendingGeneration();
  const activeRequestId =
    activeGenerationContext?.clientRequestId || pending?.clientRequestId || getActivePendingRequestId();
  if (activeGenerationContext) {
    activeGenerationContext.cancelled = true;
    activeGenerationContext.controller?.abort();
    activeGenerationContext = null;
  }
  let cancelError = "";
  if (progressCancelBtn) {
    progressCancelBtn.disabled = true;
    progressCancelBtn.textContent = "中止中...";
  }
  try {
    if (activeRequestId) {
      await requestCancelJob(pending?.jobId || "", activeRequestId);
    }
  } catch (error) {
    cancelError = error?.message || "中止生成失败";
  }
  clearPendingGeneration(activeRequestId);
  setGeneratingState(false);
  setRecoveringState(false);
  resetProgressView();
  loadHomeList();
  if (showMessage) {
    showError(
      cancelError
        ? `已停止本地进度跟踪，但服务端返回：${cancelError}`
        : "已中止当前生成，可再次发起生成"
    );
  }
}

function stopRecoverPolling() {
  if (recoverTimer) {
    clearInterval(recoverTimer);
    recoverTimer = null;
  }
}

function findRecoveredRecord(items, pending) {
  if (!Array.isArray(items) || !pending) return null;
  if (pending.clientRequestId) {
    const exactMatch = items.find((item) => item.clientRequestId === pending.clientRequestId);
    if (exactMatch) return exactMatch;
  }
  const prd = normalizeTextForCompare(pending.prd);
  const tech = normalizeTextForCompare(pending.tech);
  const startAt = Number(pending.startAt || 0);
  return items.find((item) => {
    const samePrd = normalizeTextForCompare(item.prd) === prd;
    const sameTech = normalizeTextForCompare(item.tech) === tech;
    if (!samePrd || !sameTech) return false;
    const createdAtMs = item.createdAt ? new Date(item.createdAt).getTime() : 0;
    return !startAt || !createdAtMs || createdAtMs >= startAt - 5000;
  });
}

async function resolvePendingJob(pending) {
  if (!pending) return null;
  if (pending.jobId) {
    try {
      return await fetchPendingJobById(pending.jobId);
    } catch {
      // Fall through to requestId lookup.
    }
  }
  if (pending.clientRequestId) {
    try {
      const job = await fetchPendingJobByClientRequestId(pending.clientRequestId);
      if (job?.id && !pending.jobId) {
        updatePendingGeneration(pending.clientRequestId, { jobId: job.id });
      }
      return job;
    } catch {
      return null;
    }
  }
  return null;
}

function startRecoverPolling(notifyEnabled = false) {
  const pending = readPendingGeneration();
  if (!pending) return;
  if (recoverTimer) return;

  prdInput.value = pending.prd || prdInput.value;
  techInput.value = pending.tech || techInput.value;
  renderProgressJob(createPendingProgressJob(pending.jobId || "", "正在恢复生成进度"));
  setRecoveringState(true);

  const tick = async () => {
    const latestPending = readPendingGeneration();
    if (!latestPending) {
      stopRecoverPolling();
      setRecoveringState(false);
      return;
    }

    const now = Date.now();
    if (now - Number(latestPending.startAt || 0) > RECOVER_TIMEOUT_MS) {
      stopRecoverPolling();
      clearPendingGeneration(latestPending.clientRequestId);
      setRecoveringState(false);
      resetProgressView();
      showError("生成查询超时，请到历史记录确认结果或重新生成");
      return;
    }

    try {
      const job = await resolvePendingJob(latestPending);
      if (job) {
        updatePendingGeneration(latestPending.clientRequestId, { jobId: job.id });
        if (job.status === "done") {
          finalizeSuccessfulJob(job, notifyEnabled, true);
          return;
        }
        if (job.status === "cancelled") {
          finalizeCancelledJob(job, true);
          return;
        }
        if (job.status === "failed") {
          finalizeFailedJob(job, notifyEnabled);
          return;
        }
        renderProgressJob(job);
        return;
      }

      const res = await fetch("/api/testcase/list");
      const data = await res.json();
      if (!data.success || !Array.isArray(data.data)) return;
      const record = findRecoveredRecord(data.data, latestPending);
      if (!record) return;

      if (record.status === "failed") {
        finalizeFailedJob(
          {
            clientRequestId: latestPending.clientRequestId,
            error: getOutputText(record.outputs || {}) || record.outputs?.error || "生成失败",
            result: {
              outputs: record.outputs || {},
              workflowRunId: record.workflowRunId,
              leafNodeCount: record.leafNodeCount,
            },
            stages: [],
          },
          notifyEnabled
        );
        return;
      }

      finalizeSuccessfulJob(
        {
          clientRequestId: latestPending.clientRequestId,
          result: {
            outputs: record.outputs || {},
            workflowRunId: record.workflowRunId,
            leafNodeCount: record.leafNodeCount,
          },
          warnings: [],
        },
        notifyEnabled,
        true
      );
    } catch {
      // Keep polling; transient network errors are expected.
    }
  };

  void tick();
  recoverTimer = setInterval(() => {
    void tick();
  }, RECOVER_POLL_INTERVAL_MS);
}

function showResult(success, outputs) {
  setResultVisible(true);
  if (resultStatus) resultStatus.textContent = "";
  if (!success) {
    const text = getOutputText(outputs);
    const normalizedText = normalizeEscapedNewlines(text || "");
    const displayText = normalizedText || JSON.stringify(outputs || {}, null, 2);
    resultContent.innerHTML = `
      <p class="output-text" style="color:#b91c1c;margin-bottom:0.5rem">生成失败</p>
      <pre class="output-text">${escapeHtml(displayText || "生成失败")}</pre>
    `;
    return;
  }
  const text = getOutputText(outputs);
  const normalizedText = normalizeEscapedNewlines(text || "");
  const displayText = normalizedText || JSON.stringify(outputs || {}, null, 2);
  const canOpenMindmap = Boolean((normalizedText || "").trim());
  resultContent.innerHTML = `<pre class="output-text">${escapeHtml(displayText)}</pre>`;

  if (toMindmapBtnHeader) {
    toMindmapBtnHeader.hidden = !canOpenMindmap;
    toMindmapBtnHeader.onclick = null;
    if (canOpenMindmap) {
      toMindmapBtnHeader.onclick = () => {
        const payload = normalizedText || displayText;
        if (!payload) { showError("当前结果无可转换内容"); return; }
        sessionStorage.setItem("mindmapMarkdown", payload);
        window.location.href = "/mindmap";
      };
    }
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (isGenerating || isRecovering) return;
  const prd = (prdInput.value || "").trim();
  const tech = (techInput.value || "").trim();

  if (!prd || !tech) {
    showError("请填写需求文档和设计文档");
    return;
  }

  // Ask permission during user interaction and wait to avoid race conditions.
  const notifyEnabled = await ensureNotificationPermission();
  if (!notifyEnabled && "Notification" in window && !window.isSecureContext) {
    showError("当前不是安全上下文（需 HTTPS 或 localhost），浏览器通知不可用");
  }
  stopRecoverPolling();
  resetResultView();
  resetProgressView();
  const pending = savePendingGeneration({ prd, tech, clientRequestId: createClientRequestId() });
  showHomePendingPlaceholderImmediately(pending);
  const generationContext = {
    clientRequestId: pending.clientRequestId,
    controller: new AbortController(),
    cancelled: false,
  };
  activeGenerationContext = generationContext;
  setGeneratingState(true);
  renderProgressJob(createPendingProgressJob("", "正在创建生成任务"));
  try {
    const res = await fetch("/api/testcase/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prd, tech, clientRequestId: pending.clientRequestId }),
      signal: generationContext.controller.signal,
    });

    const data = await res.json();
    if (generationContext.cancelled) return;

    if (!res.ok || !data?.success) {
      clearPendingGeneration(pending.clientRequestId);
      clearActiveGenerationContext(generationContext);
      setGeneratingState(false);
      resetProgressView();
      let errMsg = data.error || data.message || "生成失败";
      if (data.rawResponse) {
        errMsg += "\n\n--- Bella 原始响应 ---\n" + JSON.stringify(data.rawResponse, null, 2);
      }
      showError(errMsg);
      loadHomeList();
      if (notifyEnabled) notifyGenerationDone(false, data.error || data.message || "生成失败");
      return;
    }

    clearActiveGenerationContext(generationContext);
    setGeneratingState(false);
    setRecoveringState(true);
    const jobId = data.data?.jobId || data.data?.job?.id || "";
    updatePendingGeneration(pending.clientRequestId, { jobId });
    renderProgressJob(data.data?.job || createPendingProgressJob(jobId, "正在进入生成流程"));
    startRecoverPolling(notifyEnabled);
  } catch (err) {
    if (generationContext.cancelled) return;
    clearActiveGenerationContext(generationContext);
    // Request may fail on refresh/tab switch while server still running.
    setGeneratingState(false);
    setRecoveringState(true);
    renderProgressJob(createPendingProgressJob("", "请求中断，正在继续查询生成状态"));
    showError("请求中断，正在继续查询生成状态...");
    startRecoverPolling(notifyEnabled);
    if (notifyEnabled) notifyGenerationDone(false, "请求中断，已开始继续查询生成状态");
  } finally {
    clearActiveGenerationContext(generationContext);
  }
});

homeModalBackdrop?.addEventListener("click", (e) => {
  e.stopPropagation();
  closeHomeModal();
});
homeModalClose?.addEventListener("click", (e) => {
  e.preventDefault();
  closeHomeModal();
});

openSavedPairBtn?.addEventListener("click", (e) => {
  e.preventDefault();
  e.stopPropagation();
  openSavedPairPicker();
});
openParsedDocBtn?.addEventListener("click", async (e) => {
  e.preventDefault();
  e.stopPropagation();
  await openParsedDocPicker();
});
document.addEventListener("click", onDocClickCloseSavedPairMenu);
document.addEventListener("keydown", onDocKeydownCloseSavedPairMenu);

document.addEventListener("click", (e) => {
  const el = e.target.closest(".result-id-copy");
  if (!el || !el.textContent?.trim()) return;
  const text = el.textContent.trim();
  if (!navigator.clipboard?.writeText) return;
  e.preventDefault();
  navigator.clipboard.writeText(text).then(() => {
    el.classList.add("is-copied");
    setTimeout(() => el.classList.remove("is-copied"), 900);
  });
});

regenerateBtn?.addEventListener("click", () => {
  resetResultView();
  resetProgressView();
  hideError();
  prdInput.focus();
  updateButtonState();
});
progressCancelBtn?.addEventListener("click", async () => {
  await cancelCurrentGeneration(true);
});

applyPrefillFromUrl();
updateButtonState();
loadSavedPairs();
loadHomeList();
resetResultView();
resetProgressView();
startRecoverPolling(false);
