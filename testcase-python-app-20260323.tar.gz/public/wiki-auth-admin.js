(function () {
  const ADMIN_SECRET_HEADER = "X-Wiki-Admin-Secret";
  const PROMPT_KEYS = [
    "testPoint",
    "elements",
    "business",
    "businessFallback",
    "elementMatch",
    "elementMatchFallback",
  ];

  const elements = {
    adminSecret: document.getElementById("adminSecret"),
    updatedBy: document.getElementById("updatedBy"),
    wikiCookie: document.getElementById("wikiCookie"),
    wikiAuthToken: document.getElementById("wikiAuthToken"),
    verifyUrl: document.getElementById("verifyUrl"),
    refreshStatusBtn: document.getElementById("refreshStatusBtn"),
    saveAuthBtn: document.getElementById("saveAuthBtn"),
    verifyAuthBtn: document.getElementById("verifyAuthBtn"),
    loadPromptConfigBtn: document.getElementById("loadPromptConfigBtn"),
    savePromptConfigBtn: document.getElementById("savePromptConfigBtn"),
    statusFeedback: document.getElementById("statusFeedback"),
    saveFeedback: document.getElementById("saveFeedback"),
    verifyFeedback: document.getElementById("verifyFeedback"),
    promptConfigFeedback: document.getElementById("promptConfigFeedback"),
    statusSource: document.getElementById("statusSource"),
    statusAdminSecret: document.getElementById("statusAdminSecret"),
    statusCookieConfigured: document.getElementById("statusCookieConfigured"),
    statusCookieMasked: document.getElementById("statusCookieMasked"),
    statusTokenConfigured: document.getElementById("statusTokenConfigured"),
    statusTokenMasked: document.getElementById("statusTokenMasked"),
    statusUpdatedAt: document.getElementById("statusUpdatedAt"),
    statusUpdatedBy: document.getElementById("statusUpdatedBy"),
    verifyHttpStatus: document.getElementById("verifyHttpStatus"),
    verifyFinalUrl: document.getElementById("verifyFinalUrl"),
    verifyTitle: document.getElementById("verifyTitle"),
    verifyUser: document.getElementById("verifyUser"),
    promptOverrideCount: document.getElementById("promptOverrideCount"),
    promptUpdatedAt: document.getElementById("promptUpdatedAt"),
    promptUpdatedBy: document.getElementById("promptUpdatedBy"),
    promptFields: {
      testPoint: document.getElementById("promptTestPoint"),
      elements: document.getElementById("promptElements"),
      business: document.getElementById("promptBusiness"),
      businessFallback: document.getElementById("promptBusinessFallback"),
      elementMatch: document.getElementById("promptElementMatch"),
      elementMatchFallback: document.getElementById("promptElementMatchFallback"),
      knowledgeBase: document.getElementById("promptKnowledgeBase"),
    },
    promptSources: {
      testPoint: document.getElementById("promptSourceTestPoint"),
      elements: document.getElementById("promptSourceElements"),
      business: document.getElementById("promptSourceBusiness"),
      businessFallback: document.getElementById("promptSourceBusinessFallback"),
      elementMatch: document.getElementById("promptSourceElementMatch"),
      elementMatchFallback: document.getElementById("promptSourceElementMatchFallback"),
      knowledgeBase: document.getElementById("promptSourceKnowledgeBase"),
    },
    genProviderLabel: document.getElementById("genProviderLabel"),
    genEffectiveModel: document.getElementById("genEffectiveModel"),
    genEffectiveThinking: document.getElementById("genEffectiveThinking"),
    genChatModel: document.getElementById("genChatModel"),
    genThinkingLevel: document.getElementById("genThinkingLevel"),
  };

  function getAdminSecret() {
    return String(elements.adminSecret?.value || "").trim();
  }

  function getJsonHeaders(includeJsonContentType) {
    const secret = getAdminSecret();
    if (!secret) {
      throw new Error("请先输入管理员口令");
    }
    const headers = {
      [ADMIN_SECRET_HEADER]: secret,
    };
    if (includeJsonContentType) {
      headers["Content-Type"] = "application/json";
    }
    return headers;
  }

  function setFeedback(target, message, type) {
    if (!target) return;
    target.hidden = !message;
    target.className = "admin-feedback";
    if (!message) {
      target.textContent = "";
      return;
    }
    if (type === "error") {
      target.classList.add("is-error");
    } else if (type === "success") {
      target.classList.add("is-success");
    } else {
      target.classList.add("is-info");
    }
    target.textContent = message;
  }

  function formatTime(value) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString("zh-CN", { hour12: false });
  }

  function renderAuthStatus(status) {
    elements.statusSource.textContent =
      status?.source === "runtime"
        ? "运行时配置"
        : status?.source === "env"
          ? "环境变量兜底"
          : "未配置";
    elements.statusAdminSecret.textContent = status?.adminSecretConfigured
      ? status?.adminSecretSource === "env"
        ? "环境变量覆盖"
        : "使用默认口令"
      : "未配置";
    elements.statusCookieConfigured.textContent = status?.cookieConfigured ? "已配置" : "未配置";
    elements.statusCookieMasked.textContent = status?.cookieMasked || "-";
    elements.statusTokenConfigured.textContent = status?.authTokenConfigured ? "已配置" : "未配置";
    elements.statusTokenMasked.textContent = status?.authTokenMasked || "-";
    elements.statusUpdatedAt.textContent = formatTime(status?.updatedAt);
    elements.statusUpdatedBy.textContent = status?.updatedBy || "-";
  }

  function renderVerifyResult(data) {
    elements.verifyHttpStatus.textContent =
      data?.httpStatus === undefined || data?.httpStatus === null ? "-" : String(data.httpStatus);
    elements.verifyFinalUrl.textContent = data?.finalUrl || "-";
    elements.verifyTitle.textContent = data?.title || "-";
    elements.verifyUser.textContent = data?.authenticatedUser || "-";
  }

  function renderGenerationConfig(gen) {
    if (!gen) return;
    const p = gen.provider;
    elements.genProviderLabel.textContent =
      p === "gemini" ? "Gemini 直连" : p === "bella" ? "Bella Chat（chat/completions）" : p === "bella-workflow" ? "Bella Workflow（旧编排）" : String(p || "-");
    elements.genEffectiveModel.textContent = gen.effectiveChatModel || "-";
    elements.genEffectiveThinking.textContent = gen.effectiveThinkingLevel || "-";
    if (elements.genChatModel) {
      elements.genChatModel.value = gen.chatModel || "";
    }
    if (elements.genThinkingLevel) {
      const v = String(gen.thinkingLevel || "").toUpperCase();
      const allowed = new Set(["", "HIGH", "MEDIUM", "LOW"]);
      elements.genThinkingLevel.value = allowed.has(v) ? v : "";
    }
  }

  function renderPromptConfig(data) {
    renderGenerationConfig(data?.generation);
    elements.promptOverrideCount.textContent =
      data?.runtimeOverrideCount === undefined || data?.runtimeOverrideCount === null
        ? "-"
        : String(data.runtimeOverrideCount);
    elements.promptUpdatedAt.textContent = formatTime(data?.updatedAt);
    elements.promptUpdatedBy.textContent = data?.updatedBy || "-";

    const templateMap = new Map((data?.templates || []).map((item) => [item.key, item]));
    PROMPT_KEYS.forEach((key) => {
      const item = templateMap.get(key);
      if (elements.promptFields[key]) {
        elements.promptFields[key].value = item?.content || "";
      }
      if (elements.promptSources[key]) {
        elements.promptSources[key].textContent = item
          ? `${item.source === "runtime" ? "运行时覆盖" : "文件默认"} · ${item.fileName}`
          : "未加载";
      }
    });

    if (elements.promptFields.knowledgeBase) {
      elements.promptFields.knowledgeBase.value = data?.knowledgeBase?.content || "";
    }
    if (elements.promptSources.knowledgeBase) {
      const item = data?.knowledgeBase;
      elements.promptSources.knowledgeBase.textContent = item
        ? `${item.source === "runtime" ? "运行时覆盖" : "文件默认"} · ${item.fileName}`
        : "未加载";
    }
  }

  async function requestJson(url, options) {
    const response = await fetch(url, options);
    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }
    if (!response.ok || !data?.success) {
      throw new Error(data?.error || "请求失败");
    }
    return data;
  }

  async function loadStatus() {
    setFeedback(elements.statusFeedback, "正在加载状态...", "info");
    const data = await requestJson("/api/admin/wiki-auth/status", {
      method: "GET",
      headers: getJsonHeaders(false),
    });
    renderAuthStatus(data.data || {});
    setFeedback(elements.statusFeedback, "状态已刷新", "success");
  }

  async function loadPromptConfig() {
    setFeedback(elements.promptConfigFeedback, "正在加载 Prompt 配置...", "info");
    const data = await requestJson("/api/admin/prompt-config", {
      method: "GET",
      headers: getJsonHeaders(false),
    });
    renderPromptConfig(data.data || {});
    setFeedback(elements.promptConfigFeedback, "Prompt 配置已刷新", "success");
  }

  async function saveAuth() {
    const cookie = String(elements.wikiCookie?.value || "").trim();
    const authToken = String(elements.wikiAuthToken?.value || "").trim();
    const updatedBy = String(elements.updatedBy?.value || "").trim();
    if (!cookie && !authToken) {
      throw new Error("请至少填写 Wiki Cookie 或 Auth Token");
    }
    setFeedback(elements.saveFeedback, "正在保存运行时凭证...", "info");
    const data = await requestJson("/api/admin/wiki-auth", {
      method: "POST",
      headers: getJsonHeaders(true),
      body: JSON.stringify({ cookie, authToken, updatedBy }),
    });
    renderAuthStatus(data.data || {});
    setFeedback(elements.saveFeedback, "保存成功，新的运行时凭证已立即生效", "success");
  }

  async function verifyAuth() {
    const url = String(elements.verifyUrl?.value || "").trim();
    if (!url) {
      throw new Error("请输入用于验证的 Wiki 地址");
    }
    setFeedback(elements.verifyFeedback, "正在验证当前 Wiki 凭证...", "info");
    const data = await requestJson("/api/admin/wiki-auth/verify", {
      method: "POST",
      headers: getJsonHeaders(true),
      body: JSON.stringify({ url }),
    });
    renderVerifyResult(data.data || {});
    setFeedback(elements.verifyFeedback, "验证成功，当前凭证可正常读取该 Wiki 页面", "success");
  }

  async function savePromptConfig() {
    const templates = {};
    PROMPT_KEYS.forEach((key) => {
      templates[key] = String(elements.promptFields[key]?.value || "");
    });
    const knowledgeBase = String(elements.promptFields.knowledgeBase?.value || "");
    const chatModel = String(elements.genChatModel?.value || "").trim();
    const thinkingLevel = String(elements.genThinkingLevel?.value || "").trim();
    const updatedBy = String(elements.updatedBy?.value || "").trim();
    setFeedback(elements.promptConfigFeedback, "正在保存 Prompt 配置...", "info");
    const data = await requestJson("/api/admin/prompt-config", {
      method: "POST",
      headers: getJsonHeaders(true),
      body: JSON.stringify({ templates, knowledgeBase, chatModel, thinkingLevel, updatedBy }),
    });
    renderPromptConfig(data.data || {});
    setFeedback(elements.promptConfigFeedback, "Prompt 配置已保存并立即生效", "success");
  }

  async function executeAction(action, feedbackTarget) {
    try {
      await action();
    } catch (error) {
      const message = error?.message || "操作失败";
      setFeedback(feedbackTarget, message, "error");
    }
  }

  elements.refreshStatusBtn?.addEventListener("click", () => executeAction(loadStatus, elements.statusFeedback));
  elements.saveAuthBtn?.addEventListener("click", () => executeAction(saveAuth, elements.saveFeedback));
  elements.verifyAuthBtn?.addEventListener("click", () => executeAction(verifyAuth, elements.verifyFeedback));
  elements.loadPromptConfigBtn?.addEventListener("click", () =>
    executeAction(loadPromptConfig, elements.promptConfigFeedback)
  );
  elements.savePromptConfigBtn?.addEventListener("click", () =>
    executeAction(savePromptConfig, elements.promptConfigFeedback)
  );
})();
