(function () {
  const ADMIN_HEADER = "X-Wiki-Admin-Secret";

  const els = {
    recentJobsAuthModal: document.getElementById("recentJobsAuthModal"),
    recentJobsAuthBackdrop: document.getElementById("recentJobsAuthBackdrop"),
    recentJobsAuthClose: document.getElementById("recentJobsAuthClose"),
    recentJobsAuthConfirm: document.getElementById("recentJobsAuthConfirm"),
    recentJobsAuthCancel: document.getElementById("recentJobsAuthCancel"),
    adminSecretModal: document.getElementById("adminSecretModal"),
    modalAuthFeedback: document.getElementById("modalAuthFeedback"),
    jobIdInput: document.getElementById("jobIdInput"),
    resultIdInput: document.getElementById("resultIdInput"),
    loadJobBtn: document.getElementById("loadJobBtn"),
    loadResultBtn: document.getElementById("loadResultBtn"),
    loadRecentBtn: document.getElementById("loadRecentBtn"),
    mainFeedback: document.getElementById("mainFeedback"),
    recentJobsSection: document.getElementById("recentJobsSection"),
    recentJobList: document.getElementById("recentJobList"),
    detailSection: document.getElementById("detailSection"),
    detailJobId: document.getElementById("detailJobId"),
    detailClientReqId: document.getElementById("detailClientReqId"),
    detailResultId: document.getElementById("detailResultId"),
    detailWorkflowRunId: document.getElementById("detailWorkflowRunId"),
    detailStatus: document.getElementById("detailStatus"),
    detailUpdated: document.getElementById("detailUpdated"),
    stageBlocks: document.getElementById("stageBlocks"),
  };

  function setFeedback(message, type) {
    const t = els.mainFeedback;
    if (!t) return;
    t.hidden = !message;
    t.className = "admin-feedback";
    if (!message) {
      t.textContent = "";
      return;
    }
    if (type === "error") t.classList.add("is-error");
    else if (type === "success") t.classList.add("is-success");
    else t.classList.add("is-info");
    t.textContent = message;
  }

  function setModalAuthFeedback(message, type) {
    const t = els.modalAuthFeedback;
    if (!t) return;
    t.hidden = !message;
    t.className = "admin-feedback";
    if (!message) {
      t.textContent = "";
      return;
    }
    if (type === "error") t.classList.add("is-error");
    else if (type === "success") t.classList.add("is-success");
    else t.classList.add("is-info");
    t.textContent = message;
  }

  function openRecentJobsModal() {
    if (!els.recentJobsAuthModal) return;
    els.recentJobsAuthModal.hidden = false;
    if (els.adminSecretModal) els.adminSecretModal.value = "";
    setModalAuthFeedback("", null);
    requestAnimationFrame(() => els.adminSecretModal?.focus());
  }

  function closeRecentJobsModal() {
    if (!els.recentJobsAuthModal) return;
    els.recentJobsAuthModal.hidden = true;
    if (els.adminSecretModal) els.adminSecretModal.value = "";
    setModalAuthFeedback("", null);
  }

  async function fetchJson(url, options = {}) {
    const res = await fetch(url, options);
    let data = {};
    try {
      data = await res.json();
    } catch {
      data = {};
    }
    return { res, data };
  }

  function formatTime(iso) {
    if (!iso) return "-";
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? iso : d.toLocaleString("zh-CN", { hour12: false });
  }

  function outputsToText(outputs) {
    if (!outputs || typeof outputs !== "object") return "";
    if (typeof outputs.text === "string" && outputs.text.trim()) return outputs.text.trim();
    if (typeof outputs.result === "string" && outputs.result.trim()) return outputs.result.trim();
    const parts = [];
    for (const [k, v] of Object.entries(outputs)) {
      if (k === "text" || k === "result") continue;
      if (typeof v === "string" && v.trim()) parts.push(`### ${k}\n\n${v.trim()}`);
      else if (v && typeof v === "object") {
        try {
          parts.push(`### ${k}\n\n\`\`\`json\n${JSON.stringify(v, null, 2)}\n\`\`\``);
        } catch {
          parts.push(`### ${k}\n\n${String(v)}`);
        }
      }
    }
    return parts.join("\n\n---\n\n");
  }

  function formatStoredStageValue(key, value) {
    if (value == null) return "";
    if (typeof value === "string") return value;
    if (typeof value !== "object") return String(value);

    if ("usedFallback" in value && ("primary" in value || "final" in value)) {
      const lines = [`路径: ${value.usedFallback ? "已走兜底" : "主路径成功"}`];
      if (value.primary && typeof value.primary === "object") {
        lines.push("### 主路径 outputs\n", outputsToText(value.primary) || "```json\n" + JSON.stringify(value.primary, null, 2) + "\n```");
      }
      if (value.fallback && typeof value.fallback === "object") {
        lines.push("### 兜底 outputs\n", outputsToText(value.fallback) || "```json\n" + JSON.stringify(value.fallback, null, 2) + "\n```");
      }
      if (value.final && typeof value.final === "object") {
        lines.push("### 最终采用 outputs\n", outputsToText(value.final) || "```json\n" + JSON.stringify(value.final, null, 2) + "\n```");
      }
      return lines.filter(Boolean).join("\n\n");
    }

    return outputsToText(value) || "```json\n" + JSON.stringify(value, null, 2) + "\n```";
  }

  function renderStageBlock(title, subtitle, body) {
    const wrap = document.createElement("div");
    wrap.className = "generation-log-stage";
    const h = document.createElement("h3");
    h.className = "generation-log-stage-title";
    h.textContent = title;
    wrap.appendChild(h);
    if (subtitle) {
      const p = document.createElement("p");
      p.className = "field-hint generation-log-stage-meta";
      p.textContent = subtitle;
      wrap.appendChild(p);
    }
    const pre = document.createElement("pre");
    pre.className = "generation-log-pre";
    pre.textContent = body && String(body).trim() ? body : "（无文本输出，可能未执行或仅含结构化字段，见 JSON）";
    wrap.appendChild(pre);
    return wrap;
  }

  function renderJobPayload(job) {
    els.detailSection.hidden = false;
    const res = job.result || {};
    if (els.detailJobId) els.detailJobId.textContent = job.id || "-";
    if (els.detailClientReqId) els.detailClientReqId.textContent = job.clientRequestId || "-";
    if (els.detailResultId) els.detailResultId.textContent = res.id || "（完成后才有）";
    if (els.detailWorkflowRunId) {
      els.detailWorkflowRunId.textContent = res.workflowRunId || "（进行中或见各阶段）";
    }
    els.detailStatus.textContent = `${job.status || "-"}${job.currentStageLabel ? " · " + job.currentStageLabel : ""}`.trim();
    els.detailUpdated.textContent = formatTime(job.updatedAt || job.completedAt || job.createdAt);
    els.stageBlocks.innerHTML = "";

    const stages = Array.isArray(job.stages) ? job.stages : [];
    if (stages.length) {
      for (const s of stages) {
        const subtitle = `${s.status || ""} · workflowRunId: ${s.workflowRunId || "-"} · ${s.startedAt || ""} → ${s.completedAt || ""}`;
        els.stageBlocks.appendChild(renderStageBlock(s.label || s.key, subtitle, s.aiGenerated || ""));
      }
      return;
    }

    els.stageBlocks.appendChild(
      renderStageBlock("无阶段数据", "", "该任务可能已过期并从内存清除，请使用「结果 ID」加载历史记录中的 outputs.stages。")
    );
  }

  function renderResultPayload(record) {
    els.detailSection.hidden = false;
    if (els.detailJobId) els.detailJobId.textContent = "（仅内存任务有）";
    if (els.detailClientReqId) els.detailClientReqId.textContent = record.clientRequestId || "-";
    if (els.detailResultId) els.detailResultId.textContent = record.id || "-";
    if (els.detailWorkflowRunId) els.detailWorkflowRunId.textContent = record.workflowRunId || "-";
    els.detailStatus.textContent = record.status || "-";
    els.detailUpdated.textContent = formatTime(record.createdAt);
    els.stageBlocks.innerHTML = "";

    const stages = record.outputs?.stages;
    const summary = record.stageSummary || record.outputs?.stageSummary;
    const order = ["testPoint", "elements", "business", "businessFallback", "elementMatch", "elementMatchFallback"];

    if (stages && typeof stages === "object") {
      for (const key of order) {
        if (!(key in stages)) continue;
        const raw = stages[key];
        const sum = summary && typeof summary === "object" ? summary[key] : null;
        const label = sum?.label || key;
        const subtitle = sum
          ? `${sum.status || ""} · ${sum.workflowRunId || "-"}`
          : "";
        const body =
          sum?.aiGenerated ||
          formatStoredStageValue(key, raw);
        els.stageBlocks.appendChild(renderStageBlock(label, subtitle, body));
      }
    }

    if (!els.stageBlocks.children.length) {
      els.stageBlocks.appendChild(
        renderStageBlock(
          "无分阶段数据",
          "",
          "该记录可能是旧版本保存，未带 outputs.stages。可查看完整 outputs：\n" +
            JSON.stringify(record.outputs || {}, null, 2)
        )
      );
    }
  }

  async function loadJobById() {
    const id = String(els.jobIdInput?.value || "").trim();
    if (!id) {
      setFeedback("请填写 Job ID", "error");
      return;
    }
    setFeedback("加载中…", "info");
    const { res, data } = await fetchJson(`/api/testcase/jobs/${encodeURIComponent(id)}`);
    if (!res.ok || !data?.success) {
      setFeedback(data?.message || data?.error || "加载失败", "error");
      return;
    }
    renderJobPayload(data.data);
    setFeedback("已加载任务（内存）", "success");
  }

  async function loadResultById() {
    const id = String(els.resultIdInput?.value || "").trim();
    if (!id) {
      setFeedback("请填写结果 ID", "error");
      return;
    }
    setFeedback("加载中…", "info");
    const { res, data } = await fetchJson(`/api/testcase/${encodeURIComponent(id)}`);
    if (!res.ok || !data?.success) {
      setFeedback(data?.message || "未找到记录", "error");
      return;
    }
    renderResultPayload(data.data);
    setFeedback("已加载历史记录", "success");
  }

  function renderRecentJobsList(jobs) {
    els.recentJobsSection.hidden = false;
    els.recentJobList.innerHTML = "";
    if (!jobs.length) {
      els.recentJobList.innerHTML = "<li>当前没有内存中的任务</li>";
      return;
    }
    for (const j of jobs) {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn btn-outline btn-sm";
      btn.textContent = "查看";
      btn.addEventListener("click", () => {
        els.jobIdInput.value = j.id;
        renderJobPayload(j);
        els.detailSection.hidden = false;
        setFeedback("已从列表打开", "success");
        els.detailSection.scrollIntoView({ behavior: "smooth" });
      });
      const span = document.createElement("span");
      span.className = "generation-log-job-meta";
      span.textContent = `${j.status} · ${formatTime(j.updatedAt)} · ${(j.prd || "").slice(0, 24)}…`;
      li.appendChild(btn);
      li.appendChild(document.createTextNode(" "));
      li.appendChild(span);
      li.appendChild(document.createElement("br"));
      const small = document.createElement("small");
      small.className = "generation-log-job-id";
      small.textContent = j.id;
      li.appendChild(small);
      els.recentJobList.appendChild(li);
    }
  }

  async function confirmLoadRecentJobs() {
    const secret = String(els.adminSecretModal?.value || "").trim();
    if (!secret) {
      setModalAuthFeedback("请输入管理员口令", "error");
      return;
    }
    setModalAuthFeedback("加载中…", "info");
    try {
      const { res, data } = await fetchJson("/api/admin/testcase-jobs?limit=30", {
        headers: { [ADMIN_HEADER]: secret },
      });
      if (!res.ok || !data?.success) {
        setModalAuthFeedback(data?.error || data?.message || "加载失败（检查口令）", "error");
        return;
      }
      const jobs = data.data?.jobs || [];
      renderRecentJobsList(jobs);
      closeRecentJobsModal();
      if (!jobs.length) {
        setFeedback("列表为空", "info");
      } else {
        setFeedback(`已加载 ${jobs.length} 条`, "success");
      }
      els.recentJobsSection?.scrollIntoView({ behavior: "smooth" });
    } catch (e) {
      setModalAuthFeedback(e?.message || "错误", "error");
    }
  }

  els.loadJobBtn?.addEventListener("click", () => loadJobById().catch((e) => setFeedback(e?.message || "错误", "error")));
  els.loadResultBtn?.addEventListener("click", () => loadResultById().catch((e) => setFeedback(e?.message || "错误", "error")));
  els.loadRecentBtn?.addEventListener("click", () => openRecentJobsModal());

  els.recentJobsAuthConfirm?.addEventListener("click", () => confirmLoadRecentJobs());
  els.recentJobsAuthCancel?.addEventListener("click", () => closeRecentJobsModal());
  els.recentJobsAuthClose?.addEventListener("click", () => closeRecentJobsModal());
  els.recentJobsAuthBackdrop?.addEventListener("click", () => closeRecentJobsModal());

  els.adminSecretModal?.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") {
      ev.preventDefault();
      confirmLoadRecentJobs();
    }
  });

  document.addEventListener("keydown", (ev) => {
    if (ev.key !== "Escape") return;
    if (!els.recentJobsAuthModal || els.recentJobsAuthModal.hidden) return;
    closeRecentJobsModal();
  });
})();
