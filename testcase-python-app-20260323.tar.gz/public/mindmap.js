const markdownEl = document.getElementById("markdown");
const previewBtn = document.getElementById("previewBtn");
const convertBtn = document.getElementById("convertBtn");
const zoomOutBtn = document.getElementById("zoomOutBtn");
const zoomInBtn = document.getElementById("zoomInBtn");
const fitViewBtn = document.getElementById("fitViewBtn");
const fullscreenBtn = document.getElementById("fullscreenBtn");
const refTestcaseEl = document.getElementById("refTestcase");
const mindmapEl = document.getElementById("mindmap");
const errorBox = document.getElementById("errorBox");
const errorText = document.getElementById("errorText");
const previewPanelEl = document.querySelector(".preview-panel");
let fullscreenFitBackup = null;
let lastRenderNodeMappings = [];
let persistentSourceHighlightRange = null;
let sourceHighlightOverlayEl = null;
let pendingPreviewRestoreTransform = "";
let pendingPreviewRestoreZoom = null;
let pendingPreviewRestoreAnchor = null;
let previewRestoreToken = 0;
let shouldAutoFitPreviewOnLoad = false;
const textMeasureCanvas = document.createElement("canvas");
const textMeasureCtx = textMeasureCanvas.getContext("2d");
const PREVIEW_BUTTON_ZOOM_FACTOR = 1.18;
const PREVIEW_WHEEL_ZOOM_SENSITIVITY = 0.0015;
const DELETED_NODE_PLACEHOLDER = "（已删除）";
let pendingWheelZoomFrame = 0;
let pendingWheelZoomDelta = 0;
let pendingWheelZoomClientX = null;
let pendingWheelZoomClientY = null;

function applyPrefillMarkdown() {
  try {
    const prefill = sessionStorage.getItem("mindmapMarkdown");
    if (prefill && typeof prefill === "string" && prefill.trim()) {
      markdownEl.value = normalizeEscapedNewlines(prefill);
      sessionStorage.removeItem("mindmapMarkdown");
    }
  } catch (_) {}
}

function getOutputText(item) {
  const o = item?.outputs;
  if (!o) return "";
  if (typeof o.text === "string") return o.text;
  if (typeof o.result === "string") return o.result;
  return "";
}

function normalizeEscapedNewlines(text) {
  if (typeof text !== "string") return text;
  return text
    .replace(/\\r\\n/g, "\n")
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\n");
}

function truncate(str, len = 80) {
  if (!str || typeof str !== "string") return "";
  return str.length <= len ? str : str.slice(0, len) + "…";
}

async function loadTestcaseList() {
  if (!refTestcaseEl) return;
  try {
    const res = await fetch("/api/testcase/list");
    const data = await res.json();
    if (!data.success || !Array.isArray(data.data)) return;
    const items = data.data;
    refTestcaseEl.innerHTML = '<option value="">-- 选择一条结果 --</option>';
    items.forEach((item) => {
      const opt = document.createElement("option");
      opt.value = item.id;
      const time = item.createdAt ? new Date(item.createdAt).toLocaleString("zh-CN") : "";
      const previewText = normalizeEscapedNewlines(getOutputText(item) || "");
      const preview = previewText ? truncate(previewText, 30) : "(无输出)";
      opt.textContent = `${time} ${preview}`;
      refTestcaseEl.appendChild(opt);
    });
  } catch (_) {}
}

async function insertTestcaseResult(id) {
  if (!id) return;
  try {
    const res = await fetch(`/api/testcase/${id}`);
    const data = await res.json();
    if (!data.success || !data.data) {
      showError("获取测试用例失败");
      return;
    }
    const text = normalizeEscapedNewlines(getOutputText(data.data) || "");
    if (!text) {
      showError("该记录无文本输出");
      return;
    }
    markdownEl.value = text;
    renderPreview();
    hideError();
  } catch (e) {
    showError("引用失败：" + (e.message || "网络错误"));
  }
}

function showError(msg) {
  errorBox.hidden = false;
  errorText.textContent = msg;
}

function hideError() {
  errorBox.hidden = true;
}

function escapeMdForHtml(md) {
  return md.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function getRawLineRanges(text) {
  const lines = text.split("\n");
  const ranges = [];
  let start = 0;
  lines.forEach((line) => {
    const end = start + line.length;
    ranges.push({ line, start, end });
    start = end + 1;
  });
  return ranges;
}

function buildRenderData(md) {
  const lines = md.split("\n");
  const rawRanges = getRawLineRanges(md);
  let lastLevel = 0;
  let lastHeadingLevel = 0;
  const result = [];
  const nodeMappings = [];
  const listStack = [];

  const pushLevelContent = (level, content, mapping) => {
    if (level <= 6) {
      result.push("#".repeat(level) + " " + content);
    } else {
      const nestedIndent = "  ".repeat(level - 7);
      result.push(nestedIndent + "- " + content);
    }
    nodeMappings.push(mapping);
  };

  const resolveListLevel = (indent) => {
    if (!listStack.length) {
      const level = Math.min((lastHeadingLevel || 0) + 1, 9);
      listStack.push({ indent, level });
      return level;
    }

    const top = listStack[listStack.length - 1];
    if (indent > top.indent) {
      const level = Math.min(top.level + 1, 9);
      listStack.push({ indent, level });
      return level;
    }

    while (listStack.length && indent < listStack[listStack.length - 1].indent) {
      listStack.pop();
    }

    if (!listStack.length) {
      const level = Math.min((lastHeadingLevel || 0) + 1, 9);
      listStack.push({ indent, level });
      return level;
    }

    const current = listStack[listStack.length - 1];
    if (indent === current.indent) {
      return current.level;
    }

    const level = Math.min(current.level + 1, 9);
    listStack.push({ indent, level });
    return level;
  };

  for (let idx = 0; idx < lines.length; idx += 1) {
    const line = lines[idx];
    const sourceRange = rawRanges[idx];
    const headingMatch = line.match(/^\s*(#+)\s+(.*)$/);
    const listMatch = line.match(/^(\s*)([-*+]|\d+\.)\s+(.*)$/);
    if (headingMatch) {
      const rawLevel = headingMatch[1].length;
      const content = headingMatch[2];
      let level = rawLevel;
      // Smooth heading jumps by filling skipped levels with placeholder nodes.
      if (lastLevel > 0 && rawLevel > lastLevel + 1) {
        for (let lv = lastLevel + 1; lv < rawLevel; lv += 1) {
          const placeholder = "（占位）";
          pushLevelContent(lv, placeholder, {
            start: null,
            end: null,
            text: placeholder,
            synthetic: true,
            level: lv,
          });
        }
      }
      lastLevel = level;
      lastHeadingLevel = level;
      listStack.length = 0;
      pushLevelContent(level, content, {
        start: sourceRange.start,
        end: sourceRange.end,
        text: content.trim(),
        synthetic: false,
        level,
      });
    } else if (listMatch) {
      const indent = listMatch[1].replace(/\t/g, "  ").length;
      const content = listMatch[3];
      const newLevel = resolveListLevel(indent);
      lastLevel = newLevel;
      pushLevelContent(newLevel, content, {
        start: sourceRange.start,
        end: sourceRange.end,
        text: content.trim(),
        synthetic: false,
        level: newLevel,
      });
    } else {
      result.push(line);
    }
  }

  return {
    markdown: result.join("\n"),
    nodeMappings,
  };
}

/**
 * 将 - * + 和有序列表转换为 # 标题
 * 规则：- 视为「上一级 +1」，如上一行是 ####### 则 - 转为 ########
 * 同级 -（同缩进）保持同级；多 2 空格缩进则子级 +1
 */
function convertListToHeading(md) {
  return buildRenderData(md).markdown;
}

function getMarkdownForRender(withNodeMap = false) {
  const md = normalizeEscapedNewlines(markdownEl.value || "").trim();
  const data = buildRenderData(md);
  if (withNodeMap) {
    lastRenderNodeMappings = data.nodeMappings;
  }
  return data.markdown;
}

function normalizeEditorEscapedNewlines() {
  if (!markdownEl) return;
  const rawValue = markdownEl.value || "";
  const normalized = normalizeEscapedNewlines(rawValue);
  if (normalized === rawValue) return;

  // Keep cursor/selection position stable after newline normalization.
  const start = markdownEl.selectionStart ?? rawValue.length;
  const end = markdownEl.selectionEnd ?? start;
  const normalizedStart = normalizeEscapedNewlines(rawValue.slice(0, start)).length;
  const normalizedEnd = normalizeEscapedNewlines(rawValue.slice(0, end)).length;

  markdownEl.value = normalized;
  markdownEl.setSelectionRange(normalizedStart, normalizedEnd);
}

function renderPreview() {
  const hadPreviewFrame = Boolean(document.getElementById("previewFrame"));
  shouldAutoFitPreviewOnLoad = !hadPreviewFrame;
  if (hadPreviewFrame) {
    setPendingPreviewTransformFromCurrent();
  }
  const md = getMarkdownForRender(true);
  const convertedPreview = document.getElementById("convertedPreview");
  if (convertedPreview) {
    convertedPreview.textContent = md || "(空)";
  }
  if (!md) {
    lastRenderNodeMappings = [];
    mindmapEl.innerHTML =
      '<p style="padding:2rem;color:#94a3b8">输入 Markdown 后自动预览（- 列表会自动转为 # 层级）</p>';
    return;
  }

  const escapedMd = escapeMdForHtml(md);
  const doc =
    `<!DOCTYPE html><html><head><meta charset="utf-8">` +
    `<script src="https://cdn.jsdelivr.net/npm/d3@6"><\x2fscript>` +
    `<script src="https://cdn.jsdelivr.net/npm/markmap-autoloader@0.18.12"><\x2fscript>` +
    `<style>html,body{margin:0;width:100%;height:100%;background:#fafbfc;overflow:hidden}.markmap{width:100%;height:100%}.markmap svg{width:100%;height:100%;touch-action:none;cursor:grab}.markmap svg.is-dragging{cursor:grabbing}.markmap text{-webkit-user-select:none;user-select:none}</style>` +
    `</head><body><div class="markmap"><script type="text/template">${escapedMd}<\x2fscript></div></body></html>`;

  const iframe = document.createElement("iframe");
  iframe.id = "previewFrame";
  iframe.style.cssText = "width:100%;border:none;background:#fafbfc";
  iframe.setAttribute("sandbox", "allow-scripts allow-same-origin");
  iframe.srcdoc = doc;
  fullscreenFitBackup = null;
  mindmapEl.innerHTML = "";
  mindmapEl.appendChild(iframe);
  iframe.addEventListener("load", () => {
    bindPreviewNodeLinking(iframe);
    schedulePreviewTransformRestore();
    scheduleInitialPreviewFit();
    scheduleFullscreenFit();
  });
}

function getPreviewSvgAndGroup() {
  const iframe = document.getElementById("previewFrame");
  const doc = iframe?.contentDocument;
  const svg = doc?.querySelector(".markmap svg");
  if (!svg) return { svg: null, g: null };
  const groups = Array.from(svg.querySelectorAll("g"));
  const g =
    groups.find((el) => {
      const t = el.getAttribute?.("transform") || "";
      if (!/translate\(|matrix\(/i.test(t)) return false;
      return el.querySelector("text,foreignObject");
    }) ||
    groups.find((el) => {
      const t = el.getAttribute?.("transform") || "";
      return /translate\(|matrix\(/i.test(t);
    }) ||
    groups[0] ||
    null;
  return { svg, g };
}

function getCurrentPreviewTransform() {
  const { g } = getPreviewSvgAndGroup();
  return g?.getAttribute("transform") || "";
}

function setPendingPreviewTransformFromCurrent() {
  const { svg } = getPreviewSvgAndGroup();
  pendingPreviewRestoreTransform = getCurrentPreviewTransform() || "";
  const zoom = svg?.__zoom;
  if (zoom && Number.isFinite(zoom.x) && Number.isFinite(zoom.y) && Number.isFinite(zoom.k)) {
    pendingPreviewRestoreZoom = { x: zoom.x, y: zoom.y, k: zoom.k };
  } else {
    pendingPreviewRestoreZoom = null;
  }
}

function setPendingPreviewAnchorFromNode(nodeGroup) {
  if (!nodeGroup?.getBoundingClientRect) {
    pendingPreviewRestoreAnchor = null;
    return;
  }
  const rect = nodeGroup.getBoundingClientRect();
  const nodeIndex = Number(nodeGroup.dataset.nodeIndex || "-1");
  if (!rect || rect.width <= 0 || rect.height <= 0 || nodeIndex < 0) {
    pendingPreviewRestoreAnchor = null;
    return;
  }
  pendingPreviewRestoreAnchor = {
    nodeIndex,
    centerX: rect.left + rect.width / 2,
    centerY: rect.top + rect.height / 2,
    keepActive: nodeGroup.dataset.nodeActive === "1",
  };
}

function cancelPendingPreviewRestore() {
  previewRestoreToken += 1;
  pendingPreviewRestoreTransform = "";
  pendingPreviewRestoreZoom = null;
  pendingPreviewRestoreAnchor = null;
  shouldAutoFitPreviewOnLoad = false;
}

function schedulePreviewTransformRestore() {
  if (!pendingPreviewRestoreTransform && !pendingPreviewRestoreZoom && !pendingPreviewRestoreAnchor) return;
  const token = ++previewRestoreToken;
  let tries = 0;
  const targetTransform = pendingPreviewRestoreTransform;
  const targetZoom = pendingPreviewRestoreZoom;
  const targetAnchor = pendingPreviewRestoreAnchor;
  const tick = () => {
    if (token !== previewRestoreToken) return;
    tries += 1;
    const { svg, g } = getPreviewSvgAndGroup();
    if (svg) {
      if (targetZoom) {
        svg.__zoom = { ...targetZoom };
      }
      if (g && targetTransform) {
        g.setAttribute("transform", targetTransform);
      } else if (g && targetZoom) {
        g.setAttribute("transform", `translate(${targetZoom.x} ${targetZoom.y}) scale(${targetZoom.k})`);
      }
      if (g && targetAnchor?.nodeIndex >= 0) {
        const doc = svg.ownerDocument;
        const anchorNode = doc?.querySelector(`g[data-node-index="${targetAnchor.nodeIndex}"]`);
        if (anchorNode?.getBoundingClientRect) {
          const rect = anchorNode.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            const deltaX = rect.left + rect.width / 2 - targetAnchor.centerX;
            const deltaY = rect.top + rect.height / 2 - targetAnchor.centerY;
            if (Math.abs(deltaX) > 0.5 || Math.abs(deltaY) > 0.5) {
              const current = parseTransform(g.getAttribute("transform"));
              if (current) {
                const nextTx = current.tx - deltaX;
                const nextTy = current.ty - deltaY;
                g.setAttribute("transform", `translate(${nextTx} ${nextTy}) scale(${current.scale})`);
                svg.__zoom = { x: nextTx, y: nextTy, k: current.scale };
              }
            }
            if (targetAnchor.keepActive && anchorNode.dataset.nodeActive !== "1") {
              setActiveNode(anchorNode);
            }
          }
        }
      }
      // Keep restoring for a short window because Markmap may mutate transform asynchronously.
      if (tries >= 16) {
        pendingPreviewRestoreTransform = "";
        pendingPreviewRestoreZoom = null;
        pendingPreviewRestoreAnchor = null;
        return;
      }
    }
    if (tries < 24) setTimeout(tick, 120);
    else {
      pendingPreviewRestoreTransform = "";
      pendingPreviewRestoreZoom = null;
      pendingPreviewRestoreAnchor = null;
    }
  };
  tick();
}

function getLineContentForMatch(line) {
  if (!line || typeof line !== "string") return "";
  const headingMatch = line.match(/^\s*#{1,}\s+(.*)$/);
  if (headingMatch) return headingMatch[1].trim();
  const listMatch = line.match(/^\s*([-*+]|\d+\.)\s+(.*)$/);
  if (listMatch) return listMatch[2].trim();
  return line.trim();
}

function locateSourceRangeByNodeText(nodeText, occurrence = 0) {
  const source = normalizeEscapedNewlines(markdownEl.value || "");
  const target = (nodeText || "").trim();
  if (!source || !target) return null;

  const ranges = getRawLineRanges(source);
  const exactMatches = [];
  const looseMatches = [];
  for (const item of ranges) {
    const content = getLineContentForMatch(item.line);
    if (!content) continue;
    if (content === target) {
      exactMatches.push({
        start: item.start,
        end: item.end,
      });
      continue;
    }
    if (content.includes(target) || target.includes(content)) {
      looseMatches.push({
        start: item.start,
        end: item.end,
      });
    }
  }
  if (exactMatches.length) {
    const idx = Math.min(Math.max(occurrence, 0), exactMatches.length - 1);
    return exactMatches[idx];
  }
  if (looseMatches.length) {
    const idx = Math.min(Math.max(occurrence, 0), looseMatches.length - 1);
    return looseMatches[idx];
  }
  return null;
}

function revealSourceByRange(range) {
  if (!range) return;
  const safeStart = Math.max(0, range.start ?? 0);
  const safeEnd = Math.max(safeStart, range.end ?? safeStart);
  const lineHeight = parseFloat(window.getComputedStyle(markdownEl).lineHeight) || 24;
  const caretTop = getTextareaCaretTop(markdownEl, safeStart);
  const desiredTop = caretTop - markdownEl.clientHeight / 2 + lineHeight / 2;
  const maxTop = Math.max(0, markdownEl.scrollHeight - markdownEl.clientHeight);
  markdownEl.scrollTop = Math.max(0, Math.min(desiredTop, maxTop));
  setPersistentSourceHighlight({ start: safeStart, end: safeEnd });
  return { start: safeStart, end: safeEnd };
}

function focusSourceByRange(range) {
  const normalized = revealSourceByRange(range);
  if (!normalized) return;
  markdownEl.focus();
  markdownEl.setSelectionRange(normalized.start, normalized.end);
}

function getTextareaCaretTop(textarea, index) {
  if (!textarea) return 0;
  const value = textarea.value || "";
  const safeIndex = Math.max(0, Math.min(index, value.length));
  const before = value.slice(0, safeIndex);

  const style = window.getComputedStyle(textarea);
  const mirror = document.createElement("div");
  mirror.style.position = "absolute";
  mirror.style.visibility = "hidden";
  mirror.style.pointerEvents = "none";
  mirror.style.left = "-99999px";
  mirror.style.top = "0";
  mirror.style.whiteSpace = "pre-wrap";
  mirror.style.wordWrap = "break-word";
  mirror.style.overflowWrap = "break-word";
  mirror.style.boxSizing = style.boxSizing;
  mirror.style.width = `${textarea.clientWidth}px`;
  mirror.style.font = style.font;
  mirror.style.lineHeight = style.lineHeight;
  mirror.style.letterSpacing = style.letterSpacing;
  mirror.style.padding = style.padding;
  mirror.style.border = style.border;

  const textNode = document.createTextNode(before);
  const marker = document.createElement("span");
  marker.textContent = "\u200b";
  mirror.appendChild(textNode);
  mirror.appendChild(marker);
  document.body.appendChild(mirror);

  const caretTop = marker.offsetTop;
  mirror.remove();
  return caretTop;
}

function ensureSourceHighlightOverlay() {
  if (sourceHighlightOverlayEl) return sourceHighlightOverlayEl;
  if (!markdownEl || !markdownEl.parentElement) return null;
  const container = markdownEl.parentElement;
  if (window.getComputedStyle(container).position === "static") {
    container.style.position = "relative";
  }
  const overlay = document.createElement("div");
  overlay.className = "source-highlight-overlay";
  overlay.hidden = true;
  container.appendChild(overlay);
  sourceHighlightOverlayEl = overlay;
  return overlay;
}

function updatePersistentSourceHighlightPosition() {
  if (!persistentSourceHighlightRange) return;
  const overlay = ensureSourceHighlightOverlay();
  if (!overlay || !markdownEl) return;
  const lineHeight = parseFloat(window.getComputedStyle(markdownEl).lineHeight) || 24;
  const topInTextarea = getTextareaCaretTop(markdownEl, persistentSourceHighlightRange.start);
  const top = markdownEl.offsetTop + topInTextarea - markdownEl.scrollTop;
  overlay.style.left = `${markdownEl.offsetLeft + 6}px`;
  overlay.style.top = `${top}px`;
  overlay.style.width = `${Math.max(40, markdownEl.clientWidth - 12)}px`;
  overlay.style.height = `${Math.max(20, lineHeight)}px`;
  overlay.hidden = false;
}

function setPersistentSourceHighlight(range) {
  if (!range) return;
  const safeStart = Math.max(0, range.start ?? 0);
  const safeEnd = Math.max(safeStart, range.end ?? safeStart);
  persistentSourceHighlightRange = { start: safeStart, end: safeEnd };
  updatePersistentSourceHighlightPosition();
}

function focusSourceByNodeText(nodeText, occurrence = 0) {
  const range = locateSourceRangeByNodeText(nodeText, occurrence);
  if (!range) return;
  focusSourceByRange(range);
}

function getNodeTextFromGroup(nodeGroup) {
  if (!nodeGroup) return "";
  const labelEl = getNodeLabelElement(nodeGroup);
  return (labelEl?.textContent || "").trim();
}

function getNodeLabelElement(nodeGroup) {
  if (!nodeGroup) return null;
  return (
    nodeGroup.querySelector("text") ||
    nodeGroup.querySelector("foreignObject") ||
    nodeGroup.querySelector("[data-node-label]")
  );
}

function getNodeGroups(doc) {
  const direct = Array.from(doc.querySelectorAll("g.markmap-node"));
  if (direct.length) return direct;
  return Array.from(doc.querySelectorAll(".markmap g")).filter(
    (g) =>
      g.querySelector("circle") &&
      (g.querySelector("text") || g.querySelector("foreignObject"))
  );
}

function ensureNodeHitbox(nodeGroup) {
  if (!nodeGroup) return null;
  const existed = nodeGroup.querySelector('rect[data-node-hitbox="1"]');
  if (existed) return existed;

  if (!nodeGroup.getBBox) return null;
  const nodeBox = nodeGroup.getBBox();
  if (!nodeBox || nodeBox.width <= 0 || nodeBox.height <= 0) return null;

  const paddingX = 10;
  const paddingY = 6;
  const rect = nodeGroup.ownerDocument.createElementNS("http://www.w3.org/2000/svg", "rect");
  rect.dataset.nodeHitbox = "1";
  rect.setAttribute("x", String(nodeBox.x - paddingX));
  rect.setAttribute("y", String(nodeBox.y - paddingY));
  rect.setAttribute("width", String(nodeBox.width + paddingX * 2));
  rect.setAttribute("height", String(nodeBox.height + paddingY * 2));
  rect.setAttribute("rx", "6");
  rect.setAttribute("ry", "6");
  rect.setAttribute("fill", "transparent");
  rect.setAttribute("stroke", "none");
  rect.style.pointerEvents = "all";
  nodeGroup.insertBefore(rect, nodeGroup.firstChild || null);
  return rect;
}

function setActiveNode(nodeGroup) {
  const doc = nodeGroup?.ownerDocument;
  if (!doc) return;

  const prev = doc.querySelector('g[data-node-active="1"]');
  if (prev) {
    prev.dataset.nodeActive = "0";
    const prevRect = prev.querySelector('rect[data-node-hitbox="1"]');
    if (prevRect) {
      if (prev.dataset.nodeDeleted === "1") {
        prevRect.setAttribute("fill", "rgba(148,163,184,0.10)");
        prevRect.setAttribute("stroke", "rgba(148,163,184,0.6)");
        prevRect.setAttribute("stroke-dasharray", "4 3");
      } else {
        prevRect.setAttribute("fill", "transparent");
        prevRect.setAttribute("stroke", "none");
        prevRect.setAttribute("stroke-dasharray", "");
      }
    }
  }

  nodeGroup.dataset.nodeActive = "1";
  const activeRect = ensureNodeHitbox(nodeGroup);
  if (activeRect) {
    activeRect.setAttribute("fill", "rgba(37,99,235,0.12)");
    activeRect.setAttribute("stroke", "rgba(37,99,235,0.7)");
    activeRect.setAttribute("stroke-width", "1.5");
  }
}

function resolveSourceRangeByNode(targetGroup) {
  if (targetGroup?.dataset?.nodeSynthetic === "1") return null;
  const text = getNodeTextFromGroup(targetGroup);
  const nodeIndex = Number(targetGroup.dataset.nodeIndex || "-1");
  const textOccurrence = Number(targetGroup.dataset.nodeTextOccurrence || "0");
  const mappedRange = nodeIndex >= 0 ? lastRenderNodeMappings[nodeIndex] : null;
  const mappedText = (mappedRange?.text || "").trim();
  const mappedIsReliable = Boolean(
    mappedRange &&
      !mappedRange.synthetic &&
      Number.isFinite(mappedRange.start) &&
      Number.isFinite(mappedRange.end) &&
      (!text || mappedText === text)
  );
  if (mappedIsReliable) return mappedRange;
  if (text) return locateSourceRangeByNodeText(text, textOccurrence);
  return null;
}

function findSourceMappingIndexByRange(range, expectedText = "") {
  if (!range) return -1;
  const safeStart = Number(range.start);
  const safeEnd = Number(range.end);
  if (!Number.isFinite(safeStart) || !Number.isFinite(safeEnd)) return -1;
  const normalizedText = (expectedText || "").trim();
  let fallbackIndex = -1;
  for (let idx = 0; idx < lastRenderNodeMappings.length; idx += 1) {
    const mapping = lastRenderNodeMappings[idx];
    if (
      !mapping ||
      mapping.synthetic ||
      !Number.isFinite(mapping.start) ||
      !Number.isFinite(mapping.end) ||
      mapping.start !== safeStart ||
      mapping.end !== safeEnd
    ) {
      continue;
    }
    if (!normalizedText) return idx;
    const mappingText = (mapping.text || "").trim();
    if (mappingText === normalizedText) return idx;
    if (fallbackIndex < 0) fallbackIndex = idx;
  }
  return fallbackIndex;
}

function resolveSourceDeletePlanByNode(targetGroup) {
  const fallbackRange = resolveSourceRangeByNode(targetGroup);
  if (!fallbackRange) return null;
  const text = getNodeTextFromGroup(targetGroup);
  const mappingIndex = findSourceMappingIndexByRange(fallbackRange, text);
  const mapping = mappingIndex >= 0 ? lastRenderNodeMappings[mappingIndex] : null;
  if (
    !mapping ||
    mapping.synthetic ||
    !Number.isFinite(mapping.start) ||
    !Number.isFinite(mapping.end) ||
    !Number.isFinite(mapping.level)
  ) {
    return {
      deleteRange: fallbackRange,
      mappingIndex,
      deletedMappingIndexes: mappingIndex >= 0 ? [mappingIndex] : [],
    };
  }

  const source = markdownEl.value || "";
  const baseLevel = Number(mapping.level);
  let deleteEnd = mapping.end;
  let foundBoundary = false;
  const deletedMappingIndexes = [mappingIndex];
  for (let idx = mappingIndex + 1; idx < lastRenderNodeMappings.length; idx += 1) {
    const next = lastRenderNodeMappings[idx];
    if (!next || next.synthetic || !Number.isFinite(next.start) || !Number.isFinite(next.end)) continue;
    const nextLevel = Number(next.level);
    if (Number.isFinite(nextLevel) && nextLevel <= baseLevel) {
      deleteEnd = next.start;
      foundBoundary = true;
      break;
    }
    deletedMappingIndexes.push(idx);
    deleteEnd = Math.max(deleteEnd, next.end);
  }
  if (!foundBoundary) {
    deleteEnd = source.length;
  }
  return {
    deleteRange: {
      start: Math.max(0, Math.min(mapping.start, source.length)),
      end: Math.max(mapping.start, Math.min(deleteEnd, source.length)),
    },
    mappingIndex,
    deletedMappingIndexes,
  };
}

function getEventElementTarget(event) {
  const target = event?.target;
  if (target instanceof Element) return target;
  if (target instanceof Node) return target.parentElement;
  return null;
}

function shouldIgnorePreviewHotkey(event) {
  const el = getEventElementTarget(event);
  if (!el) return false;
  if (el.closest('input, textarea, select, button, [contenteditable="true"], [contenteditable=""]')) {
    return true;
  }
  return false;
}

function updateSourceLineContent(range, newContent) {
  if (!range) return null;
  const source = markdownEl.value || "";
  const safeStart = Math.max(0, Math.min(range.start ?? 0, source.length));
  const safeEnd = Math.max(safeStart, Math.min(range.end ?? safeStart, source.length));
  const lineText = source.slice(safeStart, safeEnd);
  if (!lineText) return null;

  const headingMatch = lineText.match(/^(\s*#{1,}\s+)(.*)$/);
  const listMatch = lineText.match(/^(\s*(?:[-*+]|\d+\.)\s+)(.*)$/);
  let prefix = "";
  let oldContent = lineText;
  if (headingMatch) {
    prefix = headingMatch[1];
    oldContent = headingMatch[2];
  } else if (listMatch) {
    prefix = listMatch[1];
    oldContent = listMatch[2];
  }

  const replacedLine = prefix + (newContent || "");
  if (replacedLine === lineText) {
    return {
      updatedRange: { start: safeStart, end: safeEnd },
      oldRange: { start: safeStart, end: safeEnd },
      oldContent,
      newContent: newContent || "",
      delta: 0,
    };
  }
  const nextSource = source.slice(0, safeStart) + replacedLine + source.slice(safeEnd);
  markdownEl.value = nextSource;
  return {
    updatedRange: { start: safeStart, end: safeStart + replacedLine.length },
    oldRange: { start: safeStart, end: safeEnd },
    oldContent,
    newContent: newContent || "",
    delta: replacedLine.length - lineText.length,
  };
}

function deleteSourceRange(range) {
  if (!range) return null;
  const source = markdownEl.value || "";
  const prevScrollTop = markdownEl.scrollTop;
  const safeStart = Math.max(0, Math.min(range.start ?? 0, source.length));
  const safeEnd = Math.max(safeStart, Math.min(range.end ?? safeStart, source.length));
  if (safeStart === safeEnd) return null;

  let removeStart = safeStart;
  let removeEnd = safeEnd;
  const nextChar = source.slice(removeEnd, removeEnd + 1);
  const prevChar = removeEnd > 0 ? source.slice(removeEnd - 1, removeEnd) : "";

  // If the range ends at line text boundary, include its trailing newline.
  // If it already ends at the next line's start, keep the boundary as-is.
  if (nextChar === "\n") {
    removeEnd += 1;
  } else if (removeEnd >= source.length && removeStart > 0 && source.slice(removeStart - 1, removeStart) === "\n") {
    // When deleting the tail section, remove the leading newline before it.
    removeStart -= 1;
  } else if (prevChar === "\n") {
    // The provided range already spans whole lines and ends at the next line start.
    removeEnd = safeEnd;
  }

  const nextSource = source.slice(0, removeStart) + source.slice(removeEnd);
  markdownEl.value = nextSource;
  // Keep editor viewport stable; do not force caret focus jump.
  markdownEl.scrollTop = Math.max(0, Math.min(prevScrollTop, markdownEl.scrollHeight));
  return {
    removedRange: { start: removeStart, end: removeEnd },
    cursor: removeStart,
    delta: removeStart - removeEnd,
  };
}

function applyInlineNodeLabel(nodeGroup, newText) {
  if (!nodeGroup) return;
  const labelEl = getNodeLabelElement(nodeGroup);
  if (!labelEl) return;
  labelEl.textContent = newText;

  // Sync bound markmap data so internal rerender won't restore old text.
  const datum = nodeGroup.__data__;
  if (datum?.data && typeof datum.data === "object") {
    datum.data.content = newText;
  }

  // Some markmap labels are rendered via foreignObject with fixed width.
  // Expand width/height after editing to avoid clipping updated text.
  const foreignObject = nodeGroup.querySelector("foreignObject");
  if (foreignObject) {
    const target = foreignObject.querySelector("[data-node-label]") || foreignObject.firstElementChild;
    if (target) {
      target.textContent = newText;
      const style = window.getComputedStyle(target);
      const font = style.font && style.font !== "normal normal normal normal 16px / normal Arial"
        ? style.font
        : `${style.fontWeight || "400"} ${style.fontSize || "14px"} ${style.fontFamily || "sans-serif"}`;
      let contentW = Math.ceil(target.scrollWidth || target.clientWidth || 0);
      if ((!contentW || contentW < 8) && textMeasureCtx) {
        textMeasureCtx.font = font;
        contentW = Math.ceil(textMeasureCtx.measureText(newText || "").width);
      }
      const parsedLineHeight = Number.parseFloat(style.lineHeight || "");
      const contentH = Math.ceil(
        target.scrollHeight ||
          target.clientHeight ||
          (Number.isFinite(parsedLineHeight) ? parsedLineHeight : 20)
      );
      const prevW = Number(foreignObject.getAttribute("width") || 0);
      const prevH = Number(foreignObject.getAttribute("height") || 0);
      const nextW = Math.max(prevW, contentW + 24, 56);
      const nextH = Math.max(prevH, contentH + 6, 20);
      foreignObject.setAttribute("width", String(nextW));
      foreignObject.setAttribute("height", String(nextH));
      foreignObject.style.overflow = "visible";
      if (target.style) {
        target.style.width = `${nextW - 8}px`;
        target.style.minWidth = `${nextW - 8}px`;
      }

      const x = Number(foreignObject.getAttribute("x") || 0);
      if (x < 0 && nextW > prevW && prevW > 0) {
        foreignObject.setAttribute("x", String(x - (nextW - prevW)));
      }
    }
  }
  const hitbox = nodeGroup.querySelector('rect[data-node-hitbox="1"]');
  if (hitbox) hitbox.remove();
  ensureNodeHitbox(nodeGroup);
}

function markPreviewNodeDeleted(nodeGroup, deleted = true) {
  if (!nodeGroup) return;
  nodeGroup.dataset.nodeDeleted = deleted ? "1" : "0";
  const labelEl = getNodeLabelElement(nodeGroup);
  if (labelEl) {
    labelEl.style.opacity = deleted ? "0.55" : "";
    labelEl.style.textDecoration = deleted ? "line-through" : "";
    labelEl.style.fill = deleted ? "#94a3b8" : "";
  }
  const hitbox = ensureNodeHitbox(nodeGroup);
  if (hitbox) {
    hitbox.setAttribute("fill", deleted ? "rgba(148,163,184,0.10)" : "transparent");
    hitbox.setAttribute("stroke", deleted ? "rgba(148,163,184,0.6)" : "none");
    hitbox.setAttribute("stroke-dasharray", deleted ? "4 3" : "");
  }
  const datum = nodeGroup.__data__;
  if (datum?.data && typeof datum.data === "object") {
    datum.data._deleted = deleted;
  }
}

function getPreviewSubtreeGroups(targetGroup) {
  if (!targetGroup) return [];
  const doc = targetGroup.ownerDocument;
  if (!doc) return [targetGroup];
  const rootDatum = targetGroup.__data__;
  if (!rootDatum) return [targetGroup];

  const subtreeData = new Set();
  const stack = [rootDatum];
  while (stack.length) {
    const datum = stack.pop();
    if (!datum || subtreeData.has(datum)) continue;
    subtreeData.add(datum);
    if (Array.isArray(datum.children)) {
      for (const child of datum.children) stack.push(child);
    }
  }

  const groups = getNodeGroups(doc).filter((group) => subtreeData.has(group.__data__));
  return groups.length ? groups : [targetGroup];
}

function applyDeletedPlaceholderToGroup(nodeGroup) {
  if (!nodeGroup) return;
  const labelEl = getNodeLabelElement(nodeGroup);
  if (!labelEl) return;
  if (!nodeGroup.dataset.nodeDeletedOriginalText) {
    nodeGroup.dataset.nodeDeletedOriginalText = getNodeTextFromGroup(nodeGroup);
  }
  applyInlineNodeLabel(nodeGroup, DELETED_NODE_PLACEHOLDER);
  markPreviewNodeDeleted(nodeGroup, true);
}

function softDeleteNode(targetGroup) {
  if (!targetGroup) return false;
  if (targetGroup.dataset.nodeDeleted === "1") return false;
  const deletePlan = resolveSourceDeletePlanByNode(targetGroup);
  if (!deletePlan?.deleteRange) return false;
  const deletedGroups = getPreviewSubtreeGroups(targetGroup);
  const deleted = deleteSourceRange(deletePlan.deleteRange);
  if (!deleted) return false;
  patchNodeMappingsAfterDelete(deletePlan, deleted);
  deletedGroups.forEach((group) => {
    applyDeletedPlaceholderToGroup(group);
  });
  setPersistentSourceHighlight({ start: deleted.cursor, end: deleted.cursor });
  return true;
}

function getActivePreviewNode() {
  const iframe = document.getElementById("previewFrame");
  const doc = iframe?.contentDocument;
  if (!doc) return null;
  return doc.querySelector('g[data-node-active="1"]');
}

function handleGlobalDeleteForActiveNode(event) {
  const key = event.key;
  if (key !== "Delete" && key !== "Backspace") return;
  if (shouldIgnorePreviewHotkey(event)) return;
  const active = getActivePreviewNode();
  if (!active) return;
  if (active.dataset.nodeEditing === "1") return;
  if (active.dataset.nodeDeleted === "1") return;
  event.preventDefault();
  event.stopPropagation();
  if (typeof event.stopImmediatePropagation === "function") {
    event.stopImmediatePropagation();
  }
  softDeleteNode(active);
}

function handleGlobalTypeForActiveNode(event) {
  if (event.defaultPrevented) return;
  if (event.ctrlKey || event.metaKey || event.altKey) return;
  if (event.isComposing) return;
  if (shouldIgnorePreviewHotkey(event)) return;
  const key = event.key;
  const isDirectTextInput = Boolean(key && key.length === 1);
  const isEditTrigger =
    key === "Enter" ||
    key === "F2" ||
    key === "Process" ||
    key === "Unidentified" ||
    key === "Dead" ||
    event.keyCode === 229;
  if (!isDirectTextInput && !isEditTrigger) return;
  const active = getActivePreviewNode();
  if (!active) return;
  if (active.dataset.nodeEditing === "1") return;
  if (active.dataset.nodeDeleted === "1") return;
  event.preventDefault();
  event.stopPropagation();
  if (typeof event.stopImmediatePropagation === "function") {
    event.stopImmediatePropagation();
  }
  startNodeInlineEdit(active, isDirectTextInput ? { appendWith: key } : {});
}

function patchNodeMappingsAfterEdit(nodeIndex, editResult) {
  if (!editResult) return;
  const oldRange = editResult.oldRange;
  const updatedRange = editResult.updatedRange;
  const delta = editResult.delta || 0;
  if (!oldRange || !updatedRange) return;

  lastRenderNodeMappings = lastRenderNodeMappings.map((mapping, idx) => {
    if (!mapping) return mapping;
    if (idx === nodeIndex) {
      return {
        ...mapping,
        start: updatedRange.start,
        end: updatedRange.end,
        text: editResult.newContent,
      };
    }
    if (mapping.start >= oldRange.end) {
      return {
        ...mapping,
        start: mapping.start + delta,
        end: mapping.end + delta,
      };
    }
    return mapping;
  });
}

function patchNodeMappingsAfterDelete(deletePlan, deleteResult) {
  if (!deleteResult) return;
  const removedRange = deleteResult.removedRange;
  const delta = deleteResult.delta || 0;
  if (!removedRange) return;
  const deletedIndexes = new Set(deletePlan?.deletedMappingIndexes || []);

  lastRenderNodeMappings = lastRenderNodeMappings.map((mapping, idx) => {
    if (!mapping) return mapping;
    if (deletedIndexes.has(idx)) {
      return {
        ...mapping,
        start: removedRange.start,
        end: removedRange.start,
        text: DELETED_NODE_PLACEHOLDER,
        deleted: true,
      };
    }
    if (mapping.start >= removedRange.end) {
      return {
        ...mapping,
        start: mapping.start + delta,
        end: mapping.end + delta,
      };
    }
    return mapping;
  });
}

function reindexPreviewNodeGroups(doc) {
  if (!doc) return;
  const nodeGroups = getNodeGroups(doc);
  const textCounts = new Map();
  nodeGroups.forEach((group, index) => {
    group.dataset.nodeIndex = String(index);
    const text = getNodeTextFromGroup(group);
    const occurrence = textCounts.get(text) || 0;
    group.dataset.nodeTextOccurrence = String(occurrence);
    textCounts.set(text, occurrence + 1);
  });
}

function removePreviewNode(targetGroup) {
  const doc = targetGroup?.ownerDocument;
  if (!targetGroup || !doc) return;
  if (targetGroup.dataset.nodeActive === "1") {
    targetGroup.dataset.nodeActive = "0";
  }
  targetGroup.remove();
  reindexPreviewNodeGroups(doc);
}

function removeMarkmapDataNode(targetGroup) {
  const datum = targetGroup?.__data__;
  if (!datum || !datum.parent) return false;

  const parent = datum.parent;
  if (Array.isArray(parent.children)) {
    const idx = parent.children.indexOf(datum);
    if (idx >= 0) parent.children.splice(idx, 1);
  }

  // Keep source data tree in sync to prevent Markmap redraw bringing node back.
  const parentDataChildren = parent.data?.children;
  if (Array.isArray(parentDataChildren)) {
    const dataIdx = parentDataChildren.indexOf(datum.data);
    if (dataIdx >= 0) {
      parentDataChildren.splice(dataIdx, 1);
    } else {
      const text = (datum.data?.content || "").trim();
      const looseIdx = parentDataChildren.findIndex(
        (c) => (c?.content || "").trim() === text
      );
      if (looseIdx >= 0) parentDataChildren.splice(looseIdx, 1);
    }
  }
  return true;
}

function startNodeInlineEdit(targetGroup, options = {}) {
  const { appendWith = null } = options;
  if (!targetGroup) return;
  if (targetGroup.dataset.nodeEditing === "1") return;
  const range = resolveSourceRangeByNode(targetGroup);
  if (!range) return;
  revealSourceByRange(range);

  const labelEl = getNodeLabelElement(targetGroup);
  if (!labelEl || !labelEl.getBBox) return;
  const labelBox = labelEl.getBBox();
  if (!labelBox || labelBox.width <= 0 || labelBox.height <= 0) return;

  const doc = targetGroup.ownerDocument;
  const svgNs = "http://www.w3.org/2000/svg";
  const xhtmlNs = "http://www.w3.org/1999/xhtml";

  const editor = doc.createElementNS(svgNs, "foreignObject");
  editor.dataset.nodeInlineEditor = "1";
  const initialEditorX = labelBox.x - 6;
  const initialEditorWidth = Math.max(120, labelBox.width + 18);
  const baseEditorHeight = Math.max(30, labelBox.height + 10);
  editor.setAttribute("x", String(initialEditorX));
  editor.setAttribute("y", String(labelBox.y - 4));
  editor.setAttribute("width", String(initialEditorWidth));
  editor.setAttribute("height", String(baseEditorHeight));
  editor.style.overflow = "visible";

  const wrapper = doc.createElementNS(xhtmlNs, "div");
  wrapper.style.width = "100%";
  wrapper.style.height = "100%";
  wrapper.style.display = "flex";
  wrapper.style.alignItems = "center";
  wrapper.style.background = "#ffffff";
  wrapper.style.border = "1px solid #2563eb";
  wrapper.style.borderRadius = "6px";
  wrapper.style.boxSizing = "border-box";
  wrapper.style.padding = "2px 6px";

  const input = doc.createElementNS(xhtmlNs, "input");
  input.type = "text";
  input.value = getNodeTextFromGroup(targetGroup);
  const labelStyle = doc.defaultView?.getComputedStyle(labelEl);
  const inputFont =
    labelStyle?.font && labelStyle.font !== "normal normal normal normal 16px / normal Arial"
      ? labelStyle.font
      : `${labelStyle?.fontWeight || "400"} ${labelStyle?.fontSize || "14px"} ${labelStyle?.fontFamily || "sans-serif"}`;
  input.style.width = "100%";
  input.style.height = "100%";
  input.style.border = "none";
  input.style.outline = "none";
  input.style.font = inputFont;
  input.style.background = "transparent";
  input.style.boxSizing = "border-box";
  input.style.minWidth = "0";

  wrapper.appendChild(input);
  editor.appendChild(wrapper);
  targetGroup.appendChild(editor);
  targetGroup.dataset.nodeEditing = "1";
  labelEl.style.visibility = "hidden";

  const syncInlineEditorSize = () => {
    const value = input.value || " ";
    let contentWidth = Math.ceil(input.scrollWidth || 0);
    if (textMeasureCtx) {
      textMeasureCtx.font = inputFont;
      contentWidth = Math.max(contentWidth, Math.ceil(textMeasureCtx.measureText(value).width) + 2);
    }
    const nextWidth = Math.max(initialEditorWidth, contentWidth + 24, 120);
    editor.setAttribute("width", String(nextWidth));
    editor.setAttribute("height", String(baseEditorHeight));
    if (initialEditorX < 0 && nextWidth > initialEditorWidth) {
      editor.setAttribute("x", String(initialEditorX - (nextWidth - initialEditorWidth)));
    } else {
      editor.setAttribute("x", String(initialEditorX));
    }
  };
  syncInlineEditorSize();

  let didApplyInitialAppend = false;
  let protectExistingTextOnFirstInsert = true;
  const moveCaretToEnd = () => {
    const end = input.value.length;
    try {
      input.setSelectionRange(end, end);
    } catch {
      // Ignore selection errors from embedded foreignObject inputs.
    }
  };
  const applyInitialAppend = () => {
    if (didApplyInitialAppend) return;
    if (typeof appendWith !== "string" || !appendWith) return;
    didApplyInitialAppend = true;
    const end = input.value.length;
    if (typeof input.setRangeText === "function") {
      input.setRangeText(appendWith, end, end, "end");
    } else {
      input.value += appendWith;
      moveCaretToEnd();
    }
    syncInlineEditorSize();
  };
  const preserveExistingTextBeforeFirstInsert = () => {
    if (!protectExistingTextOnFirstInsert) return;
    if (!input.value) return;
    if (input.selectionStart !== 0 || input.selectionEnd !== input.value.length) return;
    moveCaretToEnd();
  };

  const stopEdit = (commit, reason = "unknown") => {
    if (targetGroup.dataset.nodeEditing !== "1") return;
    targetGroup.dataset.nodeEditing = "0";
    labelEl.style.visibility = "";
    editor.remove();
    if (!commit) return;
    const nextText = (input.value || "").trim();
    if (!nextText) {
      // Only Enter confirms "soft delete" when text is empty.
      if (reason !== "enter") return;
      softDeleteNode(targetGroup);
      return;
    }
    const nodeIndex = Number(targetGroup.dataset.nodeIndex || "-1");
    const editResult = updateSourceLineContent(range, nextText);
    if (!editResult) return;
    const didTextChange = editResult.oldContent !== editResult.newContent;
    applyInlineNodeLabel(targetGroup, nextText);
    markPreviewNodeDeleted(targetGroup, false);
    patchNodeMappingsAfterEdit(nodeIndex, editResult);
    revealSourceByRange(editResult.updatedRange);
    if (didTextChange) {
      setPendingPreviewAnchorFromNode(targetGroup);
      renderPreview();
    }
  };

  input.addEventListener("input", syncInlineEditorSize);
  input.addEventListener("beforeinput", (e) => {
    if (typeof e.inputType === "string" && e.inputType.startsWith("insert")) {
      preserveExistingTextBeforeFirstInsert();
      protectExistingTextOnFirstInsert = false;
    }
  });
  input.addEventListener("compositionstart", preserveExistingTextBeforeFirstInsert);
  input.addEventListener("focus", () => {
    requestAnimationFrame(() => {
      moveCaretToEnd();
    });
  });
  input.addEventListener("pointerdown", () => {
    protectExistingTextOnFirstInsert = false;
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      stopEdit(true, "enter");
    } else if (e.key === "Escape") {
      e.preventDefault();
      stopEdit(false, "escape");
    } else {
      preserveExistingTextBeforeFirstInsert();
    }
  });
  input.addEventListener("blur", () => stopEdit(true, "blur"));
  setTimeout(() => {
    input.focus();
    syncInlineEditorSize();
    requestAnimationFrame(() => {
      moveCaretToEnd();
      applyInitialAppend();
      requestAnimationFrame(() => {
        moveCaretToEnd();
      });
    });
  }, 0);
}

function bindPreviewNodeLinking(iframe) {
  const doc = iframe?.contentDocument;
  if (!doc) return;

  if (doc.body && !doc.body.hasAttribute("tabindex")) {
    doc.body.tabIndex = -1;
  }
  if (!doc.body?.dataset.deleteHotkeyBound) {
    doc.body.dataset.deleteHotkeyBound = "1";
    doc.addEventListener("keydown", handleGlobalDeleteForActiveNode, true);
  }
  if (!doc.body?.dataset.previewInteractionBound) {
    doc.body.dataset.previewInteractionBound = "1";
    doc.addEventListener("wheel", handlePreviewWheelInteraction, { passive: false });
    doc.addEventListener("pointerdown", cancelPendingPreviewRestore, true);
    doc.addEventListener("touchstart", cancelPendingPreviewRestore, { passive: true });
  }
  bindPreviewGestureZoom(doc);
  bindPreviewPointerPan(doc);

  const bind = () => {
    const nodeGroups = getNodeGroups(doc);
    const textCounts = new Map();
    nodeGroups.forEach((group, index) => {
      ensureNodeHitbox(group);
      if (group.dataset.sourceLinked === "1") return;
      group.dataset.sourceLinked = "1";
      group.style.cursor = "pointer";
      group.dataset.nodeIndex = String(index);
      group.dataset.nodeSynthetic = lastRenderNodeMappings[index]?.synthetic ? "1" : "0";
      const groupText = getNodeTextFromGroup(group);
      if (group.__data__?.data?._deleted) {
        markPreviewNodeDeleted(group, true);
      }
      const occurrence = textCounts.get(groupText) || 0;
      group.dataset.nodeTextOccurrence = String(occurrence);
      textCounts.set(groupText, occurrence + 1);
      group.addEventListener("click", (event) => {
        // Fully own node click behavior and block Markmap's default toggle/fold handling.
        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === "function") {
          event.stopImmediatePropagation();
        }
        if (doc.body?.dataset.previewSuppressClick === "1") return;
        const targetGroup = event.currentTarget;
        if (targetGroup.dataset.nodeDeleted === "1") return;
        const wasActive = targetGroup.dataset.nodeActive === "1";
        setActiveNode(targetGroup);
        if (typeof doc.body?.focus === "function") {
          try {
            doc.body.focus({ preventScroll: true });
          } catch {
            doc.body.focus();
          }
        }
        if (wasActive) {
          startNodeInlineEdit(targetGroup);
          return;
        }
        const range = resolveSourceRangeByNode(targetGroup);
        if (range) {
          revealSourceByRange(range);
        }
      });
      group.addEventListener("dblclick", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === "function") {
          event.stopImmediatePropagation();
        }
        const targetGroup = event.currentTarget;
        if (targetGroup.dataset.nodeDeleted === "1") return;
        setActiveNode(targetGroup);
        startNodeInlineEdit(targetGroup);
      });
    });
    if (!nodeGroups.length) setTimeout(bind, 120);
  };

  bind();
}

async function exportXmind() {
  const md = normalizeEscapedNewlines(markdownEl.value || "").trim();
  if (!md) {
    showError("请先输入 Markdown 内容");
    return;
  }

  const defaultName = `mindmap-${Date.now()}`;
  const input = window.prompt("请输入导出文件名：", defaultName);
  if (input == null) return;
  const rawName = (input || "").trim() || defaultName;
  const fileName = rawName.endsWith(".xmind") ? rawName : rawName + ".xmind";

  convertBtn.disabled = true;
  hideError();

  try {
    const res = await fetch("/api/markdown/convert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ markdown: md }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || "转换失败");
    }

    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(a.href);
  } catch (e) {
    showError(e.message || "导出失败");
  } finally {
    convertBtn.disabled = false;
  }
}

async function toggleFullscreen() {
  if (!previewPanelEl) return;
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await previewPanelEl.requestFullscreen();
    }
  } catch (_) {
    showError("浏览器不支持全屏或当前环境禁止全屏");
  }
}

function syncFullscreenButton() {
  if (!fullscreenBtn) return;
  fullscreenBtn.textContent = document.fullscreenElement ? "退出全屏" : "全屏";
  scheduleFullscreenFit();
}

function fitPreviewToViewport(options = {}) {
  const { padding = 24, cancelRestore = true } = options;
  const { svg, g } = getPreviewSvgAndGroup();
  if (!svg || !g) return false;
  const box = g.getBBox?.();
  const viewW = svg.clientWidth || 0;
  const viewH = svg.clientHeight || 0;
  if (!box || box.width <= 0 || box.height <= 0 || viewW <= 0 || viewH <= 0) return false;
  if (cancelRestore) {
    cancelPendingPreviewRestore();
  }
  const scale = Math.min((viewW - padding * 2) / box.width, (viewH - padding * 2) / box.height);
  const safeScale = Math.max(0.1, scale);
  const tx = (viewW - box.width * safeScale) / 2 - box.x * safeScale;
  const ty = (viewH - box.height * safeScale) / 2 - box.y * safeScale;
  return setPreviewTransform(tx, ty, safeScale);
}

function applyFullscreenFit() {
  const { svg, g } = getPreviewSvgAndGroup();
  if (!svg || !g) return;
  if (pendingPreviewRestoreTransform || pendingPreviewRestoreZoom || pendingPreviewRestoreAnchor) return;

  if (document.fullscreenElement === previewPanelEl) {
    if (!fullscreenFitBackup || fullscreenFitBackup.svg !== svg) {
      fullscreenFitBackup = {
        svg,
        transform: g.getAttribute("transform") || "",
      };
    }
    // Reset to original before measuring to avoid cumulative scaling.
    g.setAttribute("transform", fullscreenFitBackup.transform);
    fitPreviewToViewport({ padding: 24, cancelRestore: false });
  } else {
    if (fullscreenFitBackup && fullscreenFitBackup.svg === svg) {
      g.setAttribute("transform", fullscreenFitBackup.transform);
      fullscreenFitBackup = null;
    }
  }
}

function scheduleFullscreenFit() {
  // Markmap is rendered asynchronously; retry a few times.
  let tries = 0;
  const tick = () => {
    tries += 1;
    applyFullscreenFit();
    if (tries < 12) setTimeout(tick, 120);
  };
  tick();
}

function scheduleInitialPreviewFit() {
  if (!shouldAutoFitPreviewOnLoad) return;
  if (pendingPreviewRestoreTransform || pendingPreviewRestoreZoom || pendingPreviewRestoreAnchor) return;
  const token = previewRestoreToken;
  let tries = 0;
  const tick = () => {
    if (!shouldAutoFitPreviewOnLoad || token !== previewRestoreToken) return;
    tries += 1;
    const iframe = document.getElementById("previewFrame");
    const doc = iframe?.contentDocument;
    const nodeCount = doc ? getNodeGroups(doc).length : 0;
    const readyForFit = nodeCount > 1 || tries > 4;
    if (readyForFit) {
      fitPreviewToViewport({ padding: 24, cancelRestore: false });
    }
    if (tries < 18) {
      setTimeout(tick, 120);
    } else {
      shouldAutoFitPreviewOnLoad = false;
    }
  };
  tick();
}

function parseTransform(transformValue) {
  const text = (transformValue || "").trim();
  const matrix = text.match(
    /matrix\(\s*([-\d.]+)\s*,\s*([-\d.]+)\s*,\s*([-\d.]+)\s*,\s*([-\d.]+)\s*,\s*([-\d.]+)\s*,\s*([-\d.]+)\s*\)/i
  );
  if (matrix) {
    const a = Number(matrix[1] || 1);
    const d = Number(matrix[4] || a || 1);
    const scale = Number.isFinite(a) && a !== 0 ? a : d || 1;
    return {
      tx: Number(matrix[5] || 0),
      ty: Number(matrix[6] || 0),
      scale: Number.isFinite(scale) && scale > 0 ? scale : 1,
    };
  }
  const m = text.match(
    /translate\(\s*([-\d.]+)(?:[,\s]+([-\d.]+))?\s*\)\s*(?:scale\(\s*([-\d.]+)\s*\))?/i
  );
  if (!m) return null;
  return {
    tx: Number(m[1] || 0),
    ty: Number(m[2] || 0),
    scale: Number(m[3] || 1),
  };
}

function setPreviewTransform(tx, ty, scale) {
  const { svg, g } = getPreviewSvgAndGroup();
  if (!g) return false;
  const nextScale = Math.max(0.08, Math.min(Number(scale) || 1, 8));
  g.setAttribute("transform", `translate(${tx} ${ty}) scale(${nextScale})`);
  if (svg) {
    svg.__zoom = { x: tx, y: ty, k: nextScale };
  }
  return true;
}

function getPreviewViewportCenter() {
  const { svg } = getPreviewSvgAndGroup();
  if (!svg) return null;
  const rect = svg.getBoundingClientRect();
  if (!rect || rect.width <= 0 || rect.height <= 0) return null;
  return {
    clientX: rect.left + rect.width / 2,
    clientY: rect.top + rect.height / 2,
  };
}

function panPreviewByWheelDelta(deltaX, deltaY) {
  const { g } = getPreviewSvgAndGroup();
  if (!g) return false;
  const current = parseTransform(g.getAttribute("transform"));
  if (!current) return false;
  // User started interacting; cancel any pending restore to avoid snap-back.
  cancelPendingPreviewRestore();
  const tx = current.tx - deltaX;
  const ty = current.ty - deltaY;
  return setPreviewTransform(tx, ty, current.scale);
}

function zoomPreviewByFactor(factor, clientX = null, clientY = null) {
  const { svg, g } = getPreviewSvgAndGroup();
  if (!svg || !g) return false;
  const current = parseTransform(g.getAttribute("transform"));
  if (!current) return false;
  const rect = svg.getBoundingClientRect();
  if (!rect || rect.width <= 0 || rect.height <= 0) return false;
  const anchorX = Number.isFinite(clientX) ? clientX - rect.left : rect.width / 2;
  const anchorY = Number.isFinite(clientY) ? clientY - rect.top : rect.height / 2;
  if (!Number.isFinite(anchorX) || !Number.isFinite(anchorY)) return false;
  const safeFactor = Number(factor) || 1;
  if (!Number.isFinite(safeFactor) || safeFactor <= 0) return false;
  cancelPendingPreviewRestore();
  const nextScale = Math.max(0.08, Math.min(current.scale * safeFactor, 8));
  if (Math.abs(nextScale - current.scale) < 0.0001) return false;
  const graphX = (anchorX - current.tx) / current.scale;
  const graphY = (anchorY - current.ty) / current.scale;
  const nextTx = anchorX - graphX * nextScale;
  const nextTy = anchorY - graphY * nextScale;
  return setPreviewTransform(nextTx, nextTy, nextScale);
}

function normalizeWheelDelta(delta, deltaMode = 0) {
  const raw = Number(delta) || 0;
  if (!raw) return 0;
  if (deltaMode === 1) return raw * 16;
  if (deltaMode === 2) return raw * window.innerHeight;
  return raw;
}

function zoomPreviewAtClientPoint(clientX, clientY, deltaY) {
  const wheelDelta = Number(deltaY) || 0;
  if (Math.abs(wheelDelta) < 0.01) return false;
  const scaleFactor = Math.exp(-wheelDelta * PREVIEW_WHEEL_ZOOM_SENSITIVITY);
  return zoomPreviewByFactor(scaleFactor, clientX, clientY);
}

function flushQueuedWheelZoom() {
  pendingWheelZoomFrame = 0;
  const deltaY = pendingWheelZoomDelta;
  const clientX = pendingWheelZoomClientX;
  const clientY = pendingWheelZoomClientY;
  pendingWheelZoomDelta = 0;
  pendingWheelZoomClientX = null;
  pendingWheelZoomClientY = null;
  if (Math.abs(deltaY) < 0.01) return false;
  return zoomPreviewAtClientPoint(clientX, clientY, deltaY);
}

function queueWheelZoom(clientX, clientY, deltaY, deltaMode = 0) {
  const normalizedDelta = normalizeWheelDelta(deltaY, deltaMode);
  if (Math.abs(normalizedDelta) < 0.01) return false;
  pendingWheelZoomDelta += normalizedDelta;
  if (Number.isFinite(clientX)) pendingWheelZoomClientX = clientX;
  if (Number.isFinite(clientY)) pendingWheelZoomClientY = clientY;
  if (!pendingWheelZoomFrame) {
    pendingWheelZoomFrame = window.requestAnimationFrame(() => {
      flushQueuedWheelZoom();
    });
  }
  return true;
}

function shouldZoomPreviewWheel(event) {
  if (!event) return false;
  // In Chromium-based browsers, trackpad pinch is surfaced as wheel + ctrlKey.
  return Boolean(event.ctrlKey);
}

function shouldPanPreviewWheel(event) {
  if (!event) return false;
  return Math.abs(event.deltaX) >= 1 || Math.abs(event.deltaY) >= 1;
}

function handlePreviewWheelInteraction(event) {
  const target = event?.target;
  if (
    event?.currentTarget === previewPanelEl &&
    target &&
    typeof target.closest === "function" &&
    !target.closest(".mindmap-container") &&
    target.id !== "previewFrame"
  ) {
    return;
  }
  if (shouldZoomPreviewWheel(event)) {
    const didZoom = queueWheelZoom(
      event.clientX,
      event.clientY,
      event.deltaY || 0,
      event.deltaMode || 0
    );
    if (!didZoom) return;
    event.preventDefault();
    event.stopPropagation();
    return;
  }
  if (!shouldPanPreviewWheel(event)) return;
  const didPan = panPreviewByWheelDelta(event.deltaX || 0, event.deltaY || 0);
  if (!didPan) return;
  // Keep scroll gestures inside preview area instead of bubbling to page scroll.
  event.preventDefault();
  event.stopPropagation();
}

function bindPreviewGestureZoom(doc) {
  if (!doc?.body) return;
  if (doc.body.dataset.previewGestureZoomBound === "1") return;
  doc.body.dataset.previewGestureZoomBound = "1";
  let gestureState = null;

  const flushGestureZoom = () => {
    if (!gestureState) return;
    gestureState.frameId = 0;
    const nextScale = gestureState.nextScale;
    if (!Number.isFinite(nextScale)) return;
    const graphX = (gestureState.anchorX - gestureState.tx) / gestureState.scale;
    const graphY = (gestureState.anchorY - gestureState.ty) / gestureState.scale;
    const nextTx = gestureState.anchorX - graphX * nextScale;
    const nextTy = gestureState.anchorY - graphY * nextScale;
    setPreviewTransform(nextTx, nextTy, nextScale);
  };

  const finishGesture = () => {
    if (gestureState?.frameId) {
      window.cancelAnimationFrame(gestureState.frameId);
    }
    gestureState = null;
  };

  doc.addEventListener(
    "gesturestart",
    (event) => {
      const targetEl = event.target;
      if (targetEl && typeof targetEl.closest === "function" && !targetEl.closest("svg")) return;
      const { svg, g } = getPreviewSvgAndGroup();
      if (!svg || !g) return;
      const current = parseTransform(g.getAttribute("transform"));
      if (!current) return;
      const rect = svg.getBoundingClientRect();
      if (!rect || rect.width <= 0 || rect.height <= 0) return;
      cancelPendingPreviewRestore();
      const anchorX = Number.isFinite(event.clientX) ? event.clientX - rect.left : rect.width / 2;
      const anchorY = Number.isFinite(event.clientY) ? event.clientY - rect.top : rect.height / 2;
      gestureState = {
        tx: current.tx,
        ty: current.ty,
        scale: current.scale,
        anchorX,
        anchorY,
        nextScale: current.scale,
        frameId: 0,
      };
      event.preventDefault();
      event.stopPropagation();
    },
    { passive: false }
  );

  doc.addEventListener(
    "gesturechange",
    (event) => {
      if (!gestureState) return;
      gestureState.nextScale = Math.max(
        0.08,
        Math.min(gestureState.scale * (Number(event.scale) || 1), 8)
      );
      if (!gestureState.frameId) {
        gestureState.frameId = window.requestAnimationFrame(() => {
          flushGestureZoom();
        });
      }
      event.preventDefault();
      event.stopPropagation();
    },
    { passive: false }
  );

  doc.addEventListener("gestureend", finishGesture, true);
  doc.addEventListener("gesturecancel", finishGesture, true);
}

function bindPreviewPointerPan(doc) {
  if (!doc?.body) return;
  if (doc.body.dataset.previewPointerPanBound === "1") return;
  doc.body.dataset.previewPointerPanBound = "1";
  let dragState = null;

  const finishDrag = () => {
    if (!dragState) return;
    const { captureTarget, dragged } = dragState;
    if (captureTarget && typeof captureTarget.releasePointerCapture === "function") {
      try {
        captureTarget.releasePointerCapture(dragState.pointerId);
      } catch (_) {}
    }
    const svg = getPreviewSvgAndGroup().svg;
    svg?.classList?.remove("is-dragging");
    dragState = null;
    if (dragged) {
      doc.body.dataset.previewSuppressClick = "1";
      setTimeout(() => {
        if (doc.body) {
          delete doc.body.dataset.previewSuppressClick;
        }
      }, 0);
    }
  };

  doc.addEventListener(
    "pointerdown",
    (event) => {
      if (event.button !== 0) return;
      const targetEl = event.target;
      if (!targetEl || typeof targetEl.closest !== "function") return;
      if (targetEl.closest('[data-node-inline-editor="1"], input, textarea, select, button')) return;
      if (!targetEl.closest("svg")) return;
      const { svg, g } = getPreviewSvgAndGroup();
      if (!svg || !g) return;
      const current = parseTransform(g.getAttribute("transform"));
      if (!current) return;
      cancelPendingPreviewRestore();
      dragState = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        startTx: current.tx,
        startTy: current.ty,
        scale: current.scale,
        dragged: false,
        captureTarget: typeof targetEl.setPointerCapture === "function" ? targetEl : null,
      };
      if (dragState.captureTarget) {
        try {
          dragState.captureTarget.setPointerCapture(event.pointerId);
        } catch (_) {}
      }
    },
    true
  );

  doc.addEventListener(
    "pointermove",
    (event) => {
      if (!dragState || event.pointerId !== dragState.pointerId) return;
      const dx = event.clientX - dragState.startX;
      const dy = event.clientY - dragState.startY;
      if (!dragState.dragged && Math.abs(dx) < 3 && Math.abs(dy) < 3) return;
      dragState.dragged = true;
      const svg = getPreviewSvgAndGroup().svg;
      svg?.classList?.add("is-dragging");
      const didPan = setPreviewTransform(
        dragState.startTx + dx,
        dragState.startTy + dy,
        dragState.scale
      );
      if (!didPan) return;
      event.preventDefault();
      event.stopPropagation();
    },
    true
  );

  doc.addEventListener("pointerup", finishDrag, true);
  doc.addEventListener("pointercancel", finishDrag, true);
}

function shouldCapturePreviewWheel(event) {
  if (!event) return false;
  if (Math.abs(event.deltaX) >= 1) return true;
  if (Math.abs(event.deltaY) < 1) return false;
  const { g } = getPreviewSvgAndGroup();
  const current = g ? parseTransform(g.getAttribute("transform")) : null;
  if (!current) return false;
  const moved = Math.abs(current.tx) > 1 || Math.abs(current.ty) > 1;
  const zoomed = Math.abs(current.scale - 1) > 0.02;
  return moved || zoomed || document.fullscreenElement === previewPanelEl;
}

function bindPreviewInteractionGuards() {
  if (!previewPanelEl) return;
  if (previewPanelEl.dataset.previewInteractionBound === "1") return;
  previewPanelEl.dataset.previewInteractionBound = "1";
  previewPanelEl.addEventListener("wheel", handlePreviewWheelInteraction, { passive: false });
  // Any direct interaction inside preview means user takes control of viewport.
  previewPanelEl.addEventListener("pointerdown", cancelPendingPreviewRestore, { passive: true });
  previewPanelEl.addEventListener("touchstart", cancelPendingPreviewRestore, { passive: true });
}

markdownEl.addEventListener("input", () => {
  normalizeEditorEscapedNewlines();
  updatePersistentSourceHighlightPosition();
  renderPreview();
});
markdownEl.addEventListener("scroll", updatePersistentSourceHighlightPosition);
previewBtn.addEventListener("click", renderPreview);
convertBtn.addEventListener("click", exportXmind);
zoomOutBtn?.addEventListener("click", () => {
  const center = getPreviewViewportCenter();
  zoomPreviewByFactor(1 / PREVIEW_BUTTON_ZOOM_FACTOR, center?.clientX ?? null, center?.clientY ?? null);
});
zoomInBtn?.addEventListener("click", () => {
  const center = getPreviewViewportCenter();
  zoomPreviewByFactor(PREVIEW_BUTTON_ZOOM_FACTOR, center?.clientX ?? null, center?.clientY ?? null);
});
fitViewBtn?.addEventListener("click", () => {
  fitPreviewToViewport();
});
fullscreenBtn?.addEventListener("click", toggleFullscreen);
document.addEventListener("fullscreenchange", syncFullscreenButton);
if (!document.body?.dataset.previewDeleteHotkeyBound) {
  document.body.dataset.previewDeleteHotkeyBound = "1";
}
window.addEventListener("resize", updatePersistentSourceHighlightPosition);
bindPreviewInteractionGuards();

refTestcaseEl?.addEventListener("change", function () {
  const id = this.value;
  if (id) insertTestcaseResult(id);
});

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    applyPrefillMarkdown();
    loadTestcaseList();
    renderPreview();
  });
} else {
  applyPrefillMarkdown();
  loadTestcaseList();
  renderPreview();
}
