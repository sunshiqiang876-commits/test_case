const listLoading = document.getElementById("listLoading");
const listEmpty = document.getElementById("listEmpty");
const resultList = document.getElementById("resultList");
const modal = document.getElementById("modal");
const modalBackdrop = document.getElementById("modalBackdrop");
const modalClose = document.getElementById("modalClose");
const detailMeta = document.getElementById("detailMeta");
const detailOutput = document.getElementById("detailOutput");
const LEGACY_PENDING_GENERATION_KEY = "testcase_pending_generation_v1";
const PENDING_GENERATIONS_KEY = "testcase_pending_generations_v2";
const ACTIVE_PENDING_REQUEST_KEY = "testcase_active_pending_request_v1";

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : str;
  return div.innerHTML;
}

function formatTime(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString("zh-CN");
  } catch {
    return iso;
  }
}

function formatLeafNodeCount(value) {
  return Number.isFinite(value) ? String(value) : "-";
}

function getStageStatusLabel(status) {
  if (status === "succeeded") return "成功";
  if (status === "timed_out") return "超时";
  if (status === "retrying") return "重试中";
  if (status === "running") return "进行中";
  if (status === "failed") return "失败";
  if (status === "hidden") return "未触发";
  return "待执行";
}

function formatStageSummaryText(stageSummary) {
  if (!stageSummary || typeof stageSummary !== "object") return "";
  return Object.values(stageSummary)
    .map((stage) => {
      const parts = [stage?.label || "-", getStageStatusLabel(stage?.status)];
      if (Number.isFinite(stage?.retryCount) && stage.retryCount > 0) {
        parts.push(`重试 ${stage.retryCount} 次`);
      }
      if (stage?.workflowRunId) {
        parts.push(`Workflow Run ID: ${stage.workflowRunId}`);
      }
      if (stage?.message) {
        parts.push(stage.message);
      }
      return parts.join(" · ");
    })
    .join("\n");
}

function truncate(str, len = 80) {
  if (!str || typeof str !== "string") return "";
  return str.length <= len ? str : str.slice(0, len) + "…";
}

function getOutputText(item) {
  const o = item?.outputs;
  if (!o) return "";
  if (typeof o.text === "string") return o.text;
  if (typeof o.result === "string") return o.result;
  return "";
}

function getItemStatus(item) {
  return item?.status === "failed" ? "failed" : "succeeded";
}

function normalizeEscapedNewlines(text) {
  if (typeof text !== "string") return text;
  return text
    .replace(/\\r\\n/g, "\n")
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\n");
}

function normalizeTextForCompare(text) {
  return String(text || "").replace(/\r\n/g, "\n").trim();
}

function getActivePendingRequestId() {
  try {
    return sessionStorage.getItem(ACTIVE_PENDING_REQUEST_KEY) || "";
  } catch {
    return "";
  }
}

function setActivePendingRequestId(requestId) {
  try {
    if (requestId) {
      sessionStorage.setItem(ACTIVE_PENDING_REQUEST_KEY, requestId);
    } else {
      sessionStorage.removeItem(ACTIVE_PENDING_REQUEST_KEY);
    }
  } catch {}
}

function readLegacyPendingGeneration() {
  try {
    const raw = localStorage.getItem(LEGACY_PENDING_GENERATION_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data || !data.prd || !data.tech || !data.startAt) return null;
    return {
      ...data,
      clientRequestId: data.clientRequestId || `legacy-${data.startAt}`,
    };
  } catch {
    return null;
  }
}

function readPendingGenerationList() {
  try {
    const raw = localStorage.getItem(PENDING_GENERATIONS_KEY);
    if (!raw) {
      const legacy = readLegacyPendingGeneration();
      return legacy ? [legacy] : [];
    }
    const data = JSON.parse(raw);
    if (!Array.isArray(data)) return [];
    return data.filter((item) => item && item.prd && item.tech && item.startAt);
  } catch {
    const legacy = readLegacyPendingGeneration();
    return legacy ? [legacy] : [];
  }
}

function writePendingGenerationList(items) {
  try {
    const next = Array.isArray(items) ? items : [];
    if (next.length) {
      localStorage.setItem(PENDING_GENERATIONS_KEY, JSON.stringify(next));
    } else {
      localStorage.removeItem(PENDING_GENERATIONS_KEY);
    }
    localStorage.removeItem(LEGACY_PENDING_GENERATION_KEY);
  } catch {}
}

function readPendingGeneration() {
  const list = readPendingGenerationList();
  if (!list.length) return null;
  const activeRequestId = getActivePendingRequestId();
  if (activeRequestId) {
    const matched = list.find((item) => item.clientRequestId === activeRequestId);
    if (matched) return matched;
  }
  return list[0] || null;
}

function clearPendingGeneration(clientRequestId) {
  const activeRequestId = clientRequestId || getActivePendingRequestId();
  if (!activeRequestId) {
    writePendingGenerationList([]);
    setActivePendingRequestId("");
    return;
  }
  const next = readPendingGenerationList().filter((item) => item.clientRequestId !== activeRequestId);
  writePendingGenerationList(next);
  if (getActivePendingRequestId() === activeRequestId) {
    setActivePendingRequestId(next[0]?.clientRequestId || "");
  }
}

function hasRecoveredInList(items, pending) {
  if (!Array.isArray(items) || !pending) return false;
  if (pending.clientRequestId) {
    return items.some((item) => item.clientRequestId === pending.clientRequestId);
  }
  const prd = normalizeTextForCompare(pending.prd);
  const tech = normalizeTextForCompare(pending.tech);
  const startAt = Number(pending.startAt || 0);
  return items.some((item) => {
    const samePrd = normalizeTextForCompare(item.prd) === prd;
    const sameTech = normalizeTextForCompare(item.tech) === tech;
    if (!samePrd || !sameTech) return false;
    const createdAtMs = item.createdAt ? new Date(item.createdAt).getTime() : 0;
    return !startAt || !createdAtMs || createdAtMs >= startAt - 5000;
  });
}

function appendPendingPlaceholder(pending) {
  if (!pending) return;
  const li = document.createElement("li");
  li.className = "list-item list-item-pending";
  li.innerHTML = `
    <div class="list-item-main">
      <span class="list-item-time">生成中</span>
      <p class="list-item-preview">正在生成测试用例，请稍候…</p>
    </div>
  `;
  resultList.appendChild(li);
}

function openInMindmap(item) {
  const text = normalizeEscapedNewlines(getOutputText(item) || "") || JSON.stringify(item?.outputs || {}, null, 2);
  if (!text) return;
  sessionStorage.setItem("mindmapMarkdown", text);
  window.location.href = "/mindmap";
}

async function loadList() {
  listLoading.hidden = false;
  listEmpty.hidden = true;
  resultList.innerHTML = "";
  const pending = readPendingGeneration();

  try {
    const res = await fetch("/api/testcase/list");
    const data = await res.json();

    if (!data.success || !Array.isArray(data.data)) {
      if (pending) appendPendingPlaceholder(pending);
      listEmpty.hidden = !!pending;
      listEmpty.innerHTML = "加载失败";
      return;
    }

    const items = data.data;
    if (pending && hasRecoveredInList(items, pending)) {
      clearPendingGeneration(pending.clientRequestId);
      resultList.innerHTML = "";
    } else if (pending) {
      // Keep pending placeholder on top.
      appendPendingPlaceholder(pending);
    }

    if (items.length === 0 && !pending) {
      listEmpty.hidden = false;
      return;
    }

    listEmpty.hidden = true;
    items.forEach((item) => {
      const li = document.createElement("li");
      const status = getItemStatus(item);
      li.className = `list-item ${status === "failed" ? "list-item-failed" : ""}`;
      const rawText = getOutputText(item);
      const normalized = normalizeEscapedNewlines(rawText || "");
      const textPreview = normalized ? truncate(normalized, 100) : "(无文本输出)";
      const canOpenMindmap = status !== "failed" && Boolean((normalized || "").trim());
      li.innerHTML = `
        <div class="list-item-main">
          <span class="list-item-time">${escapeHtml(formatTime(item.createdAt))} ${
            status === "failed" ? '<span class="status-badge status-failed">生成失败</span>' : ""
          }</span>
          <p class="list-item-preview">${escapeHtml(textPreview)}</p>
        </div>
        <div class="list-item-actions ${canOpenMindmap ? "" : "list-item-actions-center"}">
          ${canOpenMindmap ? '<button type="button" class="btn btn-outline list-item-mindmap-btn">生成思维导图</button>' : ""}
          <button type="button" class="btn btn-outline list-item-btn">查看</button>
        </div>
      `;
      const btn = li.querySelector(".list-item-btn");
      const mindmapBtn = li.querySelector(".list-item-mindmap-btn");
      btn.addEventListener("click", () => openDetail(item.id));
      mindmapBtn?.addEventListener("click", () => openInMindmap(item));
      resultList.appendChild(li);
    });
  } catch (err) {
    if (pending) appendPendingPlaceholder(pending);
    listEmpty.hidden = false;
    listEmpty.innerHTML = "加载失败：" + escapeHtml(err.message);
  } finally {
    listLoading.hidden = true;
  }
}

async function openDetail(id) {
  try {
    const res = await fetch(`/api/testcase/${id}`);
    const data = await res.json();
    if (!data.success || !data.data) {
      alert("获取详情失败");
      return;
    }
    const item = data.data;
    const status = getItemStatus(item);
    const stageSummaryText = formatStageSummaryText(item.stageSummary || item.outputs?.stageSummary);
    detailMeta.innerHTML = `
      <p><strong>结果 ID：</strong><code class="result-id-copy" title="点击复制">${escapeHtml(item.id || "-")}</code></p>
      <p><strong>Client 请求 ID：</strong>${escapeHtml(item.clientRequestId || "-")}</p>
      <p><strong>生成时间：</strong>${escapeHtml(formatTime(item.createdAt))}</p>
      <p><strong>Workflow Run ID：</strong>${escapeHtml(item.workflowRunId || "-")}</p>
      <p><strong>初始 AI 叶子节点数：</strong>${escapeHtml(formatLeafNodeCount(item.leafNodeCount))}</p>
      <p><strong>状态：</strong>${status === "failed" ? "生成失败" : "生成成功"}</p>
      ${stageSummaryText ? `
      <details class="detail-inputs">
        <summary>工作流阶段</summary>
        <pre>${escapeHtml(stageSummaryText)}</pre>
      </details>` : ""}
      <details class="detail-inputs">
        <summary>需求文档 / 设计文档 输入</summary>
        <pre>${escapeHtml(`需求文档:\n${item.prd || ""}\n\n设计文档:\n${item.tech || ""}`)}</pre>
      </details>
    `;
    const text = normalizeEscapedNewlines(getOutputText(item) || "");
    if (text) {
      detailOutput.innerHTML = `<pre class="output-text">${escapeHtml(text)}</pre>`;
    } else {
      const raw = item.outputs || {};
      const rawStr = typeof raw === "object" && Object.keys(raw).length > 0
        ? JSON.stringify(raw, null, 2)
        : "";
      detailOutput.innerHTML = rawStr
        ? `<pre class="output-text">${escapeHtml(rawStr)}</pre>`
        : '<p class="output-placeholder">暂无输出内容</p>';
    }
    modal.hidden = false;
    document.addEventListener("keydown", onEscape);
  } catch (err) {
    alert("获取详情失败：" + err.message);
  }
}

function closeModal() {
  modal.hidden = true;
  document.removeEventListener("keydown", onEscape);
}

function onEscape(e) {
  if (e.key === "Escape") closeModal();
}

modalBackdrop.addEventListener("click", (e) => {
  e.stopPropagation();
  closeModal();
});

if (modalClose) {
  modalClose.addEventListener("click", (e) => {
    e.preventDefault();
    closeModal();
  });
}

document.addEventListener("click", (e) => {
  const el = e.target.closest(".result-id-copy");
  if (!el || !el.textContent?.trim()) return;
  const text = el.textContent.trim();
  if (!navigator.clipboard?.writeText) return;
  e.preventDefault();
  navigator.clipboard.writeText(text).then(() => {
    el.classList.add("is-copied");
    setTimeout(() => el.classList.remove("is-copied"), 900);
  });
});

loadList();
