(() => {
  const DOC_PARSER_API_BASE = "";
  const WIKI_PARSE_ENDPOINT = "/api/wiki/parse";
  const WIKI_ADMIN_TRIGGER = "进入管理员页";
  const TARGET_CONFIG = {
    prd: { label: "需求文档" },
    tech: { label: "设计文档" },
  };

  const inputs = {
    prd: document.getElementById("prd"),
    tech: document.getElementById("tech"),
  };
  const docUploadInput = document.getElementById("docUploadInput");
  const toolButtons = Array.from(document.querySelectorAll(".field-tool-btn"));
  const errorBox = document.getElementById("errorBox");
  const errorText = document.getElementById("errorText");

  const historyModal = {
    root: document.getElementById("docHistoryModal"),
    backdrop: document.getElementById("docHistoryModalBackdrop"),
    close: document.getElementById("docHistoryModalClose"),
    title: document.getElementById("docHistoryModalTitle"),
    hint: document.getElementById("docHistoryModalHint"),
    loading: document.getElementById("docHistoryLoading"),
    empty: document.getElementById("docHistoryEmpty"),
    list: document.getElementById("docHistoryList"),
  };

  const wikiModal = {
    root: document.getElementById("wikiImportModal"),
    backdrop: document.getElementById("wikiImportModalBackdrop"),
    close: document.getElementById("wikiImportModalClose"),
    title: document.getElementById("wikiImportModalTitle"),
    input: document.getElementById("wikiImportUrl"),
    status: document.getElementById("wikiImportStatus"),
    cancel: document.getElementById("wikiImportCancelBtn"),
    submit: document.getElementById("wikiImportSubmitBtn"),
  };

  if (!inputs.prd || !inputs.tech || !docUploadInput) return;

  const actionState = {
    prd: { busyAction: "" },
    tech: { busyAction: "" },
  };

  let activeUploadTarget = "";
  let activeWikiTarget = "";
  let historyRequestSeq = 0;
  let docHistoryCache = null;
  const docTextCache = new Map();

  function getTargetLabel(target) {
    return TARGET_CONFIG[target]?.label || "当前输入框";
  }

  function normalizeText(text) {
    return String(text || "").replace(/\r\n/g, "\n");
  }

  function truncateText(text, maxLength = 260) {
    const normalized = normalizeText(text).trim();
    if (!normalized) return "文档内容为空";
    return normalized.length <= maxLength ? normalized : `${normalized.slice(0, maxLength)}…`;
  }

  function formatTime(iso) {
    try {
      return new Date(iso).toLocaleString("zh-CN");
    } catch {
      return iso || "-";
    }
  }

  function normalizeIdentityText(value) {
    return String(value || "").trim().toLowerCase();
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = String(text || "");
    return div.innerHTML;
  }

  function inferTargetFromName(filename) {
    const lower = String(filename || "").toLowerCase();
    if (lower.includes("__tech_") || lower.includes("tech")) return "tech";
    if (lower.includes("__prd_") || lower.includes("prd")) return "prd";
    return "";
  }

  function showGlobalError(message) {
    if (!errorBox || !errorText) return;
    errorBox.hidden = false;
    errorText.textContent = message;
  }

  function hideGlobalError() {
    if (!errorBox || !errorText) return;
    errorBox.hidden = true;
    errorText.textContent = "";
  }

  function setFieldValue(target, text) {
    const input = inputs[target];
    if (!input) return;
    input.value = normalizeText(text);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.focus();
    const len = input.value.length;
    input.setSelectionRange(len, len);
  }

  function getButtonsByTarget(target) {
    return toolButtons.filter((button) => button.dataset.fieldTarget === target);
  }

  function setTargetBusy(target, action, loading) {
    const state = actionState[target];
    if (!state) return;
    state.busyAction = loading ? action : "";
    const loadingLabel = action === "history" ? "加载中..." : "解析中...";
    getButtonsByTarget(target).forEach((button) => {
      const labelEl = button.querySelector("span:last-child");
      const defaultLabel = button.dataset.defaultLabel || "";
      const isCurrentAction = loading && button.dataset.fieldAction === action;
      button.disabled = loading;
      button.classList.toggle("is-busy", isCurrentAction);
      if (labelEl) {
        labelEl.textContent = isCurrentAction ? loadingLabel : defaultLabel;
      }
    });
  }

  async function fetchDocHistory(forceRefresh = false) {
    if (docHistoryCache && !forceRefresh) return docHistoryCache;
    const response = await fetch(`${DOC_PARSER_API_BASE}/api/history`);
    const data = await response.json();
    if (!response.ok || !data?.success || !Array.isArray(data.data)) {
      throw new Error(data?.error || "历史文档加载失败");
    }
    docHistoryCache = data.data;
    return docHistoryCache;
  }

  async function fetchDocText(path) {
    if (!path) return "";
    if (docTextCache.has(path)) {
      return docTextCache.get(path);
    }
    const pending = (async () => {
      const response = await fetch(
        `${DOC_PARSER_API_BASE}/api/file-text?path=${encodeURIComponent(path)}`
      );
      const data = await response.json();
      if (!response.ok || !data?.success) {
        throw new Error(data?.error || "读取解析文本失败");
      }
      return normalizeText(data.data?.text || "");
    })();
    docTextCache.set(path, pending);
    try {
      return await pending;
    } catch (error) {
      docTextCache.delete(path);
      throw error;
    }
  }

  function flattenHistoryEntries(records) {
    if (!Array.isArray(records)) return [];
    return records.flatMap((record) => {
      const results = Array.isArray(record?.results) ? record.results : [];
      return results
        .filter((item) => !item?.error && (item?.ocr_markdown || item?.markdown))
        .map((item, index) => ({
          id: `${record.id || "record"}:${index}`,
          createdAt: record?.createdAt || "",
          filename: item?.filename || record?.title || `解析文档 ${index + 1}`,
          path: item?.ocr_markdown || item?.markdown || "",
          target:
            (item?.target || record?.target || inferTargetFromName(item?.filename)).toLowerCase(),
          sourceType: String(item?.sourceType || record?.sourceType || "upload").toLowerCase(),
          sourceUrl: item?.sourceUrl || record?.sourceUrl || "",
        }));
    });
  }

  function buildHistoryEntryDedupKey(entry) {
    const sourceType = normalizeIdentityText(entry?.sourceType || "upload");
    const sourceUrl = normalizeIdentityText(entry?.sourceUrl);
    const filename = normalizeIdentityText(entry?.filename);
    const path = normalizeIdentityText(entry?.path);
    if (sourceType === "wiki" && sourceUrl) {
      return `wiki:${sourceUrl}`;
    }
    if (filename) {
      return `${sourceType}:${filename}`;
    }
    return `${sourceType}:${path}`;
  }

  function dedupeHistoryEntries(entries) {
    const seen = new Set();
    return entries.filter((entry) => {
      const key = buildHistoryEntryDedupKey(entry);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function pickEntriesForTarget(entries, target) {
    const exactMatches = [];
    const unknownMatches = [];
    entries.forEach((entry) => {
      if (entry.target === target) {
        exactMatches.push(entry);
      } else if (!entry.target) {
        unknownMatches.push(entry);
      }
    });
    return dedupeHistoryEntries([...exactMatches, ...unknownMatches]).slice(0, 30);
  }

  function closeHistoryModal() {
    historyModal.root.hidden = true;
    historyModal.list.innerHTML = "";
    historyModal.empty.hidden = true;
    historyModal.empty.textContent = "暂无可引用的历史文档";
    historyModal.loading.hidden = true;
  }

  function renderHistoryEntries(entries, target) {
    historyModal.list.innerHTML = "";
    historyModal.empty.hidden = true;
    if (!entries.length) {
      historyModal.empty.hidden = false;
      historyModal.empty.textContent = `暂无可直接填入${getTargetLabel(target)}的历史文档`;
      return;
    }

    entries.forEach((entry, index) => {
      const article = document.createElement("article");
      article.className = "assist-doc-item";
      const badgeClass = entry.target === target ? "" : " is-muted";
      const badgeText = entry.target === target ? "已标记到当前输入框" : "未标注文档";
      const sourceText = entry.sourceType === "wiki" ? "Wiki 页面" : "上传文档";
      article.innerHTML = `
        <div class="assist-doc-title-row">
          <h4 class="assist-doc-title">${escapeHtml(entry.filename)}</h4>
          <span class="assist-doc-badge${badgeClass}">${escapeHtml(badgeText)}</span>
        </div>
        <div class="assist-doc-meta">
          <span>${escapeHtml(formatTime(entry.createdAt))}</span>
          <span class="assist-doc-badge is-muted">${escapeHtml(sourceText)}</span>
        </div>
        <p class="assist-doc-preview is-loading" data-preview-index="${index}">正在加载内容预览...</p>
        <div class="assist-doc-actions">
          <button type="button" class="btn btn-outline" data-apply-index="${index}">
            引用到${escapeHtml(getTargetLabel(target))}
          </button>
        </div>
      `;
      historyModal.list.appendChild(article);
    });

    historyModal.list.querySelectorAll("[data-apply-index]").forEach((button) => {
      button.addEventListener("click", async () => {
        const index = Number(button.getAttribute("data-apply-index"));
        const entry = entries[index];
        if (!entry) return;
        button.disabled = true;
        const originalText = button.textContent;
        button.textContent = "引用中...";
        try {
          const text = await fetchDocText(entry.path);
          if (!text.trim()) {
            throw new Error("解析文本为空");
          }
          setFieldValue(target, text);
          hideGlobalError();
          closeHistoryModal();
        } catch (error) {
          showGlobalError(`引用历史文档失败：${error?.message || "网络错误"}`);
          button.disabled = false;
          button.textContent = originalText;
        }
      });
    });
  }

  async function hydrateHistoryPreviews(entries, seq) {
    const previewTasks = entries.slice(0, 12).map(async (entry, index) => {
      const previewEl = historyModal.list.querySelector(`[data-preview-index="${index}"]`);
      if (!previewEl) return;
      try {
        const text = await fetchDocText(entry.path);
        if (seq !== historyRequestSeq || historyModal.root.hidden) return;
        previewEl.textContent = truncateText(text);
        previewEl.classList.remove("is-loading");
      } catch {
        if (seq !== historyRequestSeq || historyModal.root.hidden) return;
        previewEl.textContent = "内容预览加载失败，可直接点击引用。";
        previewEl.classList.remove("is-loading");
      }
    });
    await Promise.allSettled(previewTasks);
  }

  async function openHistoryModal(target) {
    if (!historyModal.root) return;
    historyRequestSeq += 1;
    const seq = historyRequestSeq;
    historyModal.title.textContent = `${getTargetLabel(target)} · 历史文档引用`;
    historyModal.hint.textContent = "仅展示当前输入框对应的历史解析结果，选择后将直接填入。";
    historyModal.root.hidden = false;
    historyModal.loading.hidden = false;
    historyModal.empty.hidden = true;
    historyModal.list.innerHTML = "";
    setTargetBusy(target, "history", true);
    try {
      const records = await fetchDocHistory(false);
      if (seq !== historyRequestSeq || historyModal.root.hidden) return;
      const entries = pickEntriesForTarget(flattenHistoryEntries(records), target);
      renderHistoryEntries(entries, target);
      historyModal.loading.hidden = true;
      await hydrateHistoryPreviews(entries, seq);
    } catch (error) {
      if (seq !== historyRequestSeq || historyModal.root.hidden) return;
      historyModal.loading.hidden = true;
      historyModal.empty.hidden = false;
      historyModal.empty.textContent = `历史文档加载失败：${error?.message || "网络错误"}`;
    } finally {
      setTargetBusy(target, "history", false);
    }
  }

  function openWikiModal(target) {
    if (!wikiModal.root) return;
    activeWikiTarget = target;
    wikiModal.title.textContent = `${getTargetLabel(target)} · Wiki地址解析`;
    wikiModal.input.value = "";
    wikiModal.status.hidden = true;
    wikiModal.status.classList.remove("is-info", "is-error");
    wikiModal.status.textContent = "";
    wikiModal.submit.disabled = false;
    wikiModal.submit.textContent = "开始解析";
    wikiModal.cancel.disabled = false;
    wikiModal.root.hidden = false;
    requestAnimationFrame(() => wikiModal.input.focus());
  }

  function closeWikiModal() {
    wikiModal.root.hidden = true;
    wikiModal.status.hidden = true;
    wikiModal.status.classList.remove("is-info", "is-error");
    wikiModal.status.textContent = "";
    wikiModal.input.value = "";
    wikiModal.submit.disabled = false;
    wikiModal.submit.textContent = "开始解析";
    wikiModal.cancel.disabled = false;
    activeWikiTarget = "";
  }

  function setWikiStatus(message, type) {
    wikiModal.status.hidden = !message;
    wikiModal.status.classList.remove("is-info", "is-error");
    if (message) {
      wikiModal.status.classList.add(type === "error" ? "is-error" : "is-info");
      wikiModal.status.textContent = message;
    } else {
      wikiModal.status.textContent = "";
    }
  }

  function isWikiAdminTrigger(value) {
    return String(value || "").replace(/\s+/g, "") === WIKI_ADMIN_TRIGGER;
  }

  function getWikiStageText(job) {
    const stage = String(job?.stage || "").toLowerCase();
    if (job?.stageMessage) return String(job.stageMessage);
    if (stage === "fetch" || stage === "fetching") return "正在抓取页面...";
    if (stage === "convert" || stage === "converting") return "正在解析正文结构...";
    if (stage === "images") return "正在下载页面图片...";
    if (stage === "ocr") return "正在识别图片内容...";
    if (stage === "finalizing") return "正在整理 Markdown 结果...";
    if (stage === "done") return "解析完成，正在读取结果...";
    if (stage === "error") return "Wiki 解析失败";
    return "正在处理 Wiki 内容...";
  }

  async function pollWikiJob(jobId) {
    for (let attempt = 0; attempt < 180; attempt += 1) {
      const response = await fetch(`/api/wiki/jobs/${encodeURIComponent(jobId)}`);
      const data = await response.json();
      if (!response.ok || !data?.success) {
        throw new Error(data?.error || "Wiki 任务状态查询失败");
      }
      const job = data.data || {};
      setWikiStatus(getWikiStageText(job), "info");
      if (job.status !== "running") {
        return job;
      }
      await sleep(1500);
    }
    throw new Error("Wiki 解析超时，请稍后从历史文档中引用结果");
  }

  async function submitWikiImport() {
    const target = activeWikiTarget;
    if (!target) return;
    const wikiUrl = wikiModal.input.value.trim();
    if (!wikiUrl) {
      setWikiStatus("请输入 Wiki 地址", "error");
      return;
    }
    if (isWikiAdminTrigger(wikiUrl)) {
      closeWikiModal();
      window.location.href = "/wiki-auth-admin";
      return;
    }
    setTargetBusy(target, "wiki", true);
    wikiModal.submit.disabled = true;
    wikiModal.cancel.disabled = true;
    wikiModal.submit.textContent = "解析中...";
    setWikiStatus("正在提交 Wiki 解析任务...", "info");
    try {
      const response = await fetch(WIKI_PARSE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: wikiUrl, target }),
      });
      const data = await response.json();
      if (!response.ok || !data?.success) {
        throw new Error(data?.error || "Wiki 解析失败");
      }
      const jobId = data.data?.jobId;
      if (!jobId) {
        throw new Error("未获取到 Wiki 解析任务");
      }
      const job = await pollWikiJob(jobId);
      const result = pickSuccessfulResult(job);
      if (!result) {
        throw new Error(job?.error || "Wiki 解析失败");
      }
      setWikiStatus("解析完成，正在读取 Markdown 内容...", "info");
      const text = await fetchDocText(result.ocr_markdown || result.markdown);
      if (!text.trim()) {
        throw new Error("Wiki 页面没有可填充的正文内容");
      }
      docHistoryCache = null;
      setFieldValue(target, text);
      hideGlobalError();
      closeWikiModal();
    } catch (error) {
      const message = error?.message || "Wiki 解析失败";
      if (!wikiModal.root.hidden) {
        setWikiStatus(message, "error");
      } else {
        showGlobalError(`Wiki 地址解析失败：${message}`);
      }
    } finally {
      setTargetBusy(target, "wiki", false);
      if (!wikiModal.root.hidden) {
        wikiModal.submit.disabled = false;
        wikiModal.cancel.disabled = false;
        wikiModal.submit.textContent = "开始解析";
      }
    }
  }

  async function pollDocJob(jobId) {
    for (let attempt = 0; attempt < 120; attempt += 1) {
      const response = await fetch(`${DOC_PARSER_API_BASE}/api/jobs/${encodeURIComponent(jobId)}`);
      const data = await response.json();
      if (!response.ok || !data?.success) {
        throw new Error(data?.error || "文档解析任务查询失败");
      }
      const job = data.data || {};
      if (job.status !== "running") {
        return job;
      }
      await sleep(1500);
    }
    throw new Error("文档解析超时，请稍后从历史文档中引用结果");
  }

  function pickSuccessfulResult(job) {
    const results = Array.isArray(job?.results) ? job.results : [];
    return results.find((item) => !item?.error && (item?.ocr_markdown || item?.markdown));
  }

  function isSupportedUploadFile(file) {
    return /\.(docx|pdf)$/i.test(file?.name || "");
  }

  async function pickUploadFileWithNativeDialog() {
    if (typeof window.showOpenFilePicker !== "function" || !window.isSecureContext) {
      return { supported: false, file: null };
    }
    try {
      const handles = await window.showOpenFilePicker({
        id: "doc-upload-picker",
        multiple: false,
        startIn: "documents",
        types: [
          {
            description: "文档文件",
            accept: {
              "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
              "application/pdf": [".pdf"],
            },
          },
        ],
      });
      const handle = Array.isArray(handles) ? handles[0] : null;
      if (!handle) {
        return { supported: true, file: null };
      }
      return { supported: true, file: await handle.getFile() };
    } catch (error) {
      if (error?.name === "AbortError") {
        return { supported: true, file: null };
      }
      return { supported: false, file: null };
    }
  }

  async function startUploadSelection(target) {
    const picked = await pickUploadFileWithNativeDialog();
    if (picked.supported) {
      if (!picked.file) return;
      if (!isSupportedUploadFile(picked.file)) {
        showGlobalError("仅支持上传 .docx / .pdf 文件");
        return;
      }
      await uploadDocumentToTarget(target, picked.file);
      return;
    }
    activeUploadTarget = target;
    docUploadInput.value = "";
    docUploadInput.click();
  }

  async function uploadDocumentToTarget(target, file) {
    setTargetBusy(target, "upload", true);
    hideGlobalError();
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("target", target);
      const response = await fetch(`${DOC_PARSER_API_BASE}/api/parse`, {
        method: "POST",
        body: formData,
      });
      const data = await response.json();
      if (!response.ok || !data?.success) {
        throw new Error(data?.error || "文档提交失败");
      }
      const jobId = data.data?.jobId;
      if (!jobId) {
        throw new Error("未获取到文档解析任务");
      }
      const job = await pollDocJob(jobId);
      const result = pickSuccessfulResult(job);
      if (!result) {
        throw new Error(job?.error || "文档解析失败");
      }
      const text = await fetchDocText(result.ocr_markdown || result.markdown);
      if (!text.trim()) {
        throw new Error("文档解析结果为空");
      }
      docHistoryCache = null;
      setFieldValue(target, text);
    } catch (error) {
      showGlobalError(`文档解析失败：${error?.message || "网络错误"}`);
    } finally {
      setTargetBusy(target, "upload", false);
    }
  }

  toolButtons.forEach((button) => {
    const labelEl = button.querySelector("span:last-child");
    button.dataset.defaultLabel = labelEl?.textContent?.trim() || "";
    button.addEventListener("click", async () => {
      const target = button.dataset.fieldTarget;
      const action = button.dataset.fieldAction;
      if (!target || !action || actionState[target]?.busyAction) return;
      if (action === "upload") {
        await startUploadSelection(target);
        return;
      }
      if (action === "history") {
        openHistoryModal(target);
        return;
      }
      if (action === "wiki") {
        openWikiModal(target);
      }
    });
  });

  docUploadInput.addEventListener("change", async () => {
    const target = activeUploadTarget;
    const file = docUploadInput.files?.[0];
    docUploadInput.value = "";
    activeUploadTarget = "";
    if (!target || !file) return;
    if (!isSupportedUploadFile(file)) {
      showGlobalError("仅支持上传 .docx / .pdf 文件");
      return;
    }
    await uploadDocumentToTarget(target, file);
  });

  historyModal.backdrop?.addEventListener("click", closeHistoryModal);
  historyModal.close?.addEventListener("click", closeHistoryModal);
  wikiModal.backdrop?.addEventListener("click", closeWikiModal);
  wikiModal.close?.addEventListener("click", closeWikiModal);
  wikiModal.cancel?.addEventListener("click", closeWikiModal);
  wikiModal.submit?.addEventListener("click", submitWikiImport);
  wikiModal.input?.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      submitWikiImport();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (historyModal.root && !historyModal.root.hidden) {
      closeHistoryModal();
    }
    if (wikiModal.root && !wikiModal.root.hidden) {
      closeWikiModal();
    }
  });
})();
