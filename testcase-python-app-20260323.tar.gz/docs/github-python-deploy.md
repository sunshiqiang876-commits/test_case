# 通过 GitHub Actions 部署 Python 服务（GHCR）

推送至默认分支 **`main` 或 `master`** 且变更涉及 `python_server/`、`public/`、`prompts/` 时，会自动构建 Docker 镜像并推送到 **GitHub Container Registry（GHCR）**。

也可在 Actions 里手动运行：**Python server — Docker & GHCR** → **Run workflow**。

## 1. 仓库设置

1. 代码推到 GitHub 后，确认 Actions 已启用（Settings → Actions → General）。
2. 首次推送镜像后，在 GitHub 打开 **Packages**，找到 `python-server` 包；若需公开拉取，将 Package 设为 public，或拉取机使用有权限的 **PAT**（`read:packages`）。

## 2. 镜像地址

格式：

```text
ghcr.io/<owner>/<repo>/python-server:latest
ghcr.io/<owner>/<repo>/python-server:<git-sha>
```

`<owner>/<repo>` 与仓库路径一致且**全小写**。

登录 GHCR（私有包）：

```bash
echo <GITHUB_TOKEN> | docker login ghcr.io -u <GITHUB_USERNAME> --password-stdin
```

## 3. 运行容器（示例）

镜像内已设置 `PROJECT_ROOT=/app`，并包含 `public/`、`prompts/`。

```bash
docker pull ghcr.io/<owner>/<repo>/python-server:latest

docker run -d --name testcase-python -p 8000:8000 \
  -e DATABASE_URL="postgresql://..." \
  -e DOC_PARSER_API_BASE="http://解析服务:5000" \
  -e BELLA_API_KEY="..." \
  -e WIKI_ADMIN_SECRET="..." \
  -e PYTHON_DATA_DIR=/data/py \
  -v py-data:/data/py \
  ghcr.io/<owner>/<repo>/python-server:latest
```

- **端口**：容器内默认 `8000`，映射按需修改（如 `-p 8000:8000`）。
- **数据库**：若使用 Postgres，先在库上执行迁移（见下文），再设置 `DATABASE_URL`。
- **数据目录**：`PYTHON_DATA_DIR` 建议挂卷，避免容器删除丢数据。

健康检查：

```bash
curl -s http://127.0.0.1:8000/api/health
```

## 4. 数据库迁移（使用 Postgres 时）

在**可访问数据库**的环境执行（非必须在容器内）：

```bash
export DATABASE_URL="postgresql://USER:PASS@HOST:5432/DBNAME"
cd python_server   # 使用仓库内同版本代码
pip install -r requirements.txt
python3 -m db.migrate
```

或在一次性任务容器中挂载仓库 `python_server` 目录执行上述命令。

## 5. 与 Node 虚拟机包的关系

- **Node**：仍使用 `dist/node-vm` 下前后端压缩包部署（见该目录 `README.md`）。
- **Python**：由本流程产出 **Docker 镜像**；可与 Node 同机不同端口，或分机器部署，通过 `DOC_PARSER_API_BASE` 等环境变量互连。

## 6. 工作流文件位置

- `.github/workflows/python-server.yml`
- `python_server/Dockerfile`（构建上下文为**仓库根目录**）

本地构建自检：

```bash
docker build -f python_server/Dockerfile -t testcase-python:local .
docker run --rm -p 8000:8000 testcase-python:local
```
