# Cloud deployment (staging / production)

This app is a **Python FastAPI** service plus a separate **Flask document parser** under `文档解析/`. Data can live in **Postgres** (recommended) or local JSON files when `DATABASE_URL` is unset.

## 1. Postgres

1. Create a database (Supabase, Neon, RDS, etc.).
2. Apply migrations from the `python_server` directory:

```bash
export DATABASE_URL="postgresql://USER:PASS@HOST:5432/DBNAME"
cd python_server
python3 -m db.migrate
```

3. Optional: backfill existing JSON files:

```bash
export PYTHON_DATA_DIR="/absolute/path/to/data_or_data_py_shadow"
python3 scripts/backfill_json_to_postgres.py
```

## 2. Environment variables (main Python service)

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` | Enables Postgres-backed storage. |
| `DATABASE_DUAL_WRITE_JSON` | Default `true` when DB is on: also write legacy JSON under `PYTHON_DATA_DIR` for rollback. Set `false` after cutover. |
| `PYTHON_DATA_DIR` | Data directory (default `data_py_shadow` for staging). |
| `PYTHON_PORT` | Listen port (default `8000`). |
| `PROJECT_ROOT` | Repo root (contains `public/`, `prompts/`). |
| `DOC_PARSER_API_BASE` | URL of the document parser service (e.g. `http://localhost:5000`). |

## 3. Run the main service

```bash
cd python_server
python3 -m app.main
```

Or with uvicorn:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## 4. Document parser service

Deploy `文档解析/web_app.py` as a separate process (gunicorn recommended). Set `DATABASE_URL` there as well if you enabled DB-backed parse history (see `文档解析/parser_persistence.py`).

Set `DOC_PARSER_API_BASE` on the main app to this service’s public URL.

### Optional object storage for parser artifacts

The parser now supports S3-compatible storage for generated artifacts (`.md`, `_ocr.md`, `_ocr.json`, image folders):

| Variable | Purpose |
|----------|---------|
| `PARSER_STORAGE_BACKEND` | `local` or `s3`. If omitted, auto-detects `s3` when bucket is configured. |
| `PARSER_S3_BUCKET` / `S3_BUCKET` | Bucket name. |
| `PARSER_S3_ENDPOINT_URL` | Endpoint URL for MinIO / R2 / other S3-compatible services. |
| `PARSER_S3_REGION` | Region name. |
| `PARSER_S3_KEY_PREFIX` | Object key prefix. Default `parser-artifacts`. |
| `PARSER_S3_ACCESS_KEY_ID` / `AWS_ACCESS_KEY_ID` | Access key. |
| `PARSER_S3_SECRET_ACCESS_KEY` / `AWS_SECRET_ACCESS_KEY` | Secret key. |
| `PARSER_S3_SESSION_TOKEN` / `AWS_SESSION_TOKEN` | Optional session token. |

With S3 enabled, parser outputs are uploaded using the same logical paths returned by the API, so `/api/file-text?path=...` and `/files/<path>` continue to work without frontend changes.

## 5. GitHub → CI/CD

### 5.1 本仓库内置：Actions → GHCR（推荐）

推送 `main` / `master` 后自动构建并推送镜像，详见 **[docs/github-python-deploy.md](./github-python-deploy.md)**。

- 工作流：`.github/workflows/python-server.yml`
- 镜像：`ghcr.io/<owner>/<repo>/python-server:latest`

### 5.2 其他 PaaS

也可把同一套代码接到 **Render**、**Railway**、**Fly.io** 等：

- Build command: `pip install -r python_server/requirements.txt`
- Start command: `cd python_server && python3 -m app.main`（或上文 uvicorn）
- 在平台控制台配置 `DATABASE_URL` 等环境变量；若使用上文 Docker 镜像，则 Start 改为容器默认命令即可。

## 6. Cutover checklist

- [ ] Migrations applied on production DB.
- [ ] Backfill run (or accept empty history).
- [ ] Smoke test: `/api/health`, `/api/testcase/list`, upload parse, one testcase generation.
- [ ] Set `DATABASE_DUAL_WRITE_JSON=false` when JSON files are no longer needed.
- [ ] Keep a backup of `data/` JSON before deleting dual-write.

## 7. Object storage notes

Parser jobs still use local temporary files while running OCR / conversion, but retrieval no longer needs local disk when S3 storage is configured. Historical artifacts can be uploaded during backfill because `scripts/backfill_json_to_postgres.py` also registers parser files into `parse_artifacts`.
