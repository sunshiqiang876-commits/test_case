# Database migrations

1. Create a Postgres database (Supabase, Neon, RDS, local Postgres).
2. Set `DATABASE_URL` to a connection string, e.g. `postgresql://user:pass@host:5432/dbname`.
3. From the `python_server` directory:

```bash
export DATABASE_URL="postgresql://..."
python3 -m db.migrate
```

This applies `db/migrations/*.sql` in lexical order and records applied files in `schema_migrations`.

## Backfill from JSON

After migrations, you can import:

- `results.json`
- `input-pairs.json`
- `prompt-config.json`
- `wiki-auth.json`
- `文档解析/data/parse_history.json`
- parser artifact files referenced by the parse history

from the current project data directories:

```bash
export PYTHON_DATA_DIR="/path/to/data_or_data_py_shadow"
python3 scripts/backfill_json_to_postgres.py
```

If the parser is configured with S3-compatible storage (`PARSER_STORAGE_BACKEND=s3` and related bucket credentials), the backfill script also uploads referenced parser artifacts and registers them in `parse_artifacts`.

## Environment variables (app runtime)

| Variable | Meaning |
|----------|---------|
| `DATABASE_URL` | If set, enables database-backed storage (when implemented per route). |
| `DATABASE_DUAL_WRITE_JSON` | If `1`/`true`, also write legacy JSON files under `PYTHON_DATA_DIR` when using DB. Default: `1` when `DATABASE_URL` is set. |
