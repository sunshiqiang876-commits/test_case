-- Cloud storage migration: initial Postgres schema (Postgres 14+)
-- Compatible with Supabase, Neon, RDS Postgres.

-- Shared workspace placeholder for future multi-tenant isolation
CREATE TABLE IF NOT EXISTS workspaces (
    id UUID PRIMARY KEY,
    name TEXT NOT NULL DEFAULT 'default',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO workspaces (id, name)
VALUES ('00000000-0000-0000-0000-000000000001', 'default')
ON CONFLICT (id) DO NOTHING;

-- Testcase generation results (replaces data/results.json)
CREATE TABLE IF NOT EXISTS testcase_results (
    id TEXT PRIMARY KEY,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE DEFAULT '00000000-0000-0000-0000-000000000001',
    prd TEXT NOT NULL DEFAULT '',
    tech TEXT NOT NULL DEFAULT '',
    client_request_id TEXT NOT NULL DEFAULT '',
    workflow_run_id TEXT,
    leaf_node_count INT,
    status TEXT NOT NULL DEFAULT '',
    warnings JSONB NOT NULL DEFAULT '[]'::jsonb,
    stage_summary JSONB,
    outputs JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_testcase_results_created_at ON testcase_results (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_testcase_results_client_request_id ON testcase_results (client_request_id);
CREATE INDEX IF NOT EXISTS idx_testcase_results_workspace_created ON testcase_results (workspace_id, created_at DESC);

-- Input pairs (replaces data/input-pairs.json)
CREATE TABLE IF NOT EXISTS input_pairs (
    pair_id TEXT PRIMARY KEY,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE DEFAULT '00000000-0000-0000-0000-000000000001',
    prd TEXT NOT NULL,
    tech TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    used_count INT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (workspace_id, fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_input_pairs_created_at ON input_pairs (created_at DESC);

-- Single-row prompt overrides (replaces data/prompt-config.json)
CREATE TABLE IF NOT EXISTS prompt_config_row (
    id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE DEFAULT '00000000-0000-0000-0000-000000000001',
    templates JSONB NOT NULL DEFAULT '{}'::jsonb,
    knowledge_base TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMPTZ,
    updated_by TEXT NOT NULL DEFAULT ''
);

-- Single-row wiki credentials (replaces data/wiki-auth.json)
CREATE TABLE IF NOT EXISTS wiki_auth_row (
    id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE DEFAULT '00000000-0000-0000-0000-000000000001',
    cookie TEXT NOT NULL DEFAULT '',
    auth_token TEXT NOT NULL DEFAULT '',
    updated_at TIMESTAMPTZ,
    updated_by TEXT NOT NULL DEFAULT ''
);

-- Running / completed testcase jobs (replaces in-memory testcase_jobs)
CREATE TABLE IF NOT EXISTS testcase_jobs (
    job_id UUID PRIMARY KEY,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE DEFAULT '00000000-0000-0000-0000-000000000001',
    client_request_id TEXT NOT NULL,
    prd TEXT NOT NULL DEFAULT '',
    tech TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'running',
    current_stage TEXT NOT NULL DEFAULT '',
    current_stage_label TEXT NOT NULL DEFAULT '',
    error TEXT NOT NULL DEFAULT '',
    warnings JSONB NOT NULL DEFAULT '[]'::jsonb,
    result_json JSONB,
    job_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_testcase_jobs_client_request ON testcase_jobs (client_request_id);
CREATE INDEX IF NOT EXISTS idx_testcase_jobs_status ON testcase_jobs (status);
CREATE INDEX IF NOT EXISTS idx_testcase_jobs_created ON testcase_jobs (created_at DESC);

CREATE TABLE IF NOT EXISTS testcase_job_stages (
    id BIGSERIAL PRIMARY KEY,
    job_id UUID NOT NULL REFERENCES testcase_jobs(job_id) ON DELETE CASCADE,
    stage_key TEXT NOT NULL,
    label TEXT NOT NULL DEFAULT '',
    short_label TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    visible BOOLEAN NOT NULL DEFAULT TRUE,
    message TEXT NOT NULL DEFAULT '',
    attempt_count INT NOT NULL DEFAULT 0,
    retry_count INT NOT NULL DEFAULT 0,
    workflow_run_id TEXT,
    error TEXT NOT NULL DEFAULT '',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (job_id, stage_key)
);

CREATE INDEX IF NOT EXISTS idx_testcase_job_stages_job ON testcase_job_stages (job_id);

-- Document parse jobs (replaces 文档解析 JOBS dict + parse_history entries)
CREATE TABLE IF NOT EXISTS parse_jobs (
    job_id TEXT PRIMARY KEY,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE DEFAULT '00000000-0000-0000-0000-000000000001',
    status TEXT NOT NULL DEFAULT 'pending',
    stage TEXT NOT NULL DEFAULT '',
    stage_message TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL DEFAULT '',
    error TEXT NOT NULL DEFAULT '',
    source_type TEXT NOT NULL DEFAULT '',
    source_url TEXT NOT NULL DEFAULT '',
    target TEXT NOT NULL DEFAULT '',
    payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_parse_jobs_created ON parse_jobs (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_parse_jobs_status ON parse_jobs (status);

-- Artifacts produced by parser (local path or object storage URI)
CREATE TABLE IF NOT EXISTS parse_artifacts (
    id BIGSERIAL PRIMARY KEY,
    parse_job_id TEXT NOT NULL REFERENCES parse_jobs(job_id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    storage_uri TEXT NOT NULL,
    filename TEXT NOT NULL DEFAULT '',
    mime_type TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_parse_artifacts_job ON parse_artifacts (parse_job_id);
