-- Optional: mirror parse_history.json for doc-parser service when using Postgres
CREATE TABLE IF NOT EXISTS parse_history_snapshot (
    id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    entries JSONB NOT NULL DEFAULT '[]'::jsonb
);
