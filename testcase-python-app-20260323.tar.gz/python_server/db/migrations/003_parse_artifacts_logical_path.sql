ALTER TABLE parse_artifacts
ADD COLUMN IF NOT EXISTS logical_path TEXT;

UPDATE parse_artifacts
SET logical_path = COALESCE(logical_path, filename, '')
WHERE logical_path IS NULL;

ALTER TABLE parse_artifacts
ALTER COLUMN logical_path SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_parse_artifacts_job_kind_path
ON parse_artifacts (parse_job_id, kind, logical_path);
