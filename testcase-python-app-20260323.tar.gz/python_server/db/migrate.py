#!/usr/bin/env python3
"""Apply SQL migrations in order. Usage:

  DATABASE_URL=postgresql://... python3 -m db.migrate

Run from python_server directory.
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

import asyncpg


async def _apply() -> None:
    dsn = (os.environ.get("DATABASE_URL") or "").strip()
    if not dsn:
        print("DATABASE_URL is required", file=sys.stderr)
        sys.exit(1)

    migrations_dir = Path(__file__).resolve().parent / "migrations"
    files = sorted(migrations_dir.glob("*.sql"))
    if not files:
        print("No migrations found", file=sys.stderr)
        sys.exit(1)

    conn = await asyncpg.connect(dsn)
    try:
        await conn.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations (
                id TEXT PRIMARY KEY,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
            """
        )
        for path in files:
            mid = path.name
            row = await conn.fetchrow("SELECT 1 FROM schema_migrations WHERE id = $1", mid)
            if row:
                print(f"skip {mid}")
                continue
            sql = path.read_text(encoding="utf-8")
            print(f"apply {mid} ...")
            await conn.execute(sql)
            await conn.execute("INSERT INTO schema_migrations (id) VALUES ($1)", mid)
            print(f"ok {mid}")
        print("migrations complete")
    finally:
        await conn.close()


def main() -> None:
    asyncio.run(_apply())


if __name__ == "__main__":
    main()
