#!/usr/bin/env python3
"""
One-shot: import legacy JSON files and parser history into Postgres.

Usage (from python_server directory):

  export DATABASE_URL="postgresql://..."
  export PYTHON_DATA_DIR="/path/to/data_or_data_py_shadow"
  python3 scripts/backfill_json_to_postgres.py

Imports:
- `PYTHON_DATA_DIR/results.json`
- `PYTHON_DATA_DIR/input-pairs.json`
- `PYTHON_DATA_DIR/wiki-auth.json`
- `PYTHON_DATA_DIR/prompt-config.json`
- `PROJECT_ROOT/文档解析/data/parse_history.json`

When parser S3 storage is configured, referenced parser artifacts are uploaded and
registered into `parse_artifacts`.

Requires: pip install asyncpg
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import datetime
from pathlib import Path

# Allow running as script
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


async def _main() -> None:
    dsn = (os.environ.get("DATABASE_URL") or "").strip()
    if not dsn:
        print("DATABASE_URL is required", file=sys.stderr)
        sys.exit(1)

    import asyncpg

    from app import settings

    results_path = settings.RESULTS_FILE
    pairs_path = settings.INPUT_PAIRS_FILE
    wiki_path = settings.WIKI_AUTH_FILE
    prompt_path = settings.PROMPT_CONFIG_FILE
    parser_root = settings.PROJECT_ROOT / "文档解析"
    parser_history_path = parser_root / "data" / "parse_history.json"
    if str(parser_root) not in sys.path:
        sys.path.insert(0, str(parser_root))

    conn = await asyncpg.connect(dsn)
    try:
        def _parse_ts(value):
            if not value:
                return None
            if isinstance(value, datetime):
                return value
            s = str(value).strip()
            if not s:
                return None
            try:
                return datetime.fromisoformat(s.replace("Z", "+00:00"))
            except Exception:
                return None

        # results.json
        if results_path.exists():
            raw = json.loads(results_path.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                for rec in raw:
                    if not isinstance(rec, dict):
                        continue
                    rid = str(rec.get("id") or "")
                    if not rid:
                        continue
                    await conn.execute(
                        """
                        INSERT INTO testcase_results (
                            id, workspace_id, prd, tech, client_request_id, workflow_run_id, leaf_node_count,
                            status, warnings, stage_summary, outputs, created_at
                        )
                        VALUES (
                            $1, '00000000-0000-0000-0000-000000000001'::uuid, $2, $3, $4, $5, $6, $7,
                            $8::jsonb, $9::jsonb, $10::jsonb, COALESCE($11::timestamptz, NOW())
                        )
                        ON CONFLICT (id) DO NOTHING
                        """,
                        rid,
                        str(rec.get("prd") or ""),
                        str(rec.get("tech") or ""),
                        str(rec.get("clientRequestId") or ""),
                        rec.get("workflowRunId"),
                        rec.get("leafNodeCount"),
                        str(rec.get("status") or ""),
                        json.dumps(rec.get("warnings") or [], ensure_ascii=False),
                        json.dumps(rec.get("stageSummary"), ensure_ascii=False)
                        if rec.get("stageSummary") is not None
                        else None,
                        json.dumps(rec.get("outputs") or {}, ensure_ascii=False),
                        _parse_ts(rec.get("createdAt")),
                    )
        print(f"backfilled results from {results_path}")

        # input-pairs.json
        if pairs_path.exists():
            raw = json.loads(pairs_path.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                for p in raw:
                    if not isinstance(p, dict):
                        continue
                    pid = str(p.get("id") or "")
                    prd = str(p.get("prd") or "").strip()
                    tech = str(p.get("tech") or "").strip()
                    if not pid or not prd or not tech:
                        continue
                    fp = __import__("hashlib").sha256(f"{prd}\n{tech}".encode("utf-8")).hexdigest()
                    await conn.execute(
                        """
                        INSERT INTO input_pairs (
                            pair_id, workspace_id, prd, tech, fingerprint, used_count, created_at, updated_at
                        )
                        VALUES ($1, '00000000-0000-0000-0000-000000000001'::uuid, $2, $3, $4, $5, $6::timestamptz, $7::timestamptz)
                        ON CONFLICT (workspace_id, fingerprint) DO NOTHING
                        """,
                        pid,
                        prd,
                        tech,
                        fp,
                        int(p.get("usedCount") or 0),
                        _parse_ts(p.get("createdAt")),
                        _parse_ts(p.get("updatedAt")),
                    )
        print(f"backfilled input pairs from {pairs_path}")

        # wiki-auth.json
        if wiki_path.exists():
            try:
                w = json.loads(wiki_path.read_text(encoding="utf-8"))
            except Exception:
                w = {}
            if isinstance(w, dict) and (w.get("cookie") or w.get("authToken")):
                await conn.execute(
                    """
                    INSERT INTO wiki_auth_row (id, workspace_id, cookie, auth_token, updated_at, updated_by)
                    VALUES (1, '00000000-0000-0000-0000-000000000001'::uuid, $1, $2, $3::timestamptz, $4)
                    ON CONFLICT (id) DO UPDATE SET
                      cookie = EXCLUDED.cookie,
                      auth_token = EXCLUDED.auth_token,
                      updated_at = EXCLUDED.updated_at,
                      updated_by = EXCLUDED.updated_by
                    """,
                    str(w.get("cookie") or ""),
                    str(w.get("authToken") or ""),
                    _parse_ts(w.get("updatedAt")),
                    str(w.get("updatedBy") or ""),
                )
                print(f"backfilled wiki auth from {wiki_path}")

        # prompt-config.json
        if prompt_path.exists():
            try:
                pr = json.loads(prompt_path.read_text(encoding="utf-8"))
            except Exception:
                pr = {}
            if isinstance(pr, dict) and (pr.get("templates") or pr.get("knowledgeBase")):
                await conn.execute(
                    """
                    INSERT INTO prompt_config_row (id, workspace_id, templates, knowledge_base, updated_at, updated_by)
                    VALUES (1, '00000000-0000-0000-0000-000000000001'::uuid, $1::jsonb, $2, $3::timestamptz, $4)
                    ON CONFLICT (id) DO UPDATE SET
                      templates = EXCLUDED.templates,
                      knowledge_base = EXCLUDED.knowledge_base,
                      updated_at = EXCLUDED.updated_at,
                      updated_by = EXCLUDED.updated_by
                    """,
                    json.dumps(pr.get("templates") or {}, ensure_ascii=False),
                    str(pr.get("knowledgeBase") or ""),
                    _parse_ts(pr.get("updatedAt")),
                    str(pr.get("updatedBy") or ""),
                )
                print(f"backfilled prompt config from {prompt_path}")

        # 文档解析 parse_history.json + parse_jobs + parse_artifacts
        if parser_history_path.exists():
            try:
                parser_history = json.loads(parser_history_path.read_text(encoding="utf-8"))
            except Exception:
                parser_history = []
            if isinstance(parser_history, list):
                from artifact_store import store_directory, store_relative_path

                for rec in parser_history:
                    if not isinstance(rec, dict):
                        continue
                    job_id = str(rec.get("id") or "").strip()
                    if not job_id:
                        continue

                    await conn.execute(
                        """
                        INSERT INTO parse_jobs (
                            job_id, workspace_id, status, stage, stage_message, title, error,
                            source_type, source_url, target, payload_json, created_at, updated_at
                        )
                        VALUES (
                            $1, '00000000-0000-0000-0000-000000000001'::uuid,
                            $2, $3, $4, $5, $6, $7, $8, $9, $10::jsonb,
                            COALESCE($11::timestamptz, NOW()), NOW()
                        )
                        ON CONFLICT (job_id) DO UPDATE SET
                            status = EXCLUDED.status,
                            stage = EXCLUDED.stage,
                            stage_message = EXCLUDED.stage_message,
                            title = EXCLUDED.title,
                            error = EXCLUDED.error,
                            source_type = EXCLUDED.source_type,
                            source_url = EXCLUDED.source_url,
                            target = EXCLUDED.target,
                            payload_json = EXCLUDED.payload_json,
                            updated_at = NOW()
                        """,
                        job_id,
                        str(rec.get("status") or ""),
                        str(rec.get("stage") or ""),
                        str(rec.get("stageMessage") or ""),
                        str(rec.get("title") or ""),
                        str(rec.get("error") or ""),
                        str(rec.get("sourceType") or ""),
                        str(rec.get("sourceUrl") or ""),
                        str(rec.get("target") or ""),
                        json.dumps(rec, ensure_ascii=False),
                        _parse_ts(rec.get("createdAt")),
                    )

                    for item in rec.get("results") or []:
                        if not isinstance(item, dict):
                            continue
                        for field, kind in (
                            ("markdown", "markdown"),
                            ("ocr_markdown", "ocr_markdown"),
                            ("ocr_json", "ocr_json"),
                        ):
                            logical = str(item.get(field) or "").strip()
                            if logical:
                                store_relative_path(parser_root, job_id, logical, kind)
                        markdown_path = str(item.get("markdown") or "").strip()
                        if markdown_path:
                            store_directory(parser_root, job_id, f"images_{Path(markdown_path).stem}", "image")

                await conn.execute(
                    """
                    INSERT INTO parse_history_snapshot (id, entries)
                    VALUES (1, $1::jsonb)
                    ON CONFLICT (id) DO UPDATE SET entries = EXCLUDED.entries
                    """,
                    json.dumps(parser_history[:120], ensure_ascii=False),
                )
                print(f"backfilled parser history from {parser_history_path}")

        print("backfill complete")
    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(_main())
