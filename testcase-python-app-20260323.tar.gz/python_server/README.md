# Python 并行服务（staging）

与根目录 Node `server.js` **并行**运行，用于契约对照验证。**默认数据目录**为项目根目录下的 `data_py_shadow/`，不会写入 Node 使用的 `data/`。

## 环境

- Python 3.10+
- 依赖见 `requirements.txt`

```bash
cd python_server
pip3 install -r requirements.txt
```

从 `python_server` 目录启动（保证 `app` 包可导入）：

```bash
# 独立端口，避免与 Node（如 3002）冲突
PYTHON_PORT=8000 uvicorn app.main:app --host 0.0.0.0 --port 8000
```

或：

```bash
PYTHON_PORT=8000 python3 -m app.main
```

## 环境变量

与 Node 共用同一套生成相关变量（`BELLA_*`、`GEMINI_*`、`GENERATOR_PROVIDER` 等），从项目根 `.env` 加载需自行 `export` 或使用 `python-dotenv`（本实现未内置 dotenv，可用 shell `set -a; source ../.env; set +a`）。

**Python 专用：**

| 变量 | 说明 |
|------|------|
| `PYTHON_PORT` | 监听端口，默认 `8000` |
| `PYTHON_DATA_DIR` | 影子数据目录，默认 `<项目根>/data_py_shadow` |
| `PROJECT_ROOT` | 项目根（含 `public/`、`prompts/`），默认自动推断 |
| `DOC_PARSER_API_BASE` | 文档解析服务，默认 `http://localhost:5000` |

## 与 Node 对照

- 接口契约见 [docs/api-contract.md](../docs/api-contract.md)
- 验证步骤见 [docs/verify_parallel.md](../docs/verify_parallel.md)

## GitHub 自动构建镜像（GHCR）

推送到 `main` / `master` 后，Actions 会构建 Docker 镜像并推送到 **GitHub Container Registry**，便于虚拟机或云平台 `docker pull` 部署。说明见 [docs/github-python-deploy.md](../docs/github-python-deploy.md)。
