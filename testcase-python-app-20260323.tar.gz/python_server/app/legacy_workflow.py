"""Bella workflow/run streaming (SSE) — ported from server.js runLegacyWorkflowStreaming."""

from __future__ import annotations

import json
import re
from typing import Any

import httpx

from . import settings
from .providers import WorkflowRunError


def parse_sse(text: str) -> list[dict[str, str]]:
    events: list[dict[str, str]] = []
    lines = text.split("\n")
    current: dict[str, str] = {}
    for line in lines:
        if line.startswith("event:"):
            current["event"] = line[6:].strip()
        elif line.startswith("data:") and current.get("event"):
            current["data"] = line[5:].strip()
            events.append(dict(current))
            current = {}
    return events


def extract_from_sse_events(events: list[dict[str, str]]) -> dict[str, Any] | None:
    succeeded = next((e for e in events if e.get("event") == "onWorkflowRunSucceeded"), None)
    failed = next((e for e in events if e.get("event") == "onWorkflowRunFailed"), None)

    if succeeded and succeeded.get("data"):
        try:
            d = json.loads(succeeded["data"]) if isinstance(succeeded["data"], str) else succeeded["data"]
            return {
                "workflowRunId": d.get("workflowRunId"),
                "status": "succeeded",
                "outputs": d.get("outputs") or {},
                "error": None,
            }
        except json.JSONDecodeError:
            pass

    end_nodes = [e for e in events if e.get("event") == "onWorkflowNodeRunSucceeded"]
    end_node = end_nodes[-1] if end_nodes else None
    if end_node and end_node.get("data"):
        try:
            d = json.loads(end_node["data"]) if isinstance(end_node["data"], str) else end_node["data"]
            outputs = d.get("result", {}).get("outputs") or d.get("outputs")
            run_id = d.get("workflowRunId")
            if not run_id:
                any_e = next((e for e in events if e.get("data")), None)
                if any_e:
                    ad = json.loads(any_e["data"]) if isinstance(any_e["data"], str) else any_e["data"]
                    run_id = ad.get("workflowRunId")
            if outputs:
                return {
                    "workflowRunId": run_id,
                    "status": "succeeded",
                    "outputs": outputs,
                    "error": None,
                }
        except (json.JSONDecodeError, TypeError, KeyError):
            pass

    if failed and failed.get("data"):
        try:
            d = json.loads(failed["data"]) if isinstance(failed["data"], str) else failed["data"]
            return {
                "workflowRunId": d.get("workflowRunId"),
                "status": "failed",
                "outputs": d.get("outputs"),
                "error": d.get("error") or "工作流执行失败",
            }
        except json.JSONDecodeError:
            pass

    return None


async def run_legacy_workflow_streaming(
    *,
    workflow_id: str,
    inputs: dict[str, Any],
    label: str,
    timeout_ms: int = 300000,
    job: dict[str, Any] | None = None,
) -> dict[str, Any]:
    url = f"{settings.BELLA_BASE_URL}/workflow/run"
    body = {
        "tenantId": settings.BELLA_TENANT_ID,
        "workflowId": workflow_id,
        "inputs": inputs or {},
        "responseMode": "streaming",
        "userId": settings.BELLA_USER_ID,
        "userName": settings.BELLA_USER_NAME,
    }
    headers = {
        "Authorization": f"Bearer {settings.BELLA_API_KEY}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient() as client:
            r = await client.post(url, headers=headers, json=body, timeout=timeout_ms / 1000.0)
    except httpx.TimeoutException as e:
        if job and job.get("status") == "cancelled":
            raise WorkflowRunError("cancelled", label, workflow_id, f"{label}已中止") from e
        raise WorkflowRunError(
            "timeout", label, workflow_id, f"{label} 超时（5分钟）", http_status=None
        ) from e
    except Exception as e:
        raise WorkflowRunError(
            "workflow_error", label, workflow_id, str(e) or f"{label} 执行失败"
        ) from e

    raw = r.text
    if not r.is_success:
        err_msg = f"{label} 调用失败"
        try:
            parsed = json.loads(raw) if raw else {}
            err_msg = (
                parsed.get("message")
                or parsed.get("error")
                or (parsed.get("data") or {}).get("error")
                or err_msg
            )
        except json.JSONDecodeError:
            pass
        raise WorkflowRunError(
            "http_error", label, workflow_id, str(err_msg), http_status=r.status_code
        )

    ct = r.headers.get("content-type", "") or ""
    is_sse = "text/event-stream" in ct or "event:" in raw

    if is_sse:
        events = parse_sse(raw)
        extracted = extract_from_sse_events(events)
        if extracted and extracted.get("status") == "succeeded":
            return {
                "workflowRunId": extracted.get("workflowRunId"),
                "outputs": extracted.get("outputs") or {},
            }
        raise WorkflowRunError(
            "workflow_error",
            label,
            workflow_id,
            (extracted or {}).get("error") or f"{label} 未返回成功结果",
        )

    try:
        parsed = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        raise WorkflowRunError("workflow_error", label, workflow_id, f"{label} 执行失败")

    if parsed.get("code") and parsed.get("code") != 200:
        raise WorkflowRunError(
            "workflow_error",
            label,
            workflow_id,
            (parsed.get("data") or {}).get("error") or parsed.get("message") or f"{label} 执行失败",
        )

    data = parsed.get("data") or parsed or {}
    if data.get("status") and data.get("status") != "succeeded":
        raise WorkflowRunError(
            "workflow_error", label, workflow_id, data.get("error") or f"{label} 执行失败"
        )
    return {"workflowRunId": data.get("workflowRunId"), "outputs": data.get("outputs") or {}}
