"""Synchronous Postgres reads for code paths that are still sync-only (prompt/wiki)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from . import settings


def _psycopg():
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError as e:
        raise RuntimeError(
            "psycopg is required when DATABASE_URL is set. Install: pip install 'psycopg[binary]'"
        ) from e
    return psycopg, dict_row


def _conn():
    psycopg, dict_row = _psycopg()
    return psycopg.connect(settings.DATABASE_URL, row_factory=dict_row)


def fetch_prompt_config_row_sync() -> dict[str, Any] | None:
    if not settings.use_database():
        return None
    with _conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT templates, knowledge_base, updated_at, updated_by
                FROM prompt_config_row WHERE id = 1
                """
            )
            row = cur.fetchone()
    if not row:
        return None
    templates = row["templates"] if isinstance(row["templates"], dict) else {}
    ua = row["updated_at"]
    return {
        "templates": templates,
        "knowledgeBase": row["knowledge_base"] or "",
        "updatedAt": ua.isoformat() if isinstance(ua, datetime) else (str(ua) if ua else ""),
        "updatedBy": row["updated_by"] or "",
    }


def fetch_wiki_auth_row_sync() -> dict[str, Any] | None:
    if not settings.use_database():
        return None
    with _conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT cookie, auth_token, updated_at, updated_by
                FROM wiki_auth_row WHERE id = 1
                """
            )
            row = cur.fetchone()
    if not row:
        return None
    ua = row["updated_at"]
    return {
        "cookie": row["cookie"] or "",
        "authToken": row["auth_token"] or "",
        "updatedAt": ua.isoformat() if isinstance(ua, datetime) else (str(ua) if ua else ""),
        "updatedBy": row["updated_by"] or "",
    }
