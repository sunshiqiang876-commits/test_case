"""Persist testcase job dicts (job_snapshot JSONB)."""

from __future__ import annotations

import json
import copy
from datetime import datetime
from typing import Any

from .. import database, settings

WS = "00000000-0000-0000-0000-000000000001"


def _snapshot(job: dict[str, Any]) -> dict[str, Any]:
    j = copy.deepcopy(job)
    j.pop("runner_task", None)
    return json.loads(json.dumps(j, ensure_ascii=False, default=str))


def _parse_ts(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    s = str(value).strip()
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


async def upsert_job(job: dict[str, Any]) -> None:
    if not settings.use_database():
        return
    jid = job.get("id")
    if not jid:
        return
    snap = _snapshot(job)
    warnings = json.dumps(job.get("warnings") or [], ensure_ascii=False)
    result_json = json.dumps(job.get("result"), ensure_ascii=False) if job.get("result") is not None else None
    cr = str(job.get("clientRequestId") or "")
    completed_at = _parse_ts(job.get("completedAt"))

    await database.execute(
        """
        INSERT INTO testcase_jobs (
            job_id, workspace_id, client_request_id, prd, tech, status,
            current_stage, current_stage_label, error, warnings, result_json, job_snapshot,
            created_at, updated_at, completed_at
        )
        VALUES (
            $1::uuid, $2::uuid, $3, $4, $5, $6,
            $7, $8, $9, $10::jsonb, $11::jsonb, $12::jsonb,
            COALESCE($13::timestamptz, NOW()), COALESCE($14::timestamptz, NOW()), $15::timestamptz
        )
        ON CONFLICT (job_id) DO UPDATE SET
            client_request_id = EXCLUDED.client_request_id,
            prd = EXCLUDED.prd,
            tech = EXCLUDED.tech,
            status = EXCLUDED.status,
            current_stage = EXCLUDED.current_stage,
            current_stage_label = EXCLUDED.current_stage_label,
            error = EXCLUDED.error,
            warnings = EXCLUDED.warnings,
            result_json = EXCLUDED.result_json,
            job_snapshot = EXCLUDED.job_snapshot,
            updated_at = EXCLUDED.updated_at,
            completed_at = EXCLUDED.completed_at
        """,
        jid,
        WS,
        cr,
        str(job.get("prd") or ""),
        str(job.get("tech") or ""),
        str(job.get("status") or ""),
        str(job.get("currentStage") or ""),
        str(job.get("currentStageLabel") or ""),
        str(job.get("error") or ""),
        warnings,
        result_json,
        json.dumps(snap, ensure_ascii=False),
        _parse_ts(job.get("createdAt")),
        _parse_ts(job.get("updatedAt")),
        completed_at,
    )
    await _sync_job_stages(jid, snap.get("stages"))


async def _sync_job_stages(job_id: str, stages: Any) -> None:
    if not isinstance(stages, dict):
        await database.execute("DELETE FROM testcase_job_stages WHERE job_id = $1::uuid", job_id)
        return

    keys: list[str] = []
    for stage_key, stage in stages.items():
        if not isinstance(stage, dict):
            continue
        keys.append(str(stage_key))
        await database.execute(
            """
            INSERT INTO testcase_job_stages (
                job_id, stage_key, label, short_label, status, visible, message,
                attempt_count, retry_count, workflow_run_id, error, started_at, completed_at, updated_at
            )
            VALUES (
                $1::uuid, $2, $3, $4, $5, $6, $7,
                $8, $9, $10, $11, $12::timestamptz, $13::timestamptz,
                COALESCE($14::timestamptz, NOW())
            )
            ON CONFLICT (job_id, stage_key) DO UPDATE SET
                label = EXCLUDED.label,
                short_label = EXCLUDED.short_label,
                status = EXCLUDED.status,
                visible = EXCLUDED.visible,
                message = EXCLUDED.message,
                attempt_count = EXCLUDED.attempt_count,
                retry_count = EXCLUDED.retry_count,
                workflow_run_id = EXCLUDED.workflow_run_id,
                error = EXCLUDED.error,
                started_at = EXCLUDED.started_at,
                completed_at = EXCLUDED.completed_at,
                updated_at = EXCLUDED.updated_at
            """,
            job_id,
            str(stage_key),
            str(stage.get("label") or stage_key),
            str(stage.get("shortLabel") or ""),
            str(stage.get("status") or ""),
            stage.get("visible", True) is not False,
            str(stage.get("message") or ""),
            int(stage.get("attemptCount") or 0),
            int(stage.get("retryCount") or 0),
            stage.get("workflowRunId"),
            str(stage.get("error") or ""),
            _parse_ts(stage.get("startedAt")),
            _parse_ts(stage.get("completedAt")),
            _parse_ts(stage.get("updatedAt")),
        )

    if keys:
        await database.execute(
            "DELETE FROM testcase_job_stages WHERE job_id = $1::uuid AND NOT (stage_key = ANY($2::text[]))",
            job_id,
            keys,
        )
    else:
        await database.execute("DELETE FROM testcase_job_stages WHERE job_id = $1::uuid", job_id)


async def fetch_job(job_id: str) -> dict[str, Any] | None:
    if not settings.use_database():
        return None
    row = await database.fetchrow(
        "SELECT job_snapshot FROM testcase_jobs WHERE job_id = $1::uuid",
        job_id,
    )
    if not row or not row["job_snapshot"]:
        return None
    data = row["job_snapshot"]
    if isinstance(data, str):
        data = json.loads(data)
    return data if isinstance(data, dict) else None


async def find_latest_by_client_request_id(client_request_id: str) -> dict[str, Any] | None:
    if not settings.use_database():
        return None
    row = await database.fetchrow(
        """
        SELECT job_snapshot FROM testcase_jobs
        WHERE client_request_id = $1
        ORDER BY created_at DESC
        LIMIT 1
        """,
        client_request_id,
    )
    if not row or not row["job_snapshot"]:
        return None
    data = row["job_snapshot"]
    if isinstance(data, str):
        data = json.loads(data)
    return data if isinstance(data, dict) else None


async def delete_job(job_id: str) -> None:
    if not settings.use_database():
        return
    await database.execute("DELETE FROM testcase_jobs WHERE job_id = $1::uuid", job_id)


async def list_job_stages(job_id: str) -> list[dict[str, Any]]:
    if not settings.use_database():
        return []
    rows = await database.fetch(
        """
        SELECT stage_key, label, short_label, status, visible, message,
               attempt_count, retry_count, workflow_run_id, error,
               started_at, completed_at, updated_at
        FROM testcase_job_stages
        WHERE job_id = $1::uuid
        ORDER BY id ASC
        """,
        job_id,
    )
    out: list[dict[str, Any]] = []
    for row in rows:
        out.append(
            {
                "key": row["stage_key"],
                "label": row["label"],
                "shortLabel": row["short_label"],
                "status": row["status"],
                "visible": row["visible"],
                "message": row["message"],
                "attemptCount": row["attempt_count"],
                "retryCount": row["retry_count"],
                "workflowRunId": row["workflow_run_id"],
                "error": row["error"],
                "startedAt": row["started_at"].isoformat() if row["started_at"] else "",
                "completedAt": row["completed_at"].isoformat() if row["completed_at"] else "",
                "updatedAt": row["updated_at"].isoformat() if row["updated_at"] else "",
            }
        )
    return out
