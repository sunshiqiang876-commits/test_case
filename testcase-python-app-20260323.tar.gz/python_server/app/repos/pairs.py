"""Input pairs (replaces input-pairs.json)."""

from __future__ import annotations

import hashlib
import uuid
from datetime import datetime
from typing import Any

from .. import database, settings

WS = "00000000-0000-0000-0000-000000000001"


def fingerprint(prd: str, tech: str) -> str:
    return hashlib.sha256(f"{prd}\n{tech}".encode("utf-8")).hexdigest()


async def list_pairs() -> list[dict[str, Any]]:
    if not settings.use_database():
        return []
    rows = await database.fetch(
        """
        SELECT pair_id, prd, tech, used_count, created_at, updated_at
        FROM input_pairs
        ORDER BY updated_at DESC
        LIMIT 200
        """
    )
    out: list[dict[str, Any]] = []
    for r in rows:
        ca = r["created_at"]
        ua = r["updated_at"]
        out.append(
            {
                "id": r["pair_id"],
                "prd": r["prd"] or "",
                "tech": r["tech"] or "",
                "createdAt": ca.isoformat() if isinstance(ca, datetime) else str(ca),
                "updatedAt": ua.isoformat() if isinstance(ua, datetime) else str(ua),
                "usedCount": int(r["used_count"] or 0),
            }
        )
    return out


async def upsert_input_pair(prd_text: str, tech_text: str) -> None:
    if not settings.use_database():
        return
    fp = fingerprint(prd_text, tech_text)
    pair_id = str(uuid.uuid4())
    await database.execute(
        """
        INSERT INTO input_pairs (pair_id, workspace_id, prd, tech, fingerprint, used_count, created_at, updated_at)
        VALUES ($1, $2::uuid, $3, $4, $5, 1, NOW(), NOW())
        ON CONFLICT (workspace_id, fingerprint)
        DO UPDATE SET
          used_count = input_pairs.used_count + 1,
          updated_at = NOW(),
          prd = EXCLUDED.prd,
          tech = EXCLUDED.tech
        """,
        pair_id,
        WS,
        prd_text,
        tech_text,
        fp,
    )
