"""Single-row prompt + wiki config (replaces prompt-config.json / wiki-auth.json)."""

from __future__ import annotations

import json
from typing import Any

from .. import database, settings

WS = "00000000-0000-0000-0000-000000000001"


async def load_prompt_row() -> dict[str, Any] | None:
    if not settings.use_database():
        return None
    row = await database.fetchrow(
        """
        SELECT templates, knowledge_base, updated_at, updated_by
        FROM prompt_config_row WHERE id = 1
        """
    )
    if not row:
        return None
    return {
        "templates": row["templates"] if isinstance(row["templates"], dict) else {},
        "knowledgeBase": row["knowledge_base"] or "",
        "updatedAt": row["updated_at"].isoformat() if row["updated_at"] else "",
        "updatedBy": row["updated_by"] or "",
    }


async def save_prompt_row(templates: dict[str, Any], knowledge_base: str, updated_by: str) -> None:
    if not settings.use_database():
        return
    tjson = json.dumps(templates or {}, ensure_ascii=False)
    await database.execute(
        """
        INSERT INTO prompt_config_row (id, workspace_id, templates, knowledge_base, updated_at, updated_by)
        VALUES (1, $1::uuid, $2::jsonb, $3, NOW(), $4)
        ON CONFLICT (id) DO UPDATE SET
          templates = EXCLUDED.templates,
          knowledge_base = EXCLUDED.knowledge_base,
          updated_at = NOW(),
          updated_by = EXCLUDED.updated_by
        """,
        WS,
        tjson,
        knowledge_base or "",
        updated_by or "",
    )


async def delete_prompt_row() -> None:
    if not settings.use_database():
        return
    await database.execute("DELETE FROM prompt_config_row WHERE id = 1")


async def load_wiki_row() -> dict[str, Any] | None:
    if not settings.use_database():
        return None
    row = await database.fetchrow(
        """
        SELECT cookie, auth_token, updated_at, updated_by
        FROM wiki_auth_row WHERE id = 1
        """
    )
    if not row:
        return None
    return {
        "cookie": row["cookie"] or "",
        "authToken": row["auth_token"] or "",
        "updatedAt": row["updated_at"].isoformat() if row["updated_at"] else "",
        "updatedBy": row["updated_by"] or "",
    }


async def save_wiki_row(cookie: str, auth_token: str, updated_by: str) -> None:
    if not settings.use_database():
        return
    await database.execute(
        """
        INSERT INTO wiki_auth_row (id, workspace_id, cookie, auth_token, updated_at, updated_by)
        VALUES (1, $1::uuid, $2, $3, NOW(), $4)
        ON CONFLICT (id) DO UPDATE SET
          cookie = EXCLUDED.cookie,
          auth_token = EXCLUDED.auth_token,
          updated_at = NOW(),
          updated_by = EXCLUDED.updated_by
        """,
        WS,
        cookie or "",
        auth_token or "",
        updated_by or "",
    )


async def delete_wiki_row() -> None:
    if not settings.use_database():
        return
    await database.execute("DELETE FROM wiki_auth_row WHERE id = 1")
