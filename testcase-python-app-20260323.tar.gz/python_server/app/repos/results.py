"""Testcase results table."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from .. import database, settings

WS = "00000000-0000-0000-0000-000000000001"


def _parse_ts(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    s = str(value).strip()
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


async def list_results_ordered_newest_first() -> list[dict[str, Any]]:
    if not settings.use_database():
        return []
    rows = await database.fetch(
        """
        SELECT id, prd, tech, client_request_id, workflow_run_id, leaf_node_count, status,
               warnings, stage_summary, outputs, created_at
        FROM testcase_results
        ORDER BY created_at DESC
        """
    )
    out: list[dict[str, Any]] = []
    for r in rows:
        created = r["created_at"]
        created_iso = created.isoformat() if isinstance(created, datetime) else str(created)
        out.append(
            {
                "id": r["id"],
                "prd": r["prd"] or "",
                "tech": r["tech"] or "",
                "clientRequestId": r["client_request_id"] or "",
                "workflowRunId": r["workflow_run_id"],
                "leafNodeCount": r["leaf_node_count"],
                "status": r["status"] or "",
                "warnings": r["warnings"] if isinstance(r["warnings"], list) else [],
                "stageSummary": r["stage_summary"] if r["stage_summary"] is not None else None,
                "outputs": r["outputs"] if isinstance(r["outputs"], dict) else {},
                "createdAt": created_iso,
            }
        )
    return out


async def get_result_by_id(record_id: str) -> dict[str, Any] | None:
    if not settings.use_database():
        return None
    row = await database.fetchrow(
        """
        SELECT id, prd, tech, client_request_id, workflow_run_id, leaf_node_count, status,
               warnings, stage_summary, outputs, created_at
        FROM testcase_results WHERE id = $1
        """,
        record_id,
    )
    if not row:
        return None
    created = row["created_at"]
    created_iso = created.isoformat() if isinstance(created, datetime) else str(created)
    return {
        "id": row["id"],
        "prd": row["prd"] or "",
        "tech": row["tech"] or "",
        "clientRequestId": row["client_request_id"] or "",
        "workflowRunId": row["workflow_run_id"],
        "leafNodeCount": row["leaf_node_count"],
        "status": row["status"] or "",
        "warnings": row["warnings"] if isinstance(row["warnings"], list) else [],
        "stageSummary": row["stage_summary"] if row["stage_summary"] is not None else None,
        "outputs": row["outputs"] if isinstance(row["outputs"], dict) else {},
        "createdAt": created_iso,
    }


async def insert_result(record: dict[str, Any]) -> None:
    if not settings.use_database():
        return
    rid = str(record.get("id") or "")
    if not rid:
        return
    warnings = json.dumps(record.get("warnings") or [], ensure_ascii=False)
    stage_summary = (
        json.dumps(record.get("stageSummary"), ensure_ascii=False)
        if record.get("stageSummary") is not None
        else None
    )
    outputs = json.dumps(record.get("outputs") or {}, ensure_ascii=False)
    created = _parse_ts(record.get("createdAt"))
    await database.execute(
        """
        INSERT INTO testcase_results (
            id, workspace_id, prd, tech, client_request_id, workflow_run_id, leaf_node_count,
            status, warnings, stage_summary, outputs, created_at
        )
        VALUES (
            $1, $2::uuid, $3, $4, $5, $6, $7, $8, $9::jsonb, $10::jsonb, $11::jsonb, COALESCE($12::timestamptz, NOW())
        )
        ON CONFLICT (id) DO NOTHING
        """,
        rid,
        WS,
        str(record.get("prd") or ""),
        str(record.get("tech") or ""),
        str(record.get("clientRequestId") or ""),
        record.get("workflowRunId"),
        record.get("leafNodeCount"),
        str(record.get("status") or ""),
        warnings,
        stage_summary,
        outputs,
        created,
    )
