"""Markdown helpers ported from server.js."""

from __future__ import annotations

import re
from typing import Any


def strip_code_fences(text: str) -> str:
    value = str(text or "").strip()
    if not value.startswith("```"):
        return value
    v = re.sub(r"^```[a-zA-Z0-9_-]*\s*", "", value)
    return re.sub(r"\s*```$", "", v).strip()


def trim_markdown_from_first_heading(text: str) -> str:
    value = strip_code_fences(text)
    idx = value.find("#")
    return value[idx:].strip() if idx >= 0 else value.strip()


def trim_markdown_from_heading_level(text: str, level: int) -> str:
    marker = "#" * max(1, level)
    lines = str(text or "").splitlines()
    start = None
    pat = re.compile(rf"^\s*{re.escape(marker)}\s+")
    for i, line in enumerate(lines):
        if pat.match(line):
            start = i
            break
    if start is None:
        return trim_markdown_from_first_heading(text)
    return "\n".join(lines[start:]).strip()


def normalize_generated_markdown(text: str, heading_level: int = 1) -> str:
    if not text:
        return ""
    return (
        trim_markdown_from_heading_level(text, heading_level)
        if heading_level > 1
        else trim_markdown_from_first_heading(text)
    )


def extract_heading_text(markdown: str, level: int = 1) -> str:
    marker = "#" * max(1, level)
    m = re.search(rf"^\s*{re.escape(marker)}\s+(.+)$", str(markdown or ""), re.MULTILINE)
    return m.group(1).strip() if m else ""


def split_markdown_by_heading_level(markdown: str, level: int = 3) -> list[str]:
    marker = "#" * max(1, level)
    lines = str(markdown or "").splitlines()
    sections: list[list[str]] = []
    current: list[str] = []
    pat = re.compile(rf"^\s*{re.escape(marker)}\s+")
    for line in lines:
        if pat.match(line):
            if current:
                s = "\n".join(current).strip()
                if s:
                    sections.append(s)
            current = [line]
        else:
            if current:
                current.append(line)
    if current:
        s = "\n".join(current).strip()
        if s:
            sections.append(s)
    return sections


def join_markdown_fragments(fragments: list[str]) -> str:
    return "\n\n".join(str(f or "").strip() for f in fragments if str(f or "").strip())


def build_prompt_sections(sections: list[dict[str, str]]) -> str:
    parts = []
    for s in sections:
        if not s or not s.get("label"):
            continue
        label = s["label"]
        val = to_input_string(s.get("value"))
        parts.append(f"【{label}】\n{val}")
    return "\n\n".join(parts)


def first_non_empty_output(outputs: dict[str, Any] | None) -> str:
    if not outputs or not isinstance(outputs, dict):
        return ""
    for v in outputs.values():
        if isinstance(v, str) and v.strip():
            return v
    return ""


def to_input_string(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    try:
        import json

        return json.dumps(value, ensure_ascii=False, indent=2)
    except Exception:
        return str(value)


def extract_error(obj: Any) -> str | None:
    if obj is None:
        return None
    if isinstance(obj, list):
        for item in obj:
            v = extract_error(item)
            if v:
                return v
        return None
    if not isinstance(obj, dict):
        return None
    keys = ["error", "errorMessage", "message", "errMsg", "reason"]
    for k in keys:
        v = obj.get(k)
        if isinstance(v, str) and v.strip():
            return v
    for v in obj.values():
        if isinstance(v, (dict, list)):
            found = extract_error(v)
            if found:
                return found
    return None


def extract_markdown_nodes(markdown: str) -> list[dict[str, Any]]:
    lines = str(markdown or "").splitlines()
    last_heading_level = 0
    list_stack: list[dict[str, int]] = []
    nodes: list[dict[str, Any]] = []

    def resolve_list_level(indent: int) -> int:
        nonlocal list_stack
        if not list_stack:
            level = min((last_heading_level or 0) + 1, 9)
            list_stack.append({"indent": indent, "level": level})
            return level
        top = list_stack[-1]
        if indent > top["indent"]:
            level = min(top["level"] + 1, 9)
            list_stack.append({"indent": indent, "level": level})
            return level
        while list_stack and indent < list_stack[-1]["indent"]:
            list_stack.pop()
        if not list_stack:
            level = min((last_heading_level or 0) + 1, 9)
            list_stack.append({"indent": indent, "level": level})
            return level
        current = list_stack[-1]
        if indent == current["indent"]:
            return current["level"]
        level = min(current["level"] + 1, 9)
        list_stack.append({"indent": indent, "level": level})
        return level

    for line in lines:
        hm = re.match(r"^\s*(#{1,})\s+(.*)$", line)
        if hm:
            content = hm.group(2).strip()
            if not content:
                continue
            level = min(len(hm.group(1)), 9)
            last_heading_level = level
            list_stack.clear()
            nodes.append({"level": level, "text": content})
            continue
        lm = re.match(r"^(\s*)([-*+]|\d+\.)\s+(.*)$", line)
        if lm:
            content = lm.group(3).strip()
            if not content:
                continue
            indent = len(lm.group(1).replace("\t", "  "))
            level = resolve_list_level(indent)
            nodes.append({"level": level, "text": content})
    return nodes


def count_markdown_leaf_nodes(markdown: str) -> int:
    nodes = extract_markdown_nodes(markdown)
    if not nodes:
        return 0
    leaf = 0
    for idx in range(len(nodes)):
        cur = nodes[idx]
        nxt = nodes[idx + 1] if idx + 1 < len(nodes) else None
        if not nxt or nxt["level"] <= cur["level"]:
            leaf += 1
    return leaf


def convert_list_to_heading_md(md: str) -> str:
    """Match list-to-heading conversion used by Node /api/markdown/convert (server.js)."""
    lines = md.split("\n")
    last_level = 0
    last_heading_level = 0
    list_stack: list[dict[str, int]] = []
    result: list[str] = []

    def push_level_content(level: int, content: str) -> None:
        safe = max(1, min(level, 9))
        result.append("#" * safe + " " + content)

    def resolve_list_level(indent: int) -> int:
        nonlocal list_stack, last_heading_level
        if not list_stack:
            level = min((last_heading_level or 0) + 1, 9)
            list_stack.append({"indent": indent, "level": level})
            return level
        top = list_stack[-1]
        if indent > top["indent"]:
            level = min(top["level"] + 1, 9)
            list_stack.append({"indent": indent, "level": level})
            return level
        while list_stack and indent < list_stack[-1]["indent"]:
            list_stack.pop()
        if not list_stack:
            level = min((last_heading_level or 0) + 1, 9)
            list_stack.append({"indent": indent, "level": level})
            return level
        current = list_stack[-1]
        if indent == current["indent"]:
            return current["level"]
        level = min(current["level"] + 1, 9)
        list_stack.append({"indent": indent, "level": level})
        return level

    for line in lines:
        heading_match = re.match(r"^\s*(#+)\s+(.*)$", line)
        list_match = re.match(r"^(\s*)([-*+]|\d+\.)\s+(.*)$", line)
        if heading_match:
            raw_level = len(heading_match.group(1))
            content = heading_match.group(2)
            level = min(raw_level, 9)
            if last_level > 0 and level > last_level + 1:
                for lv in range(last_level + 1, level):
                    push_level_content(lv, "（占位）")
            last_level = level
            last_heading_level = level
            list_stack.clear()
            push_level_content(level, content)
        elif list_match:
            indent = len(list_match.group(1).replace("\t", "  "))
            content = list_match.group(3)
            new_level = resolve_list_level(indent)
            last_level = new_level
            push_level_content(new_level, content)
        else:
            result.append(line)
    return "\n".join(result)
