"""Testcase generation pipeline (mirrors server.js orchestration)."""

from __future__ import annotations

import asyncio
import re
import uuid
from typing import Any, Callable

from . import settings
from . import storage
from .job_state import (
    TESTCASE_STAGE_DEFS,
    add_job_warning,
    build_stage_summary,
    load_job_from_store,
    mark_job_cancelled,
    mark_stage_failed,
    mark_stage_running,
    mark_stage_succeeded,
    mark_stage_timed_out,
    new_job_id,
    schedule_testcase_job_cleanup,
    set_job_current_stage,
    set_job_result,
    touch_testcase_job,
    update_job_stage,
)
from .markdown_utils import (
    build_prompt_sections,
    count_markdown_leaf_nodes,
    extract_heading_text,
    first_non_empty_output,
    join_markdown_fragments,
    normalize_generated_markdown,
    split_markdown_by_heading_level,
    to_input_string,
    trim_markdown_from_heading_level,
)
from .prompt_config import get_resolved_element_knowledge_base, get_resolved_prompt_templates
from .providers import (
    WorkflowRunError,
    call_bella_chat_completions,
    call_gemini_generate_content,
    extract_bella_chat_error_message,
    extract_bella_chat_text,
    extract_gemini_error_message,
    extract_gemini_text,
)
from .legacy_workflow import run_legacy_workflow_streaming


def pick_output(outputs: dict[str, Any] | None, keys: list[str]) -> Any:
    if not outputs:
        return None
    for k in keys:
        v = outputs.get(k)
        if v is None:
            continue
        if isinstance(v, str) and v.strip():
            return v
        if not isinstance(v, str):
            return v
    return None


# --- pick_output alias for markdown_utils import fix ---
def _pick_output(outputs: dict[str, Any] | None, keys: list[str]) -> Any:
    return pick_output(outputs, keys)


async def delay(ms: float) -> None:
    await asyncio.sleep(ms / 1000.0)


def looks_like_timeout_message(message: str | None) -> bool:
    normalized = str(message or "").strip().lower()
    if not normalized:
        return False
    return (
        normalized == "timeout"
        or "timed out" in normalized
        or "time out" in normalized
        or "gateway timeout" in normalized
        or "request timeout" in normalized
        or "deadline exceeded" in normalized
        or "operation timeout" in normalized
        or "upstream timed out" in normalized
        or "upstream timeout" in normalized
        or "超时" in normalized
    )


def is_workflow_timeout_error(err: BaseException | None) -> bool:
    if not err:
        return False
    if isinstance(err, WorkflowRunError) and err.type == "timeout":
        return True
    if isinstance(err, WorkflowRunError):
        hs = err.http_status
        if hs in (408, 504, 524):
            return True
        if looks_like_timeout_message(str(err)):
            return True
    return looks_like_timeout_message(getattr(err, "message", None) or str(err))


def create_workflow_cancelled_error(label: str = "工作流", workflow_id: str = "") -> WorkflowRunError:
    return WorkflowRunError("cancelled", label, workflow_id, f"{label}已中止")


def build_stage_outputs(stage_config: dict[str, Any], value: Any) -> dict[str, Any]:
    nv = value if isinstance(value, str) else to_input_string(value)
    outputs: dict[str, Any] = {"text": nv, "result": nv}
    for k in stage_config.get("outputKeys") or []:
        outputs[k] = value
    return outputs


def get_output_text_from_outputs(outputs: dict[str, Any] | None) -> str:
    if not outputs:
        return ""
    if isinstance(outputs.get("text"), str):
        return outputs["text"]
    if isinstance(outputs.get("result"), str):
        return outputs["result"]
    return ""


def decorate_result_record(record: dict[str, Any] | None) -> dict[str, Any] | None:
    if not record or not isinstance(record, dict):
        return record
    if isinstance(record.get("leafNodeCount"), (int, float)):
        return record
    if record.get("status") == "failed":
        return {**record, "leafNodeCount": None}
    text = get_output_text_from_outputs(record.get("outputs") or {})
    return {**record, "leafNodeCount": count_markdown_leaf_nodes(text)}


async def upsert_input_pair(prd: str, tech: str) -> None:
    from .repos import pairs as pairs_repo

    prd_text = re.sub(r"\r\n", "\n", str(prd or "")).strip()
    tech_text = re.sub(r"\r\n", "\n", str(str(tech or ""))).strip()
    if not prd_text or not tech_text:
        return
    if settings.use_database():
        await pairs_repo.upsert_input_pair(prd_text, tech_text)
    now_iso = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()

    def updater(pairs: list[Any]) -> list[Any]:
        next_p = list(pairs) if isinstance(pairs, list) else []
        idx = next(
            (
                i
                for i, p in enumerate(next_p)
                if isinstance(p, dict)
                and re.sub(r"\r\n", "\n", str(p.get("prd", ""))).strip() == prd_text
                and re.sub(r"\r\n", "\n", str(p.get("tech", ""))).strip() == tech_text
            ),
            -1,
        )
        if idx >= 0:
            prev = next_p[idx]
            next_p[idx] = {
                **prev,
                "prd": prd_text,
                "tech": tech_text,
                "updatedAt": now_iso,
                "usedCount": int(prev.get("usedCount") or 0) + 1,
            }
        else:
            next_p.insert(
                0,
                {
                    "id": str(uuid.uuid4()),
                    "prd": prd_text,
                    "tech": tech_text,
                    "createdAt": now_iso,
                    "updatedAt": now_iso,
                    "usedCount": 1,
                },
            )
        next_p.sort(key=lambda x: x.get("updatedAt") or "", reverse=True)
        return next_p[:200]

    if (not settings.use_database()) or settings.dual_write_json():
        await storage.queue_json_array_update(settings.INPUT_PAIRS_FILE, updater)


async def append_result_record(record: dict[str, Any]) -> None:
    from .repos import results as results_repo

    if settings.use_database():
        await results_repo.insert_result(record)
    if (not settings.use_database()) or settings.dual_write_json():

        def updater(results: list[Any]) -> list[Any]:
            next_r = list(results) if isinstance(results, list) else []
            next_r.insert(0, record)
            return next_r

        await storage.queue_json_array_update(settings.RESULTS_FILE, updater)


def build_success_record(
    *,
    job: dict[str, Any],
    prd_text: str,
    tech_text: str,
    client_request_id: str,
    test_point_branch: dict[str, Any],
    elements_branch: dict[str, Any],
) -> dict[str, Any]:
    merged_outputs = {
        "text": "\n".join(
            [
                x
                for x in [
                    to_input_string(elements_branch.get("elementMatchResult")),
                    to_input_string(test_point_branch.get("testCase2")),
                ]
                if isinstance(x, str) and x.strip()
            ]
        ),
        "result": "\n".join(
            [
                x
                for x in [
                    to_input_string(elements_branch.get("elementMatchResult")),
                    to_input_string(test_point_branch.get("testCase2")),
                ]
                if isinstance(x, str) and x.strip()
            ]
        ),
        "test_point": test_point_branch.get("testPoint"),
        "elements_list": elements_branch.get("elementsList"),
        "test_case2": test_point_branch.get("testCase2"),
        "element_match": elements_branch.get("elementMatchResult"),
        "stages": {
            "testPoint": test_point_branch.get("testPointStage", {}).get("outputs") or {},
            "elements": elements_branch.get("elementsStage", {}).get("outputs") or {},
            "business": _build_generation_stage_outputs(test_point_branch.get("businessStage")),
            "elementMatch": _build_generation_stage_outputs(elements_branch.get("elementMatchStage")),
        },
    }
    wf = (
        test_point_branch.get("businessStage", {}).get("final", {}).get("workflowRunId")
        or elements_branch.get("elementMatchStage", {}).get("final", {}).get("workflowRunId")
        or test_point_branch.get("testPointStage", {}).get("workflowRunId")
        or elements_branch.get("elementsStage", {}).get("workflowRunId")
    )
    text = merged_outputs.get("text") or merged_outputs.get("result") or ""
    rid = str(uuid.uuid4())
    return {
        "id": rid,
        "prd": prd_text,
        "tech": tech_text,
        "clientRequestId": client_request_id,
        "outputs": merged_outputs,
        "leafNodeCount": count_markdown_leaf_nodes(text),
        "workflowRunId": wf,
        "stageSummary": build_stage_summary(job),
        "warnings": job.get("warnings") or [],
        "status": "succeeded",
        "createdAt": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
    }


def _build_generation_stage_outputs(stage_result: dict[str, Any] | None) -> dict[str, Any]:
    if not stage_result:
        return {"primary": {}, "fallback": {}, "final": {}, "usedFallback": False}
    return {
        "primary": (stage_result.get("primary") or {}).get("outputs") or {},
        "fallback": (stage_result.get("fallback") or {}).get("outputs") or {},
        "final": (stage_result.get("final") or {}).get("outputs") or {},
        "usedFallback": bool(stage_result.get("usedFallback")),
    }


def build_record_from_job_failure(
    *,
    job: dict[str, Any],
    prd_text: str,
    tech_text: str,
    client_request_id: str,
    error: BaseException,
) -> dict[str, Any]:
    msg = str(error) if error else "未知错误"
    return {
        "id": str(uuid.uuid4()),
        "prd": prd_text,
        "tech": tech_text,
        "clientRequestId": client_request_id,
        "outputs": {
            "text": f"生成失败\n{msg}",
            "result": f"生成失败\n{msg}",
            "error": msg,
            "stageSummary": build_stage_summary(job),
        },
        "leafNodeCount": None,
        "workflowRunId": None,
        "stageSummary": build_stage_summary(job),
        "warnings": job.get("warnings") or [],
        "status": "failed",
        "createdAt": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
    }


# --- Stage config factories ---


def _tpl() -> dict[str, str]:
    return get_resolved_prompt_templates()


async def run_ai_single_stage(
    *,
    stage_config: dict[str, Any],
    inputs: dict[str, Any],
    label: str,
    job: dict[str, Any] | None = None,
) -> dict[str, Any]:
    tpl = _tpl()
    key = stage_config["key"]
    system_instruction = stage_config.get("promptTemplate") or tpl[key]
    user_prompt = stage_config["buildUserPrompt"](inputs)

    if settings.PROVIDER == "gemini":
        wf_id, payload = await call_gemini_generate_content(
            stage_config=stage_config,
            label=label,
            system_instruction=system_instruction,
            user_prompt=user_prompt,
            timeout_ms=stage_config.get("timeoutMs") or settings.GEMINI_TIMEOUT_MS,
            job=job,
        )
        extracted = extract_gemini_text(payload)
        fr = payload.get("candidates", [{}])[0].get("finishReason") if payload.get("candidates") else None
        err_msg = extract_gemini_error_message(payload)
        if not str(extracted).strip():
            raise WorkflowRunError(
                "workflow_error",
                label,
                stage_config.get("key", settings.GEMINI_MODEL),
                err_msg or f"{label} 未返回有效内容",
            )
        if fr == "MAX_TOKENS" and job:
            add_job_warning(job, f"{label}输出达到上限，结果可能被截断")
        post = stage_config.get("postProcess")
        normalized = post(extracted) if post else str(extracted).strip()
        if not normalized:
            raise WorkflowRunError(
                "workflow_error",
                label,
                stage_config.get("key", settings.GEMINI_MODEL),
                f"{label} 返回内容为空",
            )
        return {"workflowRunId": wf_id, "outputs": build_stage_outputs(stage_config, normalized), "raw": payload}

    if settings.PROVIDER == "bella":
        wf_id, payload = await call_bella_chat_completions(
            stage_config=stage_config,
            label=label,
            system_instruction=system_instruction,
            user_prompt=user_prompt,
            timeout_ms=stage_config.get("timeoutMs") or settings.BELLA_CHAT_TIMEOUT_MS,
            job=job,
        )
        extracted = extract_bella_chat_text(payload)
        fr = payload.get("choices", [{}])[0].get("finish_reason") if payload.get("choices") else None
        err_msg = extract_bella_chat_error_message(payload)
        if not str(extracted).strip():
            raise WorkflowRunError(
                "workflow_error",
                label,
                stage_config.get("key", settings.BELLA_CHAT_MODEL),
                err_msg or f"{label} 未返回有效内容",
            )
        if fr == "length" and job:
            add_job_warning(job, f"{label}输出达到上限，结果可能被截断")
        post = stage_config.get("postProcess")
        normalized = post(extracted) if post else str(extracted).strip()
        if not normalized:
            raise WorkflowRunError(
                "workflow_error",
                label,
                stage_config.get("key", settings.BELLA_CHAT_MODEL),
                f"{label} 返回内容为空",
            )
        return {"workflowRunId": wf_id, "outputs": build_stage_outputs(stage_config, normalized), "raw": payload}

    # bella-workflow
    raw = await run_legacy_workflow_streaming(
        workflow_id=stage_config["legacyWorkflowId"],
        inputs=inputs,
        label=label,
        timeout_ms=stage_config.get("timeoutMs") or 300000,
        job=job,
    )
    text = get_output_text_from_outputs(raw.get("outputs") or {})
    post = stage_config.get("postProcess")
    normalized = post(text) if post else str(text or "").strip()
    if not normalized:
        raise WorkflowRunError(
            "workflow_error",
            label,
            stage_config.get("key", ""),
            f"{label} 返回内容为空",
        )
    return {
        "workflowRunId": raw.get("workflowRunId"),
        "outputs": build_stage_outputs(stage_config, normalized),
        "raw": {},
    }


async def run_gemini_business_fallback_chunks(
    *,
    stage_config: dict[str, Any],
    inputs: dict[str, Any],
    label: str,
    job: dict[str, Any] | None,
    progress_stage_key: str,
) -> dict[str, Any]:
    chunks = split_markdown_by_heading_level(inputs.get("test_point"), 3)
    if not chunks:
        merged_cfg = {
            **stage_config,
            "buildUserPrompt": lambda inp: build_prompt_sections(
                [
                    {"label": "测试点列表", "value": inp.get("test_point")},
                    {"label": "需求文档", "value": inp.get("prd")},
                    {"label": "技术文档", "value": inp.get("tech")},
                ]
            ),
            "postProcess": lambda t: normalize_generated_markdown(t, 2),
        }
        return await run_ai_single_stage(stage_config=merged_cfg, inputs=inputs, label=label, job=job)

    fragments: list[str] = []
    run_id = None
    for index, chunk in enumerate(chunks):
        if job and job.get("status") != "running":
            raise create_workflow_cancelled_error(label, stage_config.get("key", ""))
        if progress_stage_key:
            msg = f"{label}中（{index + 1}/{len(chunks)}）"
            update_job_stage(job, progress_stage_key, {"message": msg})
            set_job_current_stage(job, progress_stage_key, msg)
        inp = {**inputs, "test_point_chunk": chunk}
        result = await run_ai_single_stage(
            stage_config=stage_config,
            inputs=inp,
            label=f"{label} {index + 1}/{len(chunks)}",
            job=job,
        )
        run_id = run_id or result.get("workflowRunId")
        frag = _pick_output(result.get("outputs") or {}, stage_config.get("outputKeys") or []) or get_output_text_from_outputs(
            result.get("outputs") or {}
        )
        if frag:
            fragments.append(trim_markdown_from_heading_level(frag, 3))
    merged = join_markdown_fragments(fragments)
    if not merged.strip():
        raise WorkflowRunError(
            "workflow_error",
            label,
            stage_config.get("key", ""),
            f"{label} 未生成有效模块内容",
        )
    return {
        "workflowRunId": run_id,
        "outputs": build_stage_outputs(stage_config, f"## 业务逻辑\n\n{merged}"),
    }


async def run_gemini_element_match_fallback_chunks(
    *,
    stage_config: dict[str, Any],
    inputs: dict[str, Any],
    label: str,
    job: dict[str, Any] | None,
    progress_stage_key: str,
) -> dict[str, Any]:
    chunks = split_markdown_by_heading_level(inputs.get("element_list"), 3)
    kb = get_resolved_element_knowledge_base()
    if not chunks:
        merged_cfg = {
            **stage_config,
            "buildUserPrompt": lambda inp: build_prompt_sections(
                [
                    {"label": "界面元素列表", "value": inp.get("element_list")},
                    {"label": "组件测试点知识库", "value": kb},
                ]
            ),
            "postProcess": lambda t: normalize_generated_markdown(t),
        }
        return await run_ai_single_stage(stage_config=merged_cfg, inputs=inputs, label=label, job=job)

    title = extract_heading_text(inputs.get("element_list"), 1) or "界面元素"
    fragments = []
    run_id = None
    for index, chunk in enumerate(chunks):
        if job and job.get("status") != "running":
            raise create_workflow_cancelled_error(label, stage_config.get("key", ""))
        if progress_stage_key:
            progress_message = f"元素匹配兜底分片处理中（{index + 1}/{len(chunks)}）"
            update_job_stage(job, progress_stage_key, {"message": progress_message})
            set_job_current_stage(job, progress_stage_key, progress_message)
        result = await run_ai_single_stage(
            stage_config=stage_config,
            inputs={"element_list_chunk": chunk},
            label=f"{label} {index + 1}/{len(chunks)}",
            job=job,
        )
        run_id = run_id or result.get("workflowRunId")
        frag = _pick_output(result.get("outputs") or {}, stage_config.get("outputKeys") or []) or get_output_text_from_outputs(
            result.get("outputs") or {}
        )
        if frag:
            fragments.append(trim_markdown_from_heading_level(frag, 3))
    merged = join_markdown_fragments(fragments)
    final_text = (
        "\n\n".join([f"# {title}", "## 界面元素", merged])
        if merged
        else to_input_string(inputs.get("element_list"))
    )
    return {"workflowRunId": run_id, "outputs": build_stage_outputs(stage_config, final_text)}


async def run_ai_stage_execution(
    *,
    stage_config: dict[str, Any],
    inputs: dict[str, Any],
    label: str,
    job: dict[str, Any] | None,
    progress_stage_key: str = "",
) -> dict[str, Any]:
    mode = stage_config.get("executionMode")
    if mode == "businessFallbackChunks":
        return await run_gemini_business_fallback_chunks(
            stage_config=stage_config,
            inputs=inputs,
            label=label,
            job=job,
            progress_stage_key=progress_stage_key,
        )
    if mode == "elementMatchFallbackChunks":
        return await run_gemini_element_match_fallback_chunks(
            stage_config=stage_config,
            inputs=inputs,
            label=label,
            job=job,
            progress_stage_key=progress_stage_key,
        )
    return await run_ai_single_stage(stage_config=stage_config, inputs=inputs, label=label, job=job)


async def run_stage_execution(
    *,
    stage_config: dict[str, Any],
    inputs: dict[str, Any],
    label: str,
    job: dict[str, Any] | None,
    progress_stage_key: str = "",
) -> dict[str, Any]:
    if settings.PROVIDER in ("gemini", "bella"):
        if settings.PROVIDER == "gemini" and not settings.GEMINI_API_KEY:
            raise WorkflowRunError("workflow_error", label, "", "未配置 GEMINI_API_KEY")
        if settings.PROVIDER == "bella" and not settings.BELLA_API_KEY:
            raise WorkflowRunError("workflow_error", label, "", "未配置 BELLA_API_KEY")
        return await run_ai_stage_execution(
            stage_config=stage_config,
            inputs=inputs,
            label=label,
            job=job,
            progress_stage_key=progress_stage_key,
        )
    return await run_legacy_workflow_streaming(
        workflow_id=stage_config["legacyWorkflowId"],
        inputs=inputs,
        label=label,
        timeout_ms=stage_config.get("timeoutMs") or 300000,
        job=job,
    )


async def run_retrying_stage(
    *,
    job: dict[str, Any],
    stage_key: str,
    stage_config: dict[str, Any],
    inputs: dict[str, Any],
    label: str,
) -> dict[str, Any]:
    attempt = 0
    while job.get("status") == "running":
        attempt += 1
        retry_count = max(0, attempt - 1)
        running_message = (
            f"{label}请求超时，正在第{retry_count}次重试" if retry_count > 0 else f"{label}中"
        )
        mark_stage_running(job, stage_key, running_message, attempt, retry_count)
        try:
            stage_result = await run_stage_execution(
                stage_config=stage_config,
                inputs=inputs,
                label=label,
                job=job,
                progress_stage_key=stage_key,
            )
            mark_stage_succeeded(
                job,
                stage_key,
                message=(f"{label}重试成功" if retry_count > 0 else f"{label}完成"),
                workflow_run_id=stage_result.get("workflowRunId"),
                attempt_count=attempt,
                retry_count=retry_count,
            )
            return stage_result
        except Exception as error:
            if job.get("status") != "running":
                raise create_workflow_cancelled_error(label, stage_config.get("key", label))
            if not is_workflow_timeout_error(error):
                mark_stage_failed(job, stage_key, str(error) or f"{label}执行失败")
                raise
            update_job_stage(
                job,
                stage_key,
                {
                    "status": "retrying",
                    "visible": True,
                    "message": f"{label}请求超时，正在第{retry_count + 1}次重试",
                    "attemptCount": attempt,
                    "retryCount": retry_count + 1,
                    "error": str(error) or f"{label}超时",
                },
            )
            set_job_current_stage(job, stage_key, f"{label}请求超时，正在重试")
            await delay(1200)
    raise create_workflow_cancelled_error(label, stage_config.get("key", label))


async def run_stage_with_fallback(
    *,
    job: dict[str, Any],
    primary_stage_key: str,
    fallback_stage_key: str,
    primary_stage_config: dict[str, Any],
    fallback_stage_config: dict[str, Any],
    inputs: dict[str, Any],
    primary_label: str,
    fallback_label: str,
    timeout_warning: str,
) -> dict[str, Any]:
    if job.get("status") != "running":
        raise create_workflow_cancelled_error(primary_label, primary_stage_config.get("key", primary_label))
    mark_stage_running(job, primary_stage_key, f"{primary_label}中")
    try:
        primary = await run_stage_execution(
            stage_config=primary_stage_config,
            inputs=inputs,
            label=primary_label,
            job=job,
            progress_stage_key=primary_stage_key,
        )
        mark_stage_succeeded(
            job,
            primary_stage_key,
            message=f"{primary_label}完成",
            workflow_run_id=primary.get("workflowRunId"),
        )
        return {"primary": primary, "fallback": None, "final": primary, "usedFallback": False}
    except Exception as error:
        if job.get("status") != "running":
            raise create_workflow_cancelled_error(primary_label, primary_stage_config.get("key", primary_label))
        if not is_workflow_timeout_error(error):
            mark_stage_failed(job, primary_stage_key, str(error) or f"{primary_label}执行失败")
            raise
        mark_stage_timed_out(
            job,
            primary_stage_key,
            f"{primary_label}超时",
            str(error) or f"{primary_label}超时",
        )
        add_job_warning(job, timeout_warning)
        fb_label_def = TESTCASE_STAGE_DEFS.get(fallback_stage_key, {}).get("label") or f"{fallback_label}中"
        mark_stage_running(job, fallback_stage_key, fb_label_def)
        try:
            fallback = await run_stage_execution(
                stage_config=fallback_stage_config,
                inputs=inputs,
                label=fallback_label,
                job=job,
                progress_stage_key=fallback_stage_key,
            )
            mark_stage_succeeded(
                job,
                fallback_stage_key,
                message=f"{fallback_label}完成",
                workflow_run_id=fallback.get("workflowRunId"),
            )
            return {"primary": None, "fallback": fallback, "final": fallback, "usedFallback": True}
        except Exception as fallback_error:
            if job.get("status") != "running":
                raise create_workflow_cancelled_error(fallback_label, fallback_stage_config.get("key", fallback_label))
            mark_stage_failed(
                job, fallback_stage_key, str(fallback_error) or f"{fallback_label}执行失败"
            )
            raise


def build_stage_configs() -> dict[str, dict[str, Any]]:
    """Return stage config dicts with callables bound to current prompt resolution."""

    def tp(inp: dict[str, Any]) -> str:
        return build_prompt_sections(
            [
                {"label": "需求文档", "value": inp.get("prd")},
                {"label": "技术文档", "value": inp.get("tech")},
            ]
        )

    def el(inp: dict[str, Any]) -> str:
        return build_prompt_sections(
            [
                {"label": "需求文档", "value": inp.get("prd")},
                {"label": "技术文档", "value": inp.get("tech")},
            ]
        )

    def biz(inp: dict[str, Any]) -> str:
        return build_prompt_sections(
            [
                {"label": "测试点列表", "value": inp.get("test_point")},
                {"label": "需求文档", "value": inp.get("prd")},
                {"label": "技术文档", "value": inp.get("tech")},
            ]
        )

    def biz_fb(inp: dict[str, Any]) -> str:
        return build_prompt_sections(
            [
                {"label": "当前测试点模块片段", "value": inp.get("test_point_chunk")},
                {"label": "需求文档", "value": inp.get("prd")},
                {"label": "技术文档", "value": inp.get("tech")},
            ]
        )

    def em(inp: dict[str, Any]) -> str:
        return build_prompt_sections(
            [
                {"label": "界面元素列表", "value": inp.get("element_list")},
                {"label": "组件测试点知识库", "value": get_resolved_element_knowledge_base()},
            ]
        )

    def em_fb(inp: dict[str, Any]) -> str:
        return build_prompt_sections(
            [
                {"label": "当前界面模块片段", "value": inp.get("element_list_chunk")},
                {"label": "组件测试点知识库", "value": get_resolved_element_knowledge_base()},
            ]
        )

    return {
        "testPoint": {
            "key": "testPoint",
            "legacyWorkflowId": settings.BELLA_WORKFLOW_TEST_POINT_ID,
            "buildUserPrompt": tp,
            "postProcess": lambda t: normalize_generated_markdown(t),
            "outputKeys": ["test_point"],
        },
        "elements": {
            "key": "elements",
            "legacyWorkflowId": settings.BELLA_WORKFLOW_ELEMENTS_ID,
            "buildUserPrompt": el,
            "postProcess": lambda t: normalize_generated_markdown(t),
            "outputKeys": ["elements_list"],
        },
        "business": {
            "key": "business",
            "legacyWorkflowId": settings.BELLA_WORKFLOW_BIZ_ID,
            "timeoutMs": settings.BUSINESS_TIMEOUT_MS,
            "buildUserPrompt": biz,
            "postProcess": lambda t: normalize_generated_markdown(t, 2),
            "outputKeys": ["test_case2"],
        },
        "businessFallback": {
            "key": "businessFallback",
            "legacyWorkflowId": settings.BELLA_WORKFLOW_BIZ_FALLBACK_ID,
            "timeoutMs": settings.BUSINESS_TIMEOUT_MS,
            "thinkingLevel": "LOW",
            "executionMode": "businessFallbackChunks",
            "buildUserPrompt": biz_fb,
            "postProcess": lambda t: normalize_generated_markdown(t, 3),
            "outputKeys": ["test_case2"],
        },
        "elementMatch": {
            "key": "elementMatch",
            "legacyWorkflowId": settings.BELLA_WORKFLOW_ELEMENT_MATCH_ID,
            "timeoutMs": settings.ELEMENT_MATCH_TIMEOUT_MS,
            "buildUserPrompt": em,
            "postProcess": lambda t: normalize_generated_markdown(t),
            "outputKeys": ["element_match", "test_case2"],
        },
        "elementMatchFallback": {
            "key": "elementMatchFallback",
            "legacyWorkflowId": settings.BELLA_WORKFLOW_ELEMENT_MATCH_FALLBACK_ID,
            "timeoutMs": settings.ELEMENT_MATCH_TIMEOUT_MS,
            "thinkingLevel": "HIGH",
            "executionMode": "elementMatchFallbackChunks",
            "buildUserPrompt": em_fb,
            "postProcess": lambda t: normalize_generated_markdown(t, 3),
            "outputKeys": ["element_match", "test_case2"],
        },
    }


STAGE_CONFIGS = build_stage_configs()


async def run_test_point_branch(job: dict[str, Any], prd_text: str, tech_text: str) -> dict[str, Any]:
    sc = STAGE_CONFIGS
    test_point_stage = await run_retrying_stage(
        job=job,
        stage_key="testPoint",
        stage_config=sc["testPoint"],
        inputs={"prd": prd_text, "tech": tech_text},
        label="测试点提取",
    )
    test_point = (
        pick_output(test_point_stage.get("outputs") or {}, ["test_point", "testPoint", "points"])
        or get_output_text_from_outputs(test_point_stage.get("outputs") or {})
        or ""
    )
    business_stage = await run_stage_with_fallback(
        job=job,
        primary_stage_key="business",
        fallback_stage_key="businessFallback",
        primary_stage_config=sc["business"],
        fallback_stage_config=sc["businessFallback"],
        inputs={"prd": prd_text, "tech": tech_text, "test_point": to_input_string(test_point)},
        primary_label="业务逻辑生成",
        fallback_label="业务逻辑生成（兜底）",
        timeout_warning="业务逻辑生成超时，已转入兜底生成策略",
    )
    test_case2 = (
        pick_output(business_stage.get("final", {}).get("outputs") or {}, ["test_case2", "testCase2"])
        or get_output_text_from_outputs(business_stage.get("final", {}).get("outputs") or {})
        or ""
    )
    return {
        "testPointStage": test_point_stage,
        "testPoint": test_point,
        "businessStage": business_stage,
        "testCase2": test_case2,
    }


async def run_elements_branch(job: dict[str, Any], prd_text: str, tech_text: str) -> dict[str, Any]:
    sc = STAGE_CONFIGS
    elements_stage = await run_retrying_stage(
        job=job,
        stage_key="elements",
        stage_config=sc["elements"],
        inputs={"prd": prd_text, "tech": tech_text},
        label="元素提取",
    )
    elements_list = (
        pick_output(elements_stage.get("outputs") or {}, ["elements_list", "elementsList", "elements"])
        or get_output_text_from_outputs(elements_stage.get("outputs") or {})
        or ""
    )
    element_match_stage = await run_stage_with_fallback(
        job=job,
        primary_stage_key="elementMatch",
        fallback_stage_key="elementMatchFallback",
        primary_stage_config=sc["elementMatch"],
        fallback_stage_config=sc["elementMatchFallback"],
        inputs={"element_list": to_input_string(elements_list)},
        primary_label="元素匹配",
        fallback_label="元素匹配（兜底）",
        timeout_warning="元素匹配超时，已转入兜底匹配策略",
    )
    outs = element_match_stage.get("final", {}).get("outputs") or {}
    element_match_result = (
        pick_output(
            outs,
            ["match_result", "element_match", "matched_elements", "element_match_result", "test_case2"],
        )
        or get_output_text_from_outputs(outs)
        or first_non_empty_output(outs)
        or ""
    )
    return {
        "elementsStage": elements_stage,
        "elementsList": elements_list,
        "elementMatchStage": element_match_stage,
        "elementMatchResult": element_match_result,
    }


async def execute_testcase_job(job_id: str) -> None:
    job = await load_job_from_store(job_id)
    if not job:
        return
    prd_text = job["prd"]
    tech_text = job["tech"]
    try:
        tp_branch, el_branch = await asyncio.gather(
            run_test_point_branch(job, prd_text, tech_text),
            run_elements_branch(job, prd_text, tech_text),
        )
        if job.get("status") == "cancelled":
            raise create_workflow_cancelled_error("测试用例生成")
        record = build_success_record(
            job=job,
            prd_text=prd_text,
            tech_text=tech_text,
            client_request_id=job["clientRequestId"],
            test_point_branch=tp_branch,
            elements_branch=el_branch,
        )
        await append_result_record(record)
        set_job_result(
            job,
            "done",
            "",
            {
                "id": record["id"],
                "status": record["status"],
                "workflowRunId": record.get("workflowRunId"),
                "leafNodeCount": record.get("leafNodeCount"),
                "outputs": record["outputs"],
                "warnings": record.get("warnings") or [],
            },
            "测试用例已生成",
        )
    except asyncio.CancelledError:
        # Task cancellation (e.g. user abort) — align with Node AbortController.
        if job.get("status") == "running":
            mark_job_cancelled(job, "已中止生成")
        raise
    except Exception as error:
        if job.get("status") == "cancelled" or (
            isinstance(error, WorkflowRunError) and error.type == "cancelled"
        ):
            set_job_result(
                job,
                "cancelled",
                job.get("error") or str(error) or "已中止生成",
                None,
                job.get("currentStageLabel") or "已中止生成",
            )
            return
        job["status"] = "failed"
        job["error"] = str(error) or "生成失败"
        job["currentStage"] = ""
        job["currentStageLabel"] = "生成失败"
        touch_testcase_job(job)
        record = build_record_from_job_failure(
            job=job,
            prd_text=prd_text,
            tech_text=tech_text,
            client_request_id=job["clientRequestId"],
            error=error,
        )
        await append_result_record(record)
        set_job_result(
            job,
            "failed",
            str(error) or "生成失败",
            {
                "id": record["id"],
                "status": record["status"],
                "workflowRunId": record.get("workflowRunId"),
                "leafNodeCount": record.get("leafNodeCount"),
                "outputs": record["outputs"],
                "warnings": record.get("warnings") or [],
            },
            "生成失败",
        )
    finally:
        schedule_testcase_job_cleanup(job_id)
