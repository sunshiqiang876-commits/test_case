"""Bella Chat, Gemini, and legacy workflow HTTP clients."""

from __future__ import annotations

import json
from typing import Any

import httpx

from . import settings
from .markdown_utils import extract_error


class WorkflowRunError(Exception):
    def __init__(
        self,
        typ: str = "workflow_error",
        label: str = "",
        workflow_id: str = "",
        message: str = "",
        http_status: int | None = None,
    ):
        super().__init__(message or f"{label or '工作流'}执行失败")
        self.type = typ
        self.label = label
        self.workflow_id = workflow_id
        self.http_status = http_status


def extract_bella_chat_error_message(payload: dict[str, Any]) -> str:
    if not payload:
        return ""
    em = payload.get("error")
    if isinstance(em, dict) and isinstance(em.get("message"), str) and em["message"].strip():
        return em["message"].strip()
    if isinstance(payload.get("message"), str) and payload["message"].strip():
        return payload["message"].strip()
    fr = payload.get("choices", [{}])[0].get("finish_reason") if payload.get("choices") else None
    if isinstance(fr, str) and fr.strip() and fr.strip() != "stop":
        return f"Bella Chat 返回异常结束状态：{fr.strip()}"
    return extract_error(payload) or ""


def extract_bella_chat_text(payload: dict[str, Any]) -> str:
    choices = payload.get("choices") if isinstance(payload.get("choices"), list) else []
    if not choices:
        return ""
    content = choices[0].get("message", {}).get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
        return "".join(parts)
    return ""


def extract_gemini_text(payload: dict[str, Any]) -> str:
    cands = payload.get("candidates")
    if not isinstance(cands, list):
        return ""
    for cand in cands:
        parts = cand.get("content", {}).get("parts") if isinstance(cand, dict) else None
        if not isinstance(parts, list):
            continue
        text = "".join(
            p.get("text", "") for p in parts if isinstance(p, dict) and isinstance(p.get("text"), str)
        )
        if text.strip():
            return text
    return ""


def extract_gemini_error_message(payload: dict[str, Any]) -> str:
    if not payload:
        return ""
    te = payload.get("error")
    if isinstance(te, dict) and isinstance(te.get("message"), str) and te["message"].strip():
        return te["message"].strip()
    pf = payload.get("promptFeedback") or {}
    if isinstance(pf.get("blockReasonMessage"), str) and pf["blockReasonMessage"].strip():
        return pf["blockReasonMessage"].strip()
    if isinstance(pf.get("blockReason"), str) and pf["blockReason"].strip():
        return f"请求被 Gemini 拦截：{pf['blockReason'].strip()}"
    fr = payload.get("candidates", [{}])[0].get("finishReason") if payload.get("candidates") else None
    if isinstance(fr, str) and fr.strip() and fr != "STOP":
        return f"Gemini 返回异常结束状态：{fr.strip()}"
    return extract_error(payload) or ""


async def call_bella_chat_completions(
    *,
    stage_config: dict[str, Any],
    label: str,
    system_instruction: str,
    user_prompt: str,
    timeout_ms: int | None = None,
    job: dict[str, Any] | None = None,
) -> tuple[str | None, dict[str, Any]]:
    timeout_ms = timeout_ms or settings.BELLA_CHAT_TIMEOUT_MS
    url = f"{settings.BELLA_BASE_URL}/chat/completions"
    body: dict[str, Any] = {
        "model": settings.BELLA_CHAT_MODEL,
        "messages": [
            {"role": "system", "content": system_instruction},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": stage_config.get("temperature", settings.BELLA_CHAT_TEMPERATURE),
        "max_tokens": stage_config.get("maxOutputTokens", settings.BELLA_CHAT_MAX_TOKENS),
        "stream": False,
    }
    if settings.BELLA_USER_ID:
        body["user"] = settings.BELLA_USER_ID
    tl = stage_config.get("thinkingLevel") or settings.BELLA_CHAT_THINKING_LEVEL
    if tl:
        body["thinkingConfig"] = {"thinkingLevel": tl}

    headers = {
        "Authorization": f"Bearer {settings.BELLA_API_KEY}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient() as client:
            r = await client.post(url, headers=headers, json=body, timeout=timeout_ms / 1000.0)
    except httpx.TimeoutException as e:
        if job and job.get("status") == "cancelled":
            raise WorkflowRunError("cancelled", label, stage_config.get("key", ""), f"{label}已中止")
        raise WorkflowRunError(
            "timeout",
            label,
            stage_config.get("key", settings.BELLA_CHAT_MODEL),
            f"{label} 超时（{timeout_ms // 1000}秒）",
        ) from e
    except Exception as e:
        raise WorkflowRunError(
            "workflow_error",
            label,
            stage_config.get("key", settings.BELLA_CHAT_MODEL),
            str(e) or f"{label} 调用 Bella Chat 失败",
        ) from e

    raw = r.text
    try:
        payload = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        payload = {}
    if not r.is_success:
        msg = extract_bella_chat_error_message(payload) or f"{label} 调用 Bella Chat 失败"
        raise WorkflowRunError(
            "http_error",
            label,
            stage_config.get("key", settings.BELLA_CHAT_MODEL),
            msg,
            http_status=r.status_code,
        )
    run_id = payload.get("id") or r.headers.get("x-request-id")
    return run_id, payload


async def call_gemini_generate_content(
    *,
    stage_config: dict[str, Any],
    label: str,
    system_instruction: str,
    user_prompt: str,
    timeout_ms: int | None = None,
    job: dict[str, Any] | None = None,
) -> tuple[str | None, dict[str, Any]]:
    timeout_ms = timeout_ms or settings.GEMINI_TIMEOUT_MS
    url = f"{settings.GEMINI_BASE_URL}/models/{settings.GEMINI_MODEL}:generateContent"
    body = {
        "system_instruction": {"parts": [{"text": system_instruction}]},
        "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
        "generationConfig": {
            "temperature": stage_config.get("temperature", settings.GEMINI_TEMPERATURE),
            "maxOutputTokens": stage_config.get("maxOutputTokens", settings.GEMINI_MAX_OUTPUT_TOKENS),
            "responseMimeType": stage_config.get("responseMimeType", "text/plain"),
        },
    }
    headers = {"x-goog-api-key": settings.GEMINI_API_KEY, "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient() as client:
            r = await client.post(url, headers=headers, json=body, timeout=timeout_ms / 1000.0)
    except httpx.TimeoutException as e:
        if job and job.get("status") == "cancelled":
            raise WorkflowRunError("cancelled", label, stage_config.get("key", ""), f"{label}已中止")
        raise WorkflowRunError(
            "timeout",
            label,
            stage_config.get("key", settings.GEMINI_MODEL),
            f"{label} 超时（{timeout_ms // 1000}秒）",
        ) from e
    except Exception as e:
        raise WorkflowRunError(
            "workflow_error",
            label,
            stage_config.get("key", settings.GEMINI_MODEL),
            str(e) or f"{label} 调用 Gemini 失败",
        ) from e

    raw = r.text
    try:
        payload = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        payload = {}
    if not r.is_success:
        msg = extract_gemini_error_message(payload) or f"{label} 调用 Gemini 失败"
        raise WorkflowRunError(
            "http_error",
            label,
            stage_config.get("key", settings.GEMINI_MODEL),
            msg,
            http_status=r.status_code,
        )
    rid = (
        r.headers.get("x-request-id")
        or r.headers.get("x-guploader-uploadid")
        or payload.get("responseId")
        or payload.get("id")
    )
    return rid, payload
