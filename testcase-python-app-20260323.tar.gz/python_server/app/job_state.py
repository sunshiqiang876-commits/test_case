"""In-memory testcase jobs + stage state (mirrors server.js)."""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any

from . import settings

TESTCASE_STAGE_DEFS: dict[str, dict[str, Any]] = {
    "testPoint": {"label": "测试点提取中", "shortLabel": "测试点提取", "visibleByDefault": True},
    "elements": {"label": "元素提取中", "shortLabel": "元素提取", "visibleByDefault": True},
    "business": {"label": "业务逻辑生成中", "shortLabel": "业务逻辑生成", "visibleByDefault": True},
    "businessFallback": {"label": "兜底生成中", "shortLabel": "业务逻辑生成（兜底）", "visibleByDefault": False},
    "elementMatch": {"label": "元素匹配中", "shortLabel": "元素匹配", "visibleByDefault": True},
    "elementMatchFallback": {"label": "兜底匹配中", "shortLabel": "元素匹配（兜底）", "visibleByDefault": False},
}

TESTCASE_STAGE_ORDER = [
    "testPoint",
    "elements",
    "business",
    "businessFallback",
    "elementMatch",
    "elementMatchFallback",
]

# global job store (single event loop); optional mirror of Postgres when DATABASE_URL is set
testcase_jobs: dict[str, dict[str, Any]] = {}

_persist_tasks: dict[str, asyncio.Task[Any]] = {}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def create_testcase_stage_state(key: str) -> dict[str, Any]:
    d = TESTCASE_STAGE_DEFS.get(key, {"label": key, "shortLabel": key, "visibleByDefault": True})
    visible_default = d.get("visibleByDefault", True)
    t = now_iso()
    return {
        "key": key,
        "label": d["label"],
        "shortLabel": d["shortLabel"],
        "status": "pending" if visible_default else "hidden",
        "visible": visible_default,
        "message": "",
        "attemptCount": 0,
        "retryCount": 0,
        "workflowRunId": None,
        "error": "",
        "startedAt": "",
        "completedAt": "",
        "updatedAt": t,
    }


def create_testcase_job(job_id: str, client_request_id: str, prd: str, tech: str) -> dict[str, Any]:
    t = now_iso()
    stages = {k: create_testcase_stage_state(k) for k in TESTCASE_STAGE_ORDER}
    for s in stages.values():
        s["updatedAt"] = t
    return {
        "id": job_id,
        "clientRequestId": client_request_id,
        "prd": prd,
        "tech": tech,
        "status": "running",
        "currentStage": "",
        "currentStageLabel": "",
        "createdAt": t,
        "updatedAt": t,
        "completedAt": "",
        "error": "",
        "warnings": [],
        "result": None,
        "activeControllers": [],  # reserved; Node uses AbortController set
        "cleanupTimer": None,
        "stages": stages,
    }


def touch_testcase_job(job: dict[str, Any]) -> None:
    job["updatedAt"] = now_iso()
    _schedule_job_persist(job)


def _schedule_job_persist(job: dict[str, Any]) -> None:
    if not settings.use_database():
        return
    jid = str(job.get("id") or "")
    if not jid:
        return
    old = _persist_tasks.pop(jid, None)
    if old and not old.done():
        old.cancel()

    async def _run() -> None:
        try:
            await asyncio.sleep(0.45)
            from .repos import jobs as jobs_repo

            await jobs_repo.upsert_job(job)
        except asyncio.CancelledError:
            return
        except Exception:
            pass

    try:
        loop = asyncio.get_running_loop()
        _persist_tasks[jid] = loop.create_task(_run())
    except RuntimeError:
        pass


async def load_job_from_store(job_id: str) -> dict[str, Any] | None:
    if job_id in testcase_jobs:
        return testcase_jobs[job_id]
    if settings.use_database():
        from .repos import jobs as jobs_repo

        job = await jobs_repo.fetch_job(job_id)
        if job:
            testcase_jobs[job_id] = job
        return job
    return None


async def find_job_by_client_request_id_async(client_request_id: str) -> dict[str, Any] | None:
    if not client_request_id:
        return None
    matches = [j for j in testcase_jobs.values() if j.get("clientRequestId") == client_request_id]
    if matches:
        matches.sort(key=lambda j: j.get("createdAt", ""), reverse=True)
        return matches[0]
    if settings.use_database():
        from .repos import jobs as jobs_repo

        job = await jobs_repo.find_latest_by_client_request_id(client_request_id)
        if job:
            testcase_jobs[job["id"]] = job
        return job
    return None


def get_stage_row_label(stage_key: str, stage: dict[str, Any] | None) -> str:
    if stage_key == "business" and stage and stage.get("status") == "timed_out":
        return "业务逻辑生成超时"
    if stage_key == "elementMatch" and stage and stage.get("status") == "timed_out":
        return "元素匹配超时"
    return TESTCASE_STAGE_DEFS.get(stage_key, {}).get("label") or stage.get("label") or stage_key


def build_stage_summary(job: dict[str, Any]) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    for stage_key in TESTCASE_STAGE_ORDER:
        stage = job.get("stages", {}).get(stage_key)
        if not stage:
            continue
        if not stage.get("visible", True) and stage.get("status") == "hidden":
            continue
        summary[stage_key] = {
            "label": get_stage_row_label(stage_key, stage),
            "shortLabel": stage.get("shortLabel", ""),
            "status": stage.get("status", ""),
            "message": stage.get("message") or "",
            "attemptCount": stage.get("attemptCount") or 0,
            "retryCount": stage.get("retryCount") or 0,
            "workflowRunId": stage.get("workflowRunId"),
            "error": stage.get("error") or "",
            "startedAt": stage.get("startedAt") or "",
            "completedAt": stage.get("completedAt") or "",
            "visible": stage.get("visible", True) is not False,
        }
    return summary


def serialize_testcase_job(job: dict[str, Any] | None) -> dict[str, Any] | None:
    if not job:
        return None
    stages_out = []
    for stage_key in TESTCASE_STAGE_ORDER:
        stage = job.get("stages", {}).get(stage_key)
        if not stage:
            continue
        if not stage.get("visible", True) and stage.get("status") == "hidden":
            continue
        stages_out.append(
            {
                "key": stage_key,
                "label": get_stage_row_label(stage_key, stage),
                "shortLabel": stage.get("shortLabel", ""),
                "status": stage.get("status", ""),
                "message": stage.get("message") or "",
                "attemptCount": stage.get("attemptCount") or 0,
                "retryCount": stage.get("retryCount") or 0,
                "workflowRunId": stage.get("workflowRunId"),
                "error": stage.get("error") or "",
                "startedAt": stage.get("startedAt") or "",
                "completedAt": stage.get("completedAt") or "",
            }
        )
    return {
        "id": job["id"],
        "clientRequestId": job["clientRequestId"],
        "prd": job["prd"],
        "tech": job["tech"],
        "status": job["status"],
        "currentStage": job.get("currentStage", ""),
        "currentStageLabel": job.get("currentStageLabel", ""),
        "createdAt": job["createdAt"],
        "updatedAt": job["updatedAt"],
        "completedAt": job.get("completedAt") or "",
        "error": job.get("error") or "",
        "warnings": job.get("warnings") or [],
        "result": job.get("result"),
        "stages": stages_out,
        "stageSummary": build_stage_summary(job),
    }


def set_job_current_stage(job: dict[str, Any], stage_key: str, label: str = "") -> None:
    job["currentStage"] = stage_key or ""
    if label:
        job["currentStageLabel"] = label
    else:
        job["currentStageLabel"] = TESTCASE_STAGE_DEFS.get(stage_key, {}).get("label", "")
    touch_testcase_job(job)


def update_job_stage(job: dict[str, Any], stage_key: str, patch: dict[str, Any]) -> None:
    stage = job.get("stages", {}).get(stage_key)
    if not stage:
        return
    t = now_iso()
    stage.update(patch)
    if "visible" in patch:
        stage["visible"] = patch["visible"]
    if "workflowRunId" in patch:
        stage["workflowRunId"] = patch["workflowRunId"]
    if "error" in patch:
        stage["error"] = patch["error"]
    stage["updatedAt"] = t
    st = stage.get("status", "")
    if not stage.get("startedAt") and st in ("running", "retrying"):
        stage["startedAt"] = t
    if st in ("succeeded", "failed", "timed_out"):
        stage["completedAt"] = t
    touch_testcase_job(job)


def mark_stage_running(
    job: dict[str, Any],
    stage_key: str,
    message: str,
    attempt_count: int = 1,
    retry_count: int = 0,
) -> None:
    update_job_stage(
        job,
        stage_key,
        {
            "status": "retrying" if retry_count > 0 else "running",
            "visible": True,
            "message": message,
            "attemptCount": attempt_count,
            "retryCount": retry_count,
            "error": "",
        },
    )
    set_job_current_stage(
        job, stage_key, message or TESTCASE_STAGE_DEFS.get(stage_key, {}).get("label", "")
    )


def mark_stage_timed_out(job: dict[str, Any], stage_key: str, message: str, error: str) -> None:
    update_job_stage(
        job,
        stage_key,
        {"status": "timed_out", "visible": True, "message": message, "error": error or ""},
    )


def mark_stage_succeeded(
    job: dict[str, Any],
    stage_key: str,
    message: str = "",
    workflow_run_id: str | None = None,
    attempt_count: int = 1,
    retry_count: int = 0,
) -> None:
    update_job_stage(
        job,
        stage_key,
        {
            "status": "succeeded",
            "visible": True,
            "message": message,
            "workflowRunId": workflow_run_id,
            "attemptCount": attempt_count,
            "retryCount": retry_count,
            "error": "",
        },
    )


def mark_stage_failed(job: dict[str, Any], stage_key: str, error: str) -> None:
    update_job_stage(
        job,
        stage_key,
        {
            "status": "failed",
            "visible": True,
            "message": error or "执行失败",
            "error": error or "执行失败",
        },
    )


def add_job_warning(job: dict[str, Any], warning: str) -> None:
    if not warning:
        return
    w = job.setdefault("warnings", [])
    if warning not in w:
        w.append(warning)
    touch_testcase_job(job)


def set_job_result(
    job: dict[str, Any],
    status: str,
    error: str = "",
    result: Any = None,
    current_stage_label: str = "",
) -> None:
    job["status"] = status
    job["error"] = error
    job["result"] = result
    job["completedAt"] = now_iso()
    job["currentStage"] = ""
    job["currentStageLabel"] = current_stage_label
    touch_testcase_job(job)


def mark_job_cancelled(job: dict[str, Any], reason: str = "已中止生成") -> bool:
    if job["status"] in ("done", "failed", "cancelled"):
        return False
    t = now_iso()
    job["status"] = "cancelled"
    job["error"] = reason
    job["currentStage"] = ""
    job["currentStageLabel"] = reason
    for sk in TESTCASE_STAGE_ORDER:
        st = job.get("stages", {}).get(sk)
        if not st:
            continue
        if st.get("status") in ("running", "retrying"):
            st["status"] = "cancelled"
            st["message"] = reason
            st["error"] = reason
            st["completedAt"] = t
            st["updatedAt"] = t
    touch_testcase_job(job)
    t = job.get("runner_task")
    if isinstance(t, asyncio.Task) and not t.done():
        t.cancel()
    schedule_testcase_job_cleanup(job["id"], 30 * 60 * 1000)
    return True


_cleanup_tasks: dict[str, asyncio.Task[None]] = {}


def schedule_testcase_job_cleanup(job_id: str, delay_ms: int | None = None) -> None:
    delay = delay_ms if delay_ms is not None else settings.TESTCASE_JOB_RETENTION_MS

    async def _later() -> None:
        await asyncio.sleep(delay / 1000.0)
        testcase_jobs.pop(job_id, None)
        _cleanup_tasks.pop(job_id, None)
        if settings.use_database():
            from .repos import jobs as jobs_repo

            await jobs_repo.delete_job(job_id)

    if job_id in _cleanup_tasks:
        _cleanup_tasks[job_id].cancel()
    _cleanup_tasks[job_id] = asyncio.create_task(_later())


def find_job_by_client_request_id(client_request_id: str) -> dict[str, Any] | None:
    if not client_request_id:
        return None
    matches = [j for j in testcase_jobs.values() if j.get("clientRequestId") == client_request_id]
    if not matches:
        return None
    matches.sort(key=lambda j: j.get("createdAt", ""), reverse=True)
    return matches[0]


def new_job_id() -> str:
    return str(uuid.uuid4())
