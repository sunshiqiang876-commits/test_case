"""Atomic JSON file IO with per-file asyncio queues (mirrors Node queueJson*Update)."""

from __future__ import annotations

import asyncio
import json
import os
import uuid
from pathlib import Path
from typing import Any, Callable

from . import settings

_file_locks: dict[str, asyncio.Lock] = {}


def _lock_for(path: Path) -> asyncio.Lock:
    key = str(path.resolve())
    if key not in _file_locks:
        _file_locks[key] = asyncio.Lock()
    return _file_locks[key]


def ensure_data_dir() -> None:
    settings.DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_json_array(path: Path) -> list[Any]:
    if not path.exists():
        return []
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def load_json_object(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def save_json_array(path: Path, data: list[Any]) -> None:
    ensure_data_dir()
    temp = path.parent / f"{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp"
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def save_json_object(path: Path, data: dict[str, Any]) -> None:
    ensure_data_dir()
    temp = path.parent / f"{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp"
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


async def queue_json_array_update(
    path: Path, updater: Callable[[list[Any]], list[Any]]
) -> list[Any]:
    lock = _lock_for(path)
    async with lock:
        current = load_json_array(path)
        updated = updater(current)
        save_json_array(path, updated)
        return updated


async def queue_json_object_update(
    path: Path, updater: Callable[[dict[str, Any]], dict[str, Any]]
) -> dict[str, Any]:
    lock = _lock_for(path)
    async with lock:
        current = load_json_object(path)
        updated = updater(current)
        save_json_object(path, updated)
        return updated
