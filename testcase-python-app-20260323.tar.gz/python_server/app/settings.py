"""Environment and paths. Defaults keep production Node data untouched."""

from __future__ import annotations

import os
from pathlib import Path

# python_server/app -> project root
_APP_DIR = Path(__file__).resolve().parent
_PYTHON_SERVER_ROOT = _APP_DIR.parent
PROJECT_ROOT = Path(os.environ.get("PROJECT_ROOT", str(_PYTHON_SERVER_ROOT.parent))).resolve()

# Shadow data — never default to ./data (Node production)
DEFAULT_SHADOW = PROJECT_ROOT / "data_py_shadow"
DATA_DIR = Path(os.environ.get("PYTHON_DATA_DIR", str(DEFAULT_SHADOW))).resolve()

PUBLIC_DIR = PROJECT_ROOT / "public"
PROMPTS_DIR = PROJECT_ROOT / "prompts"

PORT = int(os.environ.get("PYTHON_PORT", os.environ.get("PORT", "8000")))

DOC_PARSER_API_BASE = os.environ.get("DOC_PARSER_API_BASE", "http://localhost:5000").rstrip("/")

WIKI_ADMIN_SECRET = os.environ.get("WIKI_ADMIN_SECRET", "ceshi_admin")
DEFAULT_WIKI_ADMIN_SECRET = "ceshi_admin"

ALLOWED_WIKI_HOSTS = frozenset({"wiki.lianjia.com"})
WIKI_HTML_ACCEPT = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"

TESTCASE_JOB_RETENTION_MS = int(os.environ.get("TESTCASE_JOB_RETENTION_MS", str(24 * 60 * 60 * 1000)))

# --- Generation (mirror server.js env) ---
GENERATOR_PROVIDER = os.environ.get("GENERATOR_PROVIDER", "").strip().lower()

BELLA_API_KEY = os.environ.get("BELLA_API_KEY", "")
BELLA_TENANT_ID = os.environ.get("BELLA_TENANT_ID", "04633c4f-8638-43a3-a02e-af23c29f821f")
BELLA_BASE_URL = os.environ.get("BELLA_BASE_URL", "https://openapi-ait.ke.com/v1").rstrip("/")
BELLA_USER_ID = os.environ.get("BELLA_USER_ID", "1000123")
BELLA_USER_NAME = os.environ.get("BELLA_USER_NAME", "测试用户")

BELLA_WORKFLOW_ID = os.environ.get("BELLA_WORKFLOW_ID", "")
BELLA_WORKFLOW_ELEMENTS_ID = os.environ.get(
    "BELLA_WORKFLOW_ELEMENTS_ID", "WKFL-5cfe7374-756c-4148-a66f-ed8c1add48f8"
)
BELLA_WORKFLOW_TEST_POINT_ID = os.environ.get(
    "BELLA_WORKFLOW_TEST_POINT_ID", "WKFL-114dd00d-7a0d-4278-907c-de17b44d1a72"
)
BELLA_WORKFLOW_ELEMENT_MATCH_ID = os.environ.get(
    "BELLA_WORKFLOW_ELEMENT_MATCH_ID", "WKFL-aed88848-7deb-4dcb-a5ee-942ee15b5a5e"
)
BELLA_WORKFLOW_BIZ_ID = os.environ.get(
    "BELLA_WORKFLOW_BIZ_ID", "WKFL-c23346f0-7084-4659-92b3-a25ae42a8db9"
)
BELLA_WORKFLOW_ELEMENT_MATCH_FALLBACK_ID = os.environ.get(
    "BELLA_WORKFLOW_ELEMENT_MATCH_FALLBACK_ID", "WKFL-04406fcc-ef15-4d35-9fe4-05ac735856e5"
)
BELLA_WORKFLOW_BIZ_FALLBACK_ID = os.environ.get(
    "BELLA_WORKFLOW_BIZ_FALLBACK_ID", "WKFL-76d7e6bb-f7a1-437b-addb-0988f957d96f"
)

BELLA_CHAT_MODEL = os.environ.get("BELLA_CHAT_MODEL", os.environ.get("GEMINI_MODEL", "gemini-3.1-pro-preview"))
BELLA_CHAT_TIMEOUT_MS = int(os.environ.get("BELLA_CHAT_TIMEOUT_MS", "300000"))
BELLA_CHAT_TEMPERATURE = float(os.environ.get("BELLA_CHAT_TEMPERATURE", "0.2"))
BELLA_CHAT_MAX_TOKENS = int(os.environ.get("BELLA_CHAT_MAX_TOKENS", "65536"))
BELLA_CHAT_THINKING_LEVEL = os.environ.get("BELLA_CHAT_THINKING_LEVEL", "HIGH").strip().upper()

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.1-pro-preview")
GEMINI_BASE_URL = os.environ.get("GEMINI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
GEMINI_TIMEOUT_MS = int(os.environ.get("GEMINI_TIMEOUT_MS", "300000"))
GEMINI_TEMPERATURE = float(os.environ.get("GEMINI_TEMPERATURE", "0.2"))
GEMINI_MAX_OUTPUT_TOKENS = int(os.environ.get("GEMINI_MAX_OUTPUT_TOKENS", "65536"))

def normalize_env_number(raw: str | None, fallback: int) -> int:
    try:
        v = float(raw) if raw is not None else float("nan")
        if v > 0:
            return int(v)
    except (TypeError, ValueError):
        pass
    return fallback


BUSINESS_TIMEOUT_MS = normalize_env_number(os.environ.get("BUSINESS_TIMEOUT_MS"), 600000)
ELEMENT_MATCH_TIMEOUT_MS = normalize_env_number(os.environ.get("ELEMENT_MATCH_TIMEOUT_MS"), 600000)


def resolve_generation_provider() -> str:
    if GENERATOR_PROVIDER in ("gemini", "bella", "bella-workflow"):
        return GENERATOR_PROVIDER
    if os.environ.get("GEMINI_API_KEY"):
        return "gemini"
    if os.environ.get("BELLA_API_KEY"):
        return "bella"
    return "bella-workflow"


PROVIDER = resolve_generation_provider()


def is_gemini_config_ready() -> bool:
    return bool(GEMINI_API_KEY and GEMINI_MODEL and GEMINI_BASE_URL)


def is_bella_chat_config_ready() -> bool:
    return bool(BELLA_API_KEY and BELLA_BASE_URL and BELLA_CHAT_MODEL)


def is_bella_workflow_config_ready() -> bool:
    return bool(
        BELLA_API_KEY
        and BELLA_TENANT_ID
        and BELLA_WORKFLOW_ELEMENTS_ID
        and BELLA_WORKFLOW_TEST_POINT_ID
        and BELLA_WORKFLOW_ELEMENT_MATCH_ID
        and BELLA_WORKFLOW_BIZ_ID
        and BELLA_WORKFLOW_ELEMENT_MATCH_FALLBACK_ID
        and BELLA_WORKFLOW_BIZ_FALLBACK_ID
    )


def is_generation_config_ready() -> bool:
    if PROVIDER == "gemini":
        return is_gemini_config_ready()
    if PROVIDER == "bella":
        return is_bella_chat_config_ready()
    return is_bella_workflow_config_ready()


RESULTS_FILE = DATA_DIR / "results.json"
INPUT_PAIRS_FILE = DATA_DIR / "input-pairs.json"
WIKI_AUTH_FILE = DATA_DIR / "wiki-auth.json"
PROMPT_CONFIG_FILE = DATA_DIR / "prompt-config.json"

TMP_MD2XMIND = Path(os.environ.get("TMP_MD2XMIND", "")) if os.environ.get("TMP_MD2XMIND") else None

# --- Postgres (optional; when set, app uses DB + optional JSON dual-write) ---
DATABASE_URL = (os.environ.get("DATABASE_URL") or "").strip()


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


# When DATABASE_URL is set, also write legacy JSON files (safer rollback during migration).
DATABASE_DUAL_WRITE_JSON = _env_bool("DATABASE_DUAL_WRITE_JSON", True)


def use_database() -> bool:
    return bool(DATABASE_URL)


def dual_write_json() -> bool:
    return use_database() and DATABASE_DUAL_WRITE_JSON
