"""Prompt templates + runtime overrides (mirrors server.js prompt loading)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import settings

PROMPT_FILE_MAP: dict[str, str] = {
    "testPoint": "test-point.system.md",
    "elements": "elements.system.md",
    "business": "business.system.md",
    "businessFallback": "business.fallback.system.md",
    "elementMatch": "element-match.system.md",
    "elementMatchFallback": "element-match.fallback.system.md",
}

PROMPT_LABELS: dict[str, str] = {
    "testPoint": "测试点 Prompt",
    "elements": "界面元素 Prompt",
    "business": "业务用例 Prompt",
    "businessFallback": "业务兜底 Prompt",
    "elementMatch": "元素匹配 Prompt",
    "elementMatchFallback": "元素匹配兜底 Prompt",
    "knowledgeBase": "组件测试点知识库",
}


def normalize_prompt_text(value: str | None) -> str:
    if not isinstance(value, str):
        return ""
    return value.replace("\r\n", "\n").strip()


def load_prompt_text(file_name: str) -> str:
    path = settings.PROMPTS_DIR / file_name
    return path.read_text(encoding="utf-8").strip()


def load_default_prompt_templates() -> dict[str, str]:
    try:
        return {k: load_prompt_text(v) for k, v in PROMPT_FILE_MAP.items()}
    except OSError:
        return {k: "" for k in PROMPT_FILE_MAP}


DEFAULT_PROMPT_TEMPLATES = load_default_prompt_templates()
try:
    DEFAULT_ELEMENT_KNOWLEDGE_BASE = load_prompt_text("element-knowledge-base.md")
except OSError:
    DEFAULT_ELEMENT_KNOWLEDGE_BASE = ""


def _normalize_runtime_from_source(
    raw_templates: dict[str, Any] | None,
    knowledge_base_raw: Any,
    updated_at_raw: Any,
    updated_by_raw: Any,
    *,
    exists: bool,
) -> dict[str, Any]:
    raw_templates = raw_templates if isinstance(raw_templates, dict) else {}
    templates: dict[str, str] = {}
    for key in PROMPT_FILE_MAP:
        v = normalize_prompt_text(raw_templates.get(key))
        if v:
            templates[key] = v
    return {
        "exists": exists,
        "templates": templates,
        "knowledgeBase": normalize_prompt_text(knowledge_base_raw),
        "updatedAt": (str(updated_at_raw or "")).strip() if updated_at_raw is not None else "",
        "updatedBy": (str(updated_by_raw or "")).strip() if updated_by_raw is not None else "",
    }


def load_runtime_prompt_config() -> dict[str, Any]:
    if settings.use_database():
        from .db_sync import fetch_prompt_config_row_sync

        db = fetch_prompt_config_row_sync()
        if db is not None:
            return _normalize_runtime_from_source(
                db.get("templates"),
                db.get("knowledgeBase"),
                db.get("updatedAt"),
                db.get("updatedBy"),
                exists=True,
            )

    path = settings.PROMPT_CONFIG_FILE
    if not path.exists():
        return {
            "exists": False,
            "templates": {},
            "knowledgeBase": "",
            "updatedAt": "",
            "updatedBy": "",
        }
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return {
            "exists": False,
            "templates": {},
            "knowledgeBase": "",
            "updatedAt": "",
            "updatedBy": "",
        }
    raw_templates = raw.get("templates") if isinstance(raw.get("templates"), dict) else {}
    return _normalize_runtime_from_source(
        raw_templates,
        raw.get("knowledgeBase"),
        raw.get("updatedAt"),
        raw.get("updatedBy"),
        exists=True,
    )


def get_resolved_prompt_templates() -> dict[str, str]:
    runtime = load_runtime_prompt_config()
    merged = {**DEFAULT_PROMPT_TEMPLATES, **runtime["templates"]}
    return merged


def get_resolved_element_knowledge_base() -> str:
    runtime = load_runtime_prompt_config()
    kb = runtime.get("knowledgeBase") or ""
    return kb if kb else DEFAULT_ELEMENT_KNOWLEDGE_BASE


def build_prompt_config_payload(include_content: bool = False) -> dict[str, Any]:
    runtime = load_runtime_prompt_config()
    resolved = get_resolved_prompt_templates()
    knowledge_base = get_resolved_element_knowledge_base()
    template_entries = []
    for key in PROMPT_FILE_MAP:
        rt = runtime["templates"].get(key)
        template_entries.append(
            {
                "key": key,
                "label": PROMPT_LABELS.get(key, key),
                "fileName": PROMPT_FILE_MAP[key],
                "source": "runtime" if rt else "file",
                "runtimeOverridden": bool(rt),
                "content": resolved.get(key) if include_content else None,
            }
        )
    runtime_override_count = sum(1 for t in template_entries if t["runtimeOverridden"])
    if runtime.get("knowledgeBase"):
        runtime_override_count += 1
    return {
        "updatedAt": runtime.get("updatedAt", ""),
        "updatedBy": runtime.get("updatedBy", ""),
        "runtimeOverrideCount": runtime_override_count,
        "templates": template_entries,
        "knowledgeBase": {
            "key": "knowledgeBase",
            "label": PROMPT_LABELS["knowledgeBase"],
            "fileName": "element-knowledge-base.md",
            "source": "runtime" if runtime.get("knowledgeBase") else "file",
            "runtimeOverridden": bool(runtime.get("knowledgeBase")),
            "content": knowledge_base if include_content else None,
        },
    }


async def save_runtime_prompt_config(
    templates: dict[str, Any], knowledge_base: str, updated_by: str
) -> dict[str, Any]:
    from .storage import queue_json_object_update
    from .repos import config_rows

    next_templates: dict[str, str] = {}
    for key in PROMPT_FILE_MAP:
        v = normalize_prompt_text(templates.get(key) if isinstance(templates, dict) else None)
        if v and v != DEFAULT_PROMPT_TEMPLATES.get(key):
            next_templates[key] = v
    next_kb = normalize_prompt_text(knowledge_base)
    normalized_kb = next_kb if next_kb and next_kb != DEFAULT_ELEMENT_KNOWLEDGE_BASE else ""

    if not next_templates and not normalized_kb:
        if settings.PROMPT_CONFIG_FILE.exists():
            settings.PROMPT_CONFIG_FILE.unlink()
        if settings.use_database():
            await config_rows.delete_prompt_row()
        return load_runtime_prompt_config()

    from datetime import datetime, timezone

    payload = {
        "templates": next_templates,
        "knowledgeBase": normalized_kb,
        "updatedAt": datetime.now(timezone.utc).isoformat(),
        "updatedBy": (updated_by or "").strip() or "manual-admin",
    }

    if settings.use_database():
        await config_rows.save_prompt_row(next_templates, normalized_kb, payload["updatedBy"])

    if (not settings.use_database()) or settings.dual_write_json():

        def _write(_: dict[str, Any]) -> dict[str, Any]:
            return payload

        await queue_json_object_update(settings.PROMPT_CONFIG_FILE, _write)
    return load_runtime_prompt_config()
