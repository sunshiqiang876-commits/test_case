"""Wiki auth + doc-parser proxy headers (mirrors server.js)."""

from __future__ import annotations

import html
import re
from typing import Any
from urllib.parse import urlparse

import httpx

from . import settings
from .storage import load_json_object, queue_json_object_update


def normalize_optional_string(value: str | None) -> str:
    return str(value or "").strip()


def normalize_wiki_cookie(cookie: str | None) -> str:
    s = str(cookie or "").strip()
    if s.lower().startswith("cookie:"):
        s = s[7:].strip()
    if not s:
        return ""
    parts = [p.strip() for p in s.split(";") if p.strip()]
    preferred = [p for p in parts if re.match(r"^JSESSIONID=", p, re.I) or re.match(r"^seraph\.confluence=", p, re.I)]
    return "; ".join(preferred if preferred else parts)


def normalize_wiki_auth_token(value: str | None) -> str:
    s = normalize_optional_string(value)
    if s.lower().startswith("bearer "):
        return s[7:].strip()
    return s


def mask_secret_value(value: str, visible_start: int = 4, visible_end: int = 4) -> str:
    raw = normalize_optional_string(value)
    if not raw:
        return ""
    if len(raw) <= visible_start + visible_end + 3:
        return f"{raw[:1]}***{raw[-1:]}"
    return f"{raw[:visible_start]}***{raw[-visible_end:]}"


def mask_cookie_string(cookie: str | None) -> str:
    raw = normalize_optional_string(cookie)
    if not raw:
        return ""
    return "; ".join(
        mask_secret_value(p.split("=", 1)[1]) if "=" in p else mask_secret_value(p)
        for p in (x.strip() for x in raw.split(";"))
        if p
    )


def load_runtime_wiki_auth() -> dict[str, Any]:
    if settings.use_database():
        from .db_sync import fetch_wiki_auth_row_sync

        db = fetch_wiki_auth_row_sync()
        if db is not None:
            ck = normalize_wiki_cookie(str(db.get("cookie", "")))
            tok = normalize_wiki_auth_token(str(db.get("authToken", "")))
            return {
                "exists": bool(ck or tok),
                "cookie": ck,
                "authToken": tok,
                "updatedAt": normalize_optional_string(db.get("updatedAt")),
                "updatedBy": normalize_optional_string(db.get("updatedBy")),
            }

    path = settings.WIKI_AUTH_FILE
    if not path.exists():
        return {"exists": False, "cookie": "", "authToken": "", "updatedAt": "", "updatedBy": ""}
    raw = load_json_object(path)
    return {
        "exists": True,
        "cookie": normalize_wiki_cookie(str(raw.get("cookie", ""))),
        "authToken": normalize_wiki_auth_token(str(raw.get("authToken", ""))),
        "updatedAt": normalize_optional_string(raw.get("updatedAt")),
        "updatedBy": normalize_optional_string(raw.get("updatedBy")),
    }


def resolve_wiki_auth() -> dict[str, Any]:
    runtime = load_runtime_wiki_auth()
    if runtime.get("cookie") or runtime.get("authToken"):
        return {
            "source": "runtime",
            "cookie": runtime["cookie"],
            "authToken": runtime["authToken"],
            "updatedAt": runtime["updatedAt"],
            "updatedBy": runtime["updatedBy"],
        }
    import os

    env_cookie = normalize_wiki_cookie(os.environ.get("WIKI_COOKIE", ""))
    env_token = normalize_wiki_auth_token(os.environ.get("WIKI_AUTH_TOKEN", ""))
    return {
        "source": "env" if (env_cookie or env_token) else "none",
        "cookie": env_cookie,
        "authToken": env_token,
        "updatedAt": "",
        "updatedBy": "",
    }


def build_wiki_request_headers(auth: dict[str, Any], accept: str = settings.WIKI_HTML_ACCEPT) -> dict[str, str]:
    h: dict[str, str] = {"Accept": accept}
    if auth.get("cookie"):
        h["Cookie"] = auth["cookie"]
    if auth.get("authToken"):
        h["Authorization"] = f"Bearer {auth['authToken']}"
    return h


def build_doc_parser_proxy_headers(base: dict[str, str] | None = None) -> dict[str, str]:
    headers = dict(base or {})
    auth = resolve_wiki_auth()
    if auth.get("cookie"):
        headers["X-Wiki-Cookie"] = auth["cookie"]
    if auth.get("authToken"):
        headers["X-Wiki-Auth-Token"] = auth["authToken"]
    return headers


def extract_html_title(html_text: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", html_text, re.I | re.S)
    if not m:
        return ""
    return html.unescape(re.sub(r"\s+", " ", m.group(1)).strip())


def looks_like_wiki_login_html(html_text: str) -> bool:
    lower = html_text.lower()
    return "seraph" in lower and "login" in lower


def normalize_wiki_url(raw_url: str) -> str:
    raw = str(raw_url or "").strip()
    try:
        parsed = urlparse(raw)
    except Exception:
        raise ValueError("请输入有效的 Wiki 地址") from None
    if parsed.scheme not in ("http", "https"):
        raise ValueError("仅支持 http/https 的 Wiki 地址")
    if parsed.hostname not in settings.ALLOWED_WIKI_HOSTS:
        raise ValueError("当前仅支持 wiki.lianjia.com 地址")
    return raw


async def verify_wiki_access(raw_url: str) -> dict[str, Any]:
    normalized_url = normalize_wiki_url(raw_url)
    auth = resolve_wiki_auth()
    if not auth.get("cookie") and not auth.get("authToken"):
        raise ValueError("当前未配置可用的 Wiki 凭证")
    async with httpx.AsyncClient() as client:
        r = await client.get(
            normalized_url,
            headers=build_wiki_request_headers(auth),
            timeout=30.0,
            follow_redirects=True,
        )
    html_text = r.text
    try:
        final_host = urlparse(str(r.url)).hostname or ""
    except Exception:
        final_host = ""
    login_reason = normalize_optional_string(r.headers.get("x-seraph-loginreason"))
    authenticated_user = normalize_optional_string(r.headers.get("x-ausername"))
    title = extract_html_title(html_text)
    login_redirected = bool(final_host) and final_host not in settings.ALLOWED_WIKI_HOSTS
    login_page = looks_like_wiki_login_html(html_text)
    if r.status_code in (401, 403):
        return {
            "ok": False,
            "error": f"Wiki 鉴权失败（HTTP {r.status_code}）",
            "httpStatus": r.status_code,
            "finalUrl": str(r.url),
            "loginReason": login_reason,
            "authenticatedUser": authenticated_user,
            "title": title,
        }
    if login_redirected or login_page or (login_reason and login_reason != "OK"):
        return {
            "ok": False,
            "error": "当前 Wiki 凭证已失效或未登录，请更新 cookie 后重试",
            "httpStatus": r.status_code,
            "finalUrl": str(r.url),
            "loginReason": login_reason,
            "authenticatedUser": authenticated_user,
            "title": title,
        }
    if not r.is_success:
        return {
            "ok": False,
            "error": f"读取 Wiki 验证页失败（HTTP {r.status_code}）",
            "httpStatus": r.status_code,
            "finalUrl": str(r.url),
            "loginReason": login_reason,
            "authenticatedUser": authenticated_user,
            "title": title,
        }
    return {
        "ok": True,
        "httpStatus": r.status_code,
        "finalUrl": str(r.url),
        "loginReason": login_reason,
        "authenticatedUser": authenticated_user,
        "title": title,
        "hasMainContent": 'id="main-content"' in html_text or "id='main-content'" in html_text,
        "source": auth.get("source"),
    }


def build_wiki_auth_status() -> dict[str, Any]:
    runtime = load_runtime_wiki_auth()
    resolved = resolve_wiki_auth()
    import os

    env_cookie = normalize_wiki_cookie(os.environ.get("WIKI_COOKIE", ""))
    env_token = normalize_wiki_auth_token(os.environ.get("WIKI_AUTH_TOKEN", ""))
    resolved_admin = normalize_optional_string(os.environ.get("WIKI_ADMIN_SECRET")) or settings.WIKI_ADMIN_SECRET
    return {
        "adminSecretConfigured": bool(resolved_admin),
        "adminSecretSource": "env" if normalize_optional_string(os.environ.get("WIKI_ADMIN_SECRET")) else "default",
        "source": resolved["source"],
        "cookieConfigured": bool(resolved.get("cookie")),
        "authTokenConfigured": bool(resolved.get("authToken")),
        "cookieMasked": mask_cookie_string(resolved.get("cookie")),
        "authTokenMasked": mask_secret_value(resolved.get("authToken") or "", 6, 4),
        "updatedAt": resolved["updatedAt"] if resolved["source"] == "runtime" else "",
        "updatedBy": resolved["updatedBy"] if resolved["source"] == "runtime" else "",
        "runtimeConfigured": bool(runtime.get("exists") and (runtime.get("cookie") or runtime.get("authToken"))),
        "runtimeCookieMasked": mask_cookie_string(runtime.get("cookie")),
        "runtimeAuthTokenMasked": mask_secret_value(runtime.get("authToken") or "", 6, 4),
        "runtimeUpdatedAt": runtime.get("updatedAt", ""),
        "runtimeUpdatedBy": runtime.get("updatedBy", ""),
        "envConfigured": bool(env_cookie or env_token),
        "envCookieMasked": mask_cookie_string(env_cookie),
        "envAuthTokenMasked": mask_secret_value(env_token, 6, 4),
    }


async def save_runtime_wiki_auth(
    *, cookie: str, auth_token: str, updated_by: str
) -> dict[str, Any]:
    from .repos import config_rows

    next_cookie = normalize_wiki_cookie(cookie)
    next_token = normalize_wiki_auth_token(auth_token)
    if not next_cookie and not next_token:
        if settings.WIKI_AUTH_FILE.exists():
            settings.WIKI_AUTH_FILE.unlink()
        if settings.use_database():
            await config_rows.delete_wiki_row()
        return load_runtime_wiki_auth()

    from datetime import datetime, timezone

    payload = {
        "cookie": next_cookie,
        "authToken": next_token,
        "updatedAt": datetime.now(timezone.utc).isoformat(),
        "updatedBy": normalize_optional_string(updated_by) or "manual-admin",
    }

    if settings.use_database():
        await config_rows.save_wiki_row(next_cookie, next_token, payload["updatedBy"])

    if (not settings.use_database()) or settings.dual_write_json():

        def _write(_: dict[str, Any]) -> dict[str, Any]:
            return payload

        await queue_json_object_update(settings.WIKI_AUTH_FILE, _write)
    return load_runtime_wiki_auth()
