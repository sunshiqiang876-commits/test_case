"""FastAPI entry — parallel staging server (does not touch Node production data by default)."""

from __future__ import annotations

import asyncio
import hmac
import os
import tempfile
import uuid
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI, Header, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import database, settings
from .markdown_utils import convert_list_to_heading_md
from .job_state import (
    create_testcase_job,
    find_job_by_client_request_id_async,
    load_job_from_store,
    mark_job_cancelled,
    new_job_id,
    serialize_testcase_job,
    testcase_jobs,
)
from .repos import jobs as jobs_repo
from .repos import pairs as pairs_repo
from .repos import results as results_repo
from .orchestration import (
    append_result_record,
    decorate_result_record,
    execute_testcase_job,
    upsert_input_pair,
)
from .prompt_config import build_prompt_config_payload, save_runtime_prompt_config
from .storage import load_json_array
from .wiki import (
    build_doc_parser_proxy_headers,
    build_wiki_auth_status,
    normalize_wiki_url,
    save_runtime_wiki_auth,
    verify_wiki_access,
)

app = FastAPI(title="Testcase Generator (Python staging)")

PUBLIC_DIR = settings.PUBLIC_DIR


def _secrets_match(expected: str, provided: str) -> bool:
    e = (expected or "").encode("utf-8")
    p = (provided or "").encode("utf-8")
    if not e or not p or len(e) != len(p):
        return False
    return hmac.compare_digest(e, p)


def _wiki_admin_forbidden() -> JSONResponse:
    return JSONResponse(status_code=403, content={"success": False, "error": "管理员口令无效"})


def _require_wiki_admin_secret(x_secret: str | None) -> JSONResponse | None:
    exp = (os.environ.get("WIKI_ADMIN_SECRET") or settings.WIKI_ADMIN_SECRET or "").strip() or "ceshi_admin"
    if not _secrets_match(exp, (x_secret or "").strip()):
        return _wiki_admin_forbidden()
    return None


@app.on_event("startup")
async def _startup() -> None:
    settings.DATA_DIR.mkdir(parents=True, exist_ok=True)
    await database.init_pool()


@app.on_event("shutdown")
async def _shutdown() -> None:
    await database.close_pool()


# --- HTML pages (before static mount) ---
@app.get("/")
async def index() -> FileResponse:
    return FileResponse(PUBLIC_DIR / "index.html")


@app.get("/list")
async def list_page() -> FileResponse:
    return FileResponse(PUBLIC_DIR / "list.html")


@app.get("/mindmap")
async def mindmap_page() -> FileResponse:
    return FileResponse(PUBLIC_DIR / "mindmap.html")


@app.get("/wiki-auth-admin")
async def wiki_admin_page() -> FileResponse:
    return FileResponse(PUBLIC_DIR / "wiki-auth-admin.html")


@app.get("/api/debug/status")
async def debug_status() -> dict[str, Any]:
    return {
        "ok": True,
        "port": settings.PORT,
        "pythonDataDir": str(settings.DATA_DIR),
        "databaseConfigured": settings.use_database(),
        "databaseDualWriteJson": settings.dual_write_json(),
        "config": {
            "provider": settings.PROVIDER,
            "activeProviderReady": settings.is_generation_config_ready(),
            "gemini": {
                "hasApiKey": bool(settings.GEMINI_API_KEY),
                "model": settings.GEMINI_MODEL,
                "baseUrl": settings.GEMINI_BASE_URL,
                "timeoutMs": settings.GEMINI_TIMEOUT_MS,
            },
            "bellaChat": {
                "hasApiKey": bool(settings.BELLA_API_KEY),
                "model": settings.BELLA_CHAT_MODEL,
                "baseUrl": settings.BELLA_BASE_URL,
                "timeoutMs": settings.BELLA_CHAT_TIMEOUT_MS,
                "maxTokens": settings.BELLA_CHAT_MAX_TOKENS,
                "thinkingLevel": settings.BELLA_CHAT_THINKING_LEVEL,
            },
        },
    }


@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {
        "ok": True,
        "provider": settings.PROVIDER,
        "configReady": settings.is_generation_config_ready(),
    }


# --- Doc parser proxy ---
@app.get("/api/history")
async def api_history() -> JSONResponse:
    url = f"{settings.DOC_PARSER_API_BASE}/api/history"
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(url, headers=build_doc_parser_proxy_headers(), timeout=30.0)
        data = r.json() if r.content else {}
        return JSONResponse(content=data, status_code=r.status_code)
    except Exception as e:
        return JSONResponse(
            status_code=500, content={"success": False, "error": str(e) or "历史文档加载失败"}
        )


@app.get("/api/file-text")
async def api_file_text(path: str = "") -> JSONResponse:
    if not path.strip():
        return JSONResponse(status_code=400, content={"success": False, "error": "请提供文档路径"})
    from urllib.parse import quote

    url = f"{settings.DOC_PARSER_API_BASE}/api/file-text?path={quote(path.strip())}"
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(url, headers=build_doc_parser_proxy_headers(), timeout=30.0)
        try:
            data = r.json()
        except Exception:
            data = {"success": False, "error": r.text[:200]}
        return JSONResponse(content=data, status_code=r.status_code)
    except Exception as e:
        return JSONResponse(
            status_code=500, content={"success": False, "error": str(e) or "读取解析文档失败"}
        )


@app.get("/api/jobs/{job_id}")
async def api_jobs(job_id: str) -> JSONResponse:
    url = f"{settings.DOC_PARSER_API_BASE}/api/jobs/{job_id}"
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(url, headers=build_doc_parser_proxy_headers(), timeout=30.0)
        try:
            data = r.json()
        except Exception:
            data = {"success": False, "error": r.text[:200]}
        return JSONResponse(content=data, status_code=r.status_code)
    except Exception as e:
        return JSONResponse(
            status_code=500, content={"success": False, "error": str(e) or "文档解析任务查询失败"}
        )


@app.post("/api/parse")
async def api_parse(request: Request) -> JSONResponse:
    ct = request.headers.get("content-type")
    if not ct:
        return JSONResponse(status_code=400, content={"success": False, "error": "缺少文件上传内容类型"})
    # Stream request body to upstream (align with Node body: req), avoid buffering whole file in memory.
    headers = dict(build_doc_parser_proxy_headers({"Accept": "application/json", "Content-Type": ct}))

    async def body_iter():
        async for chunk in request.stream():
            yield chunk

    try:
        async with httpx.AsyncClient() as client:
            r = await client.post(
                f"{settings.DOC_PARSER_API_BASE}/api/parse",
                headers=headers,
                content=body_iter(),
                timeout=120.0,
            )
        try:
            data = r.json()
        except Exception:
            data = {
                "success": False,
                "error": (r.text[:200] if r.text else "解析服务返回了非 JSON 响应"),
            }
        return JSONResponse(content=data, status_code=r.status_code)
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e) or "文档解析失败"})


# --- Admin ---
@app.get("/api/admin/wiki-auth/status", response_model=None)
async def wiki_auth_status(x_wiki_admin_secret: str | None = Header(default=None)) -> JSONResponse | dict[str, Any]:
    bad = _require_wiki_admin_secret(x_wiki_admin_secret)
    if bad:
        return bad
    return {"success": True, "data": build_wiki_auth_status()}


@app.get("/api/admin/prompt-config", response_model=None)
async def prompt_config_get(x_wiki_admin_secret: str | None = Header(default=None)) -> JSONResponse | dict[str, Any]:
    bad = _require_wiki_admin_secret(x_wiki_admin_secret)
    if bad:
        return bad
    return {"success": True, "data": build_prompt_config_payload(True)}


class WikiAuthBody(BaseModel):
    cookie: str = ""
    authToken: str = ""
    updatedBy: str = ""


@app.post("/api/admin/wiki-auth", response_model=None)
async def wiki_auth_post(
    body: WikiAuthBody, x_wiki_admin_secret: str | None = Header(default=None)
) -> JSONResponse | dict[str, Any]:
    bad = _require_wiki_admin_secret(x_wiki_admin_secret)
    if bad:
        return bad
    if not (body.cookie.strip() or body.authToken.strip()):
        return JSONResponse(
            status_code=400, content={"success": False, "error": "请至少提供 Wiki Cookie 或 Auth Token"}
        )
    try:
        await save_runtime_wiki_auth(
            cookie=body.cookie, auth_token=body.authToken, updated_by=body.updatedBy
        )
        return {"success": True, "data": build_wiki_auth_status()}
    except Exception as e:
        return JSONResponse(
            status_code=500, content={"success": False, "error": str(e) or "保存运行时 Wiki 凭证失败"}
        )


class PromptConfigBody(BaseModel):
    templates: dict[str, Any] = {}
    knowledgeBase: str = ""
    updatedBy: str = ""


@app.post("/api/admin/prompt-config", response_model=None)
async def prompt_config_post(
    body: PromptConfigBody, x_wiki_admin_secret: str | None = Header(default=None)
) -> JSONResponse | dict[str, Any]:
    bad = _require_wiki_admin_secret(x_wiki_admin_secret)
    if bad:
        return bad
    try:
        await save_runtime_prompt_config(body.templates, body.knowledgeBase, body.updatedBy)
        return {"success": True, "data": build_prompt_config_payload(True)}
    except Exception as e:
        return JSONResponse(
            status_code=500, content={"success": False, "error": str(e) or "保存 Prompt 配置失败"}
        )


class WikiVerifyBody(BaseModel):
    url: str = ""


@app.post("/api/admin/wiki-auth/verify", response_model=None)
async def wiki_verify(
    body: WikiVerifyBody, x_wiki_admin_secret: str | None = Header(default=None)
) -> JSONResponse | dict[str, Any]:
    bad = _require_wiki_admin_secret(x_wiki_admin_secret)
    if bad:
        return bad
    if not body.url.strip():
        return JSONResponse(
            status_code=400, content={"success": False, "error": "请提供用于验证的 Wiki 地址"}
        )
    try:
        result = await verify_wiki_access(body.url.strip())
        if not result.get("ok"):
            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "error": result.get("error"),
                    "data": {
                        "httpStatus": result.get("httpStatus"),
                        "finalUrl": result.get("finalUrl"),
                        "loginReason": result.get("loginReason"),
                        "authenticatedUser": result.get("authenticatedUser"),
                        "title": result.get("title"),
                    },
                },
            )
        return {"success": True, "data": result}
    except ValueError as e:
        return JSONResponse(status_code=400, content={"success": False, "error": str(e) or "Wiki 凭证验证失败"})


# --- Wiki parse proxy ---
class WikiParseBody(BaseModel):
    url: str = ""
    target: str = ""


@app.post("/api/wiki/parse")
async def wiki_parse(body: WikiParseBody) -> JSONResponse:
    if not body.url.strip():
        return JSONResponse(status_code=400, content={"success": False, "error": "请提供 Wiki 地址"})
    try:
        normalized = normalize_wiki_url(body.url.strip()).strip()
        payload = {"url": normalized, "target": (body.target or "").strip().lower()}
        async with httpx.AsyncClient() as client:
            r = await client.post(
                f"{settings.DOC_PARSER_API_BASE}/api/wiki/import",
                headers=build_doc_parser_proxy_headers({"Content-Type": "application/json"}),
                json=payload,
                timeout=45.0,
            )
        try:
            data = r.json()
        except Exception:
            data = {"success": False, "error": r.text[:200]}
        return JSONResponse(content=data, status_code=r.status_code)
    except ValueError as e:
        return JSONResponse(status_code=400, content={"success": False, "error": str(e)})
    except Exception as e:
        return JSONResponse(status_code=400, content={"success": False, "error": str(e) or "Wiki 地址解析失败"})


@app.get("/api/wiki/jobs/{job_id}")
async def wiki_jobs(job_id: str) -> JSONResponse:
    url = f"{settings.DOC_PARSER_API_BASE}/api/wiki/jobs/{job_id}"
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(url, headers=build_doc_parser_proxy_headers(), timeout=30.0)
        try:
            data = r.json()
        except Exception:
            data = {"success": False, "error": r.text[:200]}
        return JSONResponse(content=data, status_code=r.status_code)
    except Exception as e:
        return JSONResponse(
            status_code=500, content={"success": False, "error": str(e) or "Wiki 任务状态查询失败"}
        )


# --- Testcase ---
@app.get("/api/testcase/pairs")
async def testcase_pairs() -> dict[str, Any]:
    if settings.use_database():
        data = await pairs_repo.list_pairs()
        if data:
            return {"success": True, "data": data}
    pairs = load_json_array(settings.INPUT_PAIRS_FILE)
    return {"success": True, "data": pairs}


class GenerateBody(BaseModel):
    prd: str = ""
    tech: str = ""
    clientRequestId: str | None = None


@app.post("/api/testcase/generate")
async def testcase_generate(body: GenerateBody) -> JSONResponse:
    if not settings.is_generation_config_ready():
        err = (
            "请在 .env 中配置 GEMINI_API_KEY（以及可选的 GEMINI_MODEL、GEMINI_BASE_URL、GEMINI_TIMEOUT_MS）"
            if settings.PROVIDER == "gemini"
            else (
                "请在 .env 中配置 BELLA_API_KEY（以及可选的 BELLA_CHAT_MODEL、BELLA_CHAT_TIMEOUT_MS）"
                if settings.PROVIDER == "bella"
                else "请在 .env 中配置 BELLA_API_KEY、BELLA_TENANT_ID、BELLA_WORKFLOW_ELEMENTS_ID、BELLA_WORKFLOW_TEST_POINT_ID、BELLA_WORKFLOW_ELEMENT_MATCH_ID、BELLA_WORKFLOW_BIZ_ID、BELLA_WORKFLOW_ELEMENT_MATCH_FALLBACK_ID、BELLA_WORKFLOW_BIZ_FALLBACK_ID"
            )
        )
        return JSONResponse(
            status_code=500,
            content={"success": False, "message": "服务未配置", "error": err},
        )
    if not str(body.prd).strip():
        return JSONResponse(
            status_code=400, content={"success": False, "message": "参数错误", "error": "prd 为必填项"}
        )
    if not str(body.tech).strip():
        return JSONResponse(
            status_code=400, content={"success": False, "message": "参数错误", "error": "tech 为必填项"}
        )
    prd_text = str(body.prd).strip()
    tech_text = str(body.tech).strip()
    normalized_client = (
        body.clientRequestId.strip()
        if isinstance(body.clientRequestId, str) and body.clientRequestId.strip()
        else None
    )
    resolved_client = normalized_client or str(uuid.uuid4())
    existing = await find_job_by_client_request_id_async(resolved_client)
    if existing:
        return JSONResponse(
            status_code=202 if existing["status"] == "running" else 200,
            content={
                "success": True,
                "accepted": existing["status"] == "running",
                "data": {
                    "jobId": existing["id"],
                    "clientRequestId": existing["clientRequestId"],
                    "createdAt": existing["createdAt"],
                    "job": serialize_testcase_job(existing),
                },
            },
        )
    await upsert_input_pair(prd_text, tech_text)
    job_id = new_job_id()
    job = create_testcase_job(
        job_id=job_id, client_request_id=resolved_client, prd=prd_text, tech=tech_text
    )
    testcase_jobs[job_id] = job
    if settings.use_database():
        await jobs_repo.upsert_job(job)
    runner = asyncio.create_task(execute_testcase_job(job_id))
    job["runner_task"] = runner
    return JSONResponse(
        status_code=202,
        content={
            "success": True,
            "accepted": True,
            "data": {
                "jobId": job_id,
                "clientRequestId": resolved_client,
                "createdAt": job["createdAt"],
                "job": serialize_testcase_job(job),
            },
        },
    )


@app.get("/api/testcase/jobs/by-client/{client_request_id}")
async def job_by_client(client_request_id: str) -> JSONResponse:
    job = await find_job_by_client_request_id_async(client_request_id)
    if not job:
        return JSONResponse(status_code=404, content={"success": False, "message": "未找到该生成任务"})
    return {"success": True, "data": serialize_testcase_job(job)}


@app.post("/api/testcase/jobs/by-client/{client_request_id}/cancel")
async def cancel_by_client(client_request_id: str) -> JSONResponse:
    job = await find_job_by_client_request_id_async(client_request_id)
    if not job:
        return JSONResponse(status_code=404, content={"success": False, "message": "未找到该生成任务"})
    if job["status"] == "done":
        return JSONResponse(
            status_code=409, content={"success": False, "message": "该生成任务已完成，无法中止"}
        )
    if job["status"] == "failed":
        return JSONResponse(
            status_code=409, content={"success": False, "message": "该生成任务已失败，无需中止"}
        )
    mark_job_cancelled(job, "已中止生成")
    return {"success": True, "data": serialize_testcase_job(job)}


@app.get("/api/testcase/jobs/{job_id}")
async def job_get(job_id: str) -> JSONResponse:
    job = await load_job_from_store(job_id)
    if not job:
        return JSONResponse(status_code=404, content={"success": False, "message": "未找到该生成任务"})
    return {"success": True, "data": serialize_testcase_job(job)}


@app.post("/api/testcase/jobs/{job_id}/cancel")
async def cancel_job(job_id: str) -> JSONResponse:
    job = await load_job_from_store(job_id)
    if not job:
        return JSONResponse(status_code=404, content={"success": False, "message": "未找到该生成任务"})
    if job["status"] == "done":
        return JSONResponse(
            status_code=409, content={"success": False, "message": "该生成任务已完成，无法中止"}
        )
    if job["status"] == "failed":
        return JSONResponse(
            status_code=409, content={"success": False, "message": "该生成任务已失败，无需中止"}
        )
    mark_job_cancelled(job, "已中止生成")
    return {"success": True, "data": serialize_testcase_job(job)}


@app.get("/api/testcase/list")
async def testcase_list() -> dict[str, Any]:
    if settings.use_database():
        rows = await results_repo.list_results_ordered_newest_first()
        if rows:
            return {"success": True, "data": [decorate_result_record(r) for r in rows]}
    results = load_json_array(settings.RESULTS_FILE)
    return {"success": True, "data": [decorate_result_record(r) for r in results]}


@app.get("/api/testcase/{record_id}")
async def testcase_one(record_id: str) -> JSONResponse:
    if settings.use_database():
        rec = await results_repo.get_result_by_id(record_id)
        if rec:
            return {"success": True, "data": decorate_result_record(rec)}
    results = load_json_array(settings.RESULTS_FILE)
    record = next((r for r in results if isinstance(r, dict) and r.get("id") == record_id), None)
    if not record:
        return JSONResponse(status_code=404, content={"success": False, "message": "未找到该记录"})
    return {"success": True, "data": decorate_result_record(record)}


class MarkdownConvertBody(BaseModel):
    markdown: str = ""


@app.post("/api/markdown/convert")
async def markdown_convert(body: MarkdownConvertBody) -> Response:
    if not isinstance(body.markdown, str) or not body.markdown:
        return JSONResponse(status_code=400, content={"success": False, "error": "请提供 markdown 内容"})
    converted = convert_list_to_heading_md(body.markdown)
    tmp_root = settings.TMP_MD2XMIND or Path(tempfile.gettempdir()) / "md2xmind"
    tmp_root.mkdir(parents=True, exist_ok=True)
    mid = str(uuid.uuid4())
    out_name = f"mindmap-{int(__import__('time').time() * 1000)}-{mid[:8]}"
    md_path = tmp_root / f"{mid}.md"
    xmind_path = tmp_root / f"{out_name}.xmind"
    try:
        md_path.write_text(converted, encoding="utf-8")
        proc = await asyncio.create_subprocess_exec(
            "python3",
            "-c",
            f'import md2xmind; md2xmind.start_trans_file("{mid}.md", "{out_name}", "思维导图")',
            cwd=str(tmp_root),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError((stderr or b"").decode("utf-8", errors="replace") or f"exit {proc.returncode}")
        if not xmind_path.exists():
            raise RuntimeError("未生成 xmind 文件")
        data = xmind_path.read_bytes()
        md_path.unlink(missing_ok=True)
        xmind_path.unlink(missing_ok=True)
        return Response(
            content=data,
            media_type="application/vnd.xmind.workbook",
            headers={"Content-Disposition": f'attachment; filename="{out_name}.xmind"'},
        )
    except Exception as e:
        md_path.unlink(missing_ok=True)
        xmind_path.unlink(missing_ok=True)
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": str(e) or "转换失败，请确保已安装 md2xmind（pip3 install md2xmind）",
            },
        )


# Mount static assets last so /api/* and explicit HTML routes are not shadowed.
app.mount("/", StaticFiles(directory=str(PUBLIC_DIR), html=False), name="public")


def run() -> None:
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=settings.PORT,
        reload=False,
    )


if __name__ == "__main__":
    run()
