"""Async Postgres connection pool (asyncpg). Optional — only when DATABASE_URL is set."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from . import settings

if TYPE_CHECKING:
    import asyncpg

_log = logging.getLogger(__name__)
_pool: Any = None


def _asyncpg():
    try:
        import asyncpg as apg
    except ImportError as e:
        raise RuntimeError(
            "asyncpg is required when DATABASE_URL is set. Install: pip install asyncpg"
        ) from e
    return apg


async def init_pool() -> Any:
    global _pool
    if not settings.use_database():
        _log.info("DATABASE_URL not set; using JSON file storage")
        return None
    if _pool is not None:
        return _pool
    asyncpg = _asyncpg()
    _pool = await asyncpg.create_pool(
        settings.DATABASE_URL,
        min_size=1,
        max_size=10,
        command_timeout=120,
    )
    _log.info("Postgres pool connected")
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None
        _log.info("Postgres pool closed")


def pool() -> asyncpg.Pool | None:
    return _pool


async def fetchval(query: str, *args: Any) -> Any:
    p = await init_pool()
    if not p:
        return None
    async with p.acquire() as conn:
        return await conn.fetchval(query, *args)


async def fetchrow(query: str, *args: Any) -> Any:
    p = await init_pool()
    if not p:
        return None
    async with p.acquire() as conn:
        return await conn.fetchrow(query, *args)


async def fetch(query: str, *args: Any) -> list[Any]:
    p = await init_pool()
    if not p:
        return []
    async with p.acquire() as conn:
        return await conn.fetch(query, *args)


async def execute(query: str, *args: Any) -> str:
    p = await init_pool()
    if not p:
        return ""
    async with p.acquire() as conn:
        return await conn.execute(query, *args)


async def executemany(query: str, args: list[tuple[Any, ...]]) -> None:
    p = await init_pool()
    if not p:
        return
    async with p.acquire() as conn:
        await conn.executemany(query, args)
